package com.example.blacksmithspath

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlin.math.ceil

private val bg = Color(0xFF171411)
private val panel = Color(0xFF28221C)
private val gold = Color(0xFFC58A43)
private val cream = Color(0xFFF0E4D0)
private val muted = Color(0xFFB8A995)

private data class Tool(val name: String, val image: String, val description: String, val requirements: List<String>)
private val toolRooms = listOf(
    listOf(
        Tool("Печь с подачей воздуха", "https://images.pexels.com/photos/12841912/pexels-photo-12841912.jpeg?auto=compress&cs=tinysrgb&w=900", "Печь для нагрева и плавки металла.", listOf("Навык: кузнечное дело 1 уровня", "Стоимость: бесплатно")),
        Tool("Наковальня", "https://images.pexels.com/photos/5846089/pexels-photo-5846089.jpeg?auto=compress&cs=tinysrgb&w=900", "Основное рабочее место для ковки заготовок.", listOf("Навык: кузнечное дело 1 уровня", "Стоимость: бесплатно")),
        Tool("Кузнечный молот", "https://images.pexels.com/photos/19460423/pexels-photo-19460423.jpeg?auto=compress&cs=tinysrgb&w=900", "Ручной инструмент для придания формы металлу.", listOf("Сила: 5", "Стоимость: бесплатно")),
        Tool("Рабочий верстак", "https://images.pexels.com/photos/32979598/pexels-photo-32979598.jpeg?auto=compress&cs=tinysrgb&w=900", "Стол для подготовки и сборки металлических деталей.", listOf("Навык: кузнечное дело 1 уровня", "Стоимость: бесплатно")),
        Tool("Точильный камень", "https://images.pexels.com/photos/5845914/pexels-photo-5845914.jpeg?auto=compress&cs=tinysrgb&w=900", "Инструмент для заточки и доводки кромки.", listOf("Ловкость: 5", "Стоимость: бесплатно"))
    ),
    listOf(
        Tool("Доска для подготовки кожи", "https://images.pexels.com/photos/6068960/pexels-photo-6068960.jpeg?auto=compress&cs=tinysrgb&w=900", "Подготовка и сушка шкур.", listOf("Комната закрыта", "Стоимость: бесплатно")),
        Tool("Нож для раскроя", "https://images.pexels.com/photos/4226876/pexels-photo-4226876.jpeg?auto=compress&cs=tinysrgb&w=900", "Раскрой кожи и заготовок.", listOf("Комната закрыта", "Стоимость: бесплатно")),
        Tool("Набор для шитья", "https://images.pexels.com/photos/4210860/pexels-photo-4210860.jpeg?auto=compress&cs=tinysrgb&w=900", "Сшивание кожаных деталей.", listOf("Комната закрыта", "Стоимость: бесплатно")),
        Tool("Седельный зажим", "https://images.pexels.com/photos/6068965/pexels-photo-6068965.jpeg?auto=compress&cs=tinysrgb&w=900", "Фиксация деталей при работе.", listOf("Комната закрыта", "Стоимость: бесплатно")),
        Tool("Полировщик кожи", "https://images.pexels.com/photos/6068962/pexels-photo-6068962.jpeg?auto=compress&cs=tinysrgb&w=900", "Финишная обработка поверхности.", listOf("Комната закрыта", "Стоимость: бесплатно"))
    ),
    listOf(
        Tool("Рукоять для гравировки", "https://images.pexels.com/photos/5974300/pexels-photo-5974300.jpeg?auto=compress&cs=tinysrgb&w=900", "Ручной инструмент для нанесения рун.", listOf("Комната закрыта", "Стоимость: бесплатно")),
        Tool("Набор гравировальных резцов", "https://images.pexels.com/photos/5974301/pexels-photo-5974301.jpeg?auto=compress&cs=tinysrgb&w=900", "Резцы для рун разных форм.", listOf("Комната закрыта", "Стоимость: бесплатно")),
        Tool("Гравировальные тиски", "https://images.pexels.com/photos/5974302/pexels-photo-5974302.jpeg?auto=compress&cs=tinysrgb&w=900", "Фиксация предмета при гравировке.", listOf("Комната закрыта", "Стоимость: бесплатно")),
        Tool("Полировальные камни", "https://images.pexels.com/photos/5974303/pexels-photo-5974303.jpeg?auto=compress&cs=tinysrgb&w=900", "Полировка рунических линий.", listOf("Комната закрыта", "Стоимость: бесплатно")),
        Tool("Глубиномер гравировки", "https://images.pexels.com/photos/5974304/pexels-photo-5974304.jpeg?auto=compress&cs=tinysrgb&w=900", "Контроль глубины нанесения рун.", listOf("Комната закрыта", "Стоимость: бесплатно"))
    )
)
private val rankNames = listOf("F", "E", "D", "C", "B", "A", "S", "SS", "SSS", "EX")
private data class GameItem(val id: Int, val name: String, val description: String, val amount: Double, val unit: String, val unitWeight: Double, val image: String = "")
private val initialItems = listOf(GameItem(1, "Начальный молот кузнеца", "При экипировке повышает силу на 1.", 1.0, "шт.", 2.0))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setContent { BlacksmithApp() }
    }
}

@Composable
private fun BlacksmithApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var room by remember { mutableIntStateOf(0) }
    var selectedTool by remember { mutableStateOf<Tool?>(null) }
    var location by remember { mutableStateOf("Дом") }
    var goldAmount by remember { mutableIntStateOf(100) }
    var level by remember { mutableIntStateOf(1) }
    var xp by remember { mutableIntStateOf(0) }
    var freePoints by remember { mutableIntStateOf(0) }
    var multiplier by remember { mutableStateOf("1") }
    val stats = remember { mutableStateMapOf("Сила" to 5, "Ловкость" to 5, "Выносливость" to 5, "Интеллект" to 5, "Удача" to 5) }
    val ranks = remember { mutableStateMapOf<String, Int>().apply { toolRooms.flatten().forEach { put(it.name, 0) } } }
    val inventory = remember { mutableStateListOf<GameItem>().apply { addAll(initialItems) } }
    val storage = remember { mutableStateListOf<GameItem>() }
    var drawerItem by remember { mutableStateOf<GameItem?>(null) }
    var drawerFromStorage by remember { mutableStateOf(false) }
    var amountText by remember { mutableStateOf("1") }
    var confirmDelete by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    val carryMax = 50.0
    val carryNow = inventory.sumOf { it.amount * it.unitWeight }
    val hpMax = 100 + 20 * (stats["Выносливость"] ?: 5) + 5 * level
    val mpMax = 50 + 15 * (stats["Интеллект"] ?: 5) + 3 * level
    val ovMax = 50 + 10 * (stats["Выносливость"] ?: 5) + 2 * level

    MaterialTheme(colorScheme = darkColorScheme(background = bg, surface = panel, primary = gold, onPrimary = Color.Black, onBackground = cream, onSurface = cream)) {
        Box(Modifier.fillMaxSize().background(bg)) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (selectedTool != null) {
                        val t = selectedTool!!
                        ToolDetail(t, ranks[t.name] ?: 0, { name -> ranks[name] = ((ranks[name] ?: 0) + 1).coerceAtMost(9) }, { selectedTool = null })
                    } else when (selectedTab) {
                        0 -> HereScreen(location, hpMax, mpMax, ovMax, goldAmount, carryNow, carryMax, onMove = { location = it })
                        1 -> PlaceholderScreen("", "Вкладка пока не назначена")
                        2 -> CharacterScreen(level, freePoints, stats, inventory, hpMax, mpMax, ovMax, onItem = { item -> drawerItem = item; drawerFromStorage = false; amountText = "1" })
                        3 -> MapScreen(location, onMove = { location = it; selectedTab = 0 })
                        else -> SettingsScreen(multiplier, { multiplier = it }, { xp += 80 * multiplier.toInt(); while (xp >= level * 100) { xp -= level * 100; level++; freePoints += 2 } }, { goldAmount += 55 })
                    }
                }
                NavigationBar(containerColor = Color(0xFF211C17), contentColor = cream) {
                    val entries = listOf("Ты здесь", "", "Персонаж", "Карта", "Настройки")
                    val icons = listOf(Icons.Default.Place, Icons.Default.Build, Icons.Default.Person, Icons.Default.Map, Icons.Default.Settings)
                    entries.forEachIndexed { index, label ->
                        NavigationBarItem(selected = selectedTab == index, onClick = { selectedTab = index; selectedTool = null; drawerItem = null }, icon = {
                            if (index == 2) Box(Modifier.size(46.dp).background(if (selectedTab == index) gold else Color(0xFF493522), CircleShape), contentAlignment = Alignment.Center) { Icon(icons[index], null, tint = if (selectedTab == index) Color(0xFF21170D) else gold) }
                            else Icon(icons[index], null)
                        }, label = { if (label.isNotEmpty()) Text(label, fontSize = 9.sp, maxLines = 1) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = gold, selectedTextColor = gold, indicatorColor = Color(0xFF493522), unselectedIconColor = Color.LightGray, unselectedTextColor = Color.LightGray))
                    }
                }
            }
            if (selectedTab == 0 && selectedTool == null) {
                // Room navigation remains available in the home workshop view.
                Column(Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 10.dp)) {
                    TextButton(onClick = { if (location == "Дом") room = (room + 1) % 4 }) { Text(if (location == "Дом") listOf("Кузница", "Кожа", "Руны", "Склад")[room] else "", color = gold) }
                }
            }
            if (drawerItem != null) {
                val item = drawerItem!!
                Row(Modifier.fillMaxSize().background(Color(0x99000000)), horizontalArrangement = Arrangement.End) {
                    Spacer(Modifier.weight(1f).fillMaxHeight().clickable { drawerItem = null })
                    Column(Modifier.fillMaxHeight().fillMaxWidth(0.75f).background(panel).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF44382B)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Inventory2, null, tint = gold, modifier = Modifier.size(30.dp)) }
                            Spacer(Modifier.width(10.dp))
                            Text(item.name, color = cream, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        Text(item.description, color = muted, fontSize = 13.sp)
                        Text("Количество", color = gold, fontWeight = FontWeight.Bold)
                        OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = cream, unfocusedTextColor = cream))
                        val selectedAmount = amountText.replace(',', '.').toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
                        Slider(value = selectedAmount.toFloat().coerceIn(0f, item.amount.toFloat()), onValueChange = { amountText = if (item.unit == "кг") "%.2f".format(it).replace(',', '.') else it.toInt().toString() }, valueRange = 0f..item.amount.toFloat().coerceAtLeast(0.01f))
                        if (item.unit != "кг") {
                            Text("Вес: 1 шт. — ${item.unitWeight} кг\nВсего: ${(selectedAmount * item.unitWeight).let { "%.2f".format(it) }} кг", color = muted, fontSize = 12.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        if (drawerFromStorage) {
                            Button(onClick = {
                                val count = if (item.unit == "кг") (selectedAmount * 100).toInt().coerceIn(1, (item.amount * 100).toInt()) / 100.0 else ceil(selectedAmount).toInt().coerceIn(1, item.amount.toInt()).toDouble()
                                if (carryNow + count * item.unitWeight <= carryMax) {
                                    storage.remove(item); inventory.add(item.copy(amount = count)); if (item.amount > count) storage.add(item.copy(amount = item.amount - count)); drawerItem = null
                                } else toast = "Вы столько не унесёте."
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color.Black)) { Text("Забрать") }
                        } else {
                            Button(onClick = {
                                if (location != "Дом") toast = "Выложить можно только дома."
                                else {
                                    val count = if (item.unit == "кг") (selectedAmount * 100).toInt().coerceIn(1, (item.amount * 100).toInt()) / 100.0 else ceil(selectedAmount).toInt().coerceIn(1, item.amount.toInt()).toDouble()
                                    inventory.remove(item); storage.add(item.copy(amount = count)); if (item.amount > count) inventory.add(item.copy(amount = item.amount - count)); drawerItem = null
                                }
                            }, enabled = location == "Дом", modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color.Black)) { Text("Выложить") }
                        }
                        OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) { Text("Выбросить", color = cream) }
                        TextButton(onClick = { drawerItem = null }, modifier = Modifier.fillMaxWidth()) { Text("Закрыть меню", color = gold) }
                    }
                }
                if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("Удаление предмета") }, text = { Text("Вы точно хотите удалить предмет?\n${item.name} — $amountText") }, confirmButton = { TextButton(onClick = { if (drawerFromStorage) storage.remove(item) else inventory.remove(item); drawerItem = null; confirmDelete = false }) { Text("Удалить") } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } }, containerColor = panel, titleContentColor = cream, textContentColor = cream)
            }
            if (toast.isNotEmpty()) AlertDialog(onDismissRequest = { toast = "" }, text = { Text(toast) }, confirmButton = { TextButton(onClick = { toast = "" }) { Text("ОК") } }, containerColor = panel, textContentColor = cream)
        }
    }
}

@Composable
private fun HereScreen(location: String, hp: Int, mp: Int, ov: Int, goldAmount: Int, weight: Double, maxWeight: Double, onMove: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
            Text("HP  $hp / $hp", color = cream); LinearProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxWidth(), color = Color(0xFFB94C43))
            Text("MP  $mp / $mp", color = cream); LinearProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxWidth(), color = Color(0xFF477DA8))
            Text("ОВ  $ov / $ov", color = cream); LinearProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxWidth(), color = Color(0xFF65A66C))
            Spacer(Modifier.height(5.dp)); Text("Репутация: F — 0/250, до E осталось 250", color = gold); Text("Золото: $goldAmount G", color = gold, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp)); Text("Ты здесь: $location", color = cream, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(if (location == "Дом") "Дряхлый, но свой." else "Текущая локация", color = muted)
        Spacer(Modifier.height(12.dp))
        if (location == "Дом") Text("Мастерская: комнаты и склад доступны через переключение вкладок.", color = gold)
        Spacer(Modifier.weight(1f))
        Text("Переносимый вес", color = muted, fontSize = 11.sp)
        LinearProgressIndicator(progress = { (weight / maxWeight).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = gold)
        Text("%.1f / %.0f кг".format(weight, maxWeight), color = cream, modifier = Modifier.align(Alignment.End))
    }
}

@Composable
private fun MapScreen(location: String, onMove: (String) -> Unit) {
    val places = listOf("Рынок" to "Здесь можно купить всё, что тебе нужно.", "Ворота" to "Выход из города.", "Замок" to "Здесь живёт король.", "Дом" to "Дряхлый, но свой.")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Карта", color = cream, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        places.forEach { (name, description) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Place, null, tint = gold, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text(name, color = cream, fontWeight = FontWeight.Bold); Text(description, color = muted, fontSize = 12.sp) }
                if (name == location) Text("Вы здесь", color = gold, fontSize = 12.sp)
                else Button(onClick = { onMove(name) }, contentPadding = PaddingValues(horizontal = 10.dp), colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color.Black)) { Text("Переместиться", fontSize = 10.sp) }
            }
        }
    }
}

@Composable
private fun SettingsScreen(multiplier: String, onMultiplier: (String) -> Unit, onXp: () -> Unit, onGold: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Настройки", color = cream, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Множитель опыта", color = gold)
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(value = "×$multiplier", onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(unfocusedTextColor = cream, focusedTextColor = cream))
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                listOf("0.5", "1", "2", "5", "10").forEach { v -> DropdownMenuItem(text = { Text("×$v") }, onClick = { onMultiplier(v); expanded = false }) }
            }
        }
        Button(onClick = onXp, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color.Black)) { Text("Получить опыт (+${80 * multiplier.toDouble().toInt()} XP)") }
        Button(onClick = onGold, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color.Black)) { Text("Получить золото (+55 G)") }
    }
}

@Composable
private fun CharacterScreen(level: Int, freePoints: Int, stats: MutableMap<String, Int>, inventory: List<GameItem>, hp: Int, mp: Int, ov: Int, onItem: (GameItem) -> Unit) {
    var subTab by remember { mutableIntStateOf(0) }
    var expandedStat by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Персонаж", color = cream, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Уровень $level  •  Свободные очки: $freePoints", color = gold)
        Text("HP $hp  •  MP $mp  •  ОВ $ov", color = muted)
        Spacer(Modifier.height(12.dp))
        Text("ЭКИПИРОВКА", color = gold, fontWeight = FontWeight.Bold)
        val slots = listOf("Кольцо" to "Голова" to "Кольцо", "Лук" to "Ожерелье" to "Стрелы", "Правая рука" to "Тело" to "Левая рука", "Оружие" to "Ноги" to "Оружие", "Зелье" to "Ступни" to "Зелье")
        slots.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(row.first.first, row.first.second, row.second).forEach { slot ->
                    Box(Modifier.weight(1f).padding(vertical = 3.dp).height(46.dp).background(panel, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) { Text(slot, color = muted, fontSize = 10.sp, textAlign = TextAlign.Center) }
                }
            }
        }
        Text("Атака: 5  •  Защита: 0  •  Скорость: 5", color = cream)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Инвентарь", "Навыки", "Характеристики").forEachIndexed { i, title ->
                Button(onClick = { subTab = i }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp), colors = ButtonDefaults.buttonColors(containerColor = if (subTab == i) gold else panel, contentColor = if (subTab == i) Color.Black else cream)) { Text(title, fontSize = 10.sp) }
            }
        }
        Spacer(Modifier.height(10.dp))
        when (subTab) {
            0 -> {
                Text("ИНВЕНТАРЬ", color = gold, fontWeight = FontWeight.Bold)
                LazyVerticalGrid(columns = GridCells.Fixed(5), modifier = Modifier.height(230.dp), userScrollEnabled = false, verticalArrangement = Arrangement.spacedBy(5.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    items(20) { index ->
                        val item = inventory.getOrNull(index)
                        Box(Modifier.aspectRatio(1f).background(panel, RoundedCornerShape(7.dp)).clickable { item?.let(onItem) }, contentAlignment = Alignment.Center) {
                            if (item != null) Icon(Icons.Default.Inventory2, null, tint = gold) else Text("·", color = muted)
                        }
                    }
                }
            }
            1 -> {
                Text("ПАССИВНЫЕ НАВЫКИ", color = gold, fontWeight = FontWeight.Bold)
                listOf("Кузнечное дело", "Кожевенное дело", "Руническая гравировка", "Двуручное оружие", "Одноручное оружие", "Дальний бой", "Блокирование").forEach {
                    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Row { Text(it, color = cream, modifier = Modifier.weight(1f)); Text("1", color = gold) }; LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth()); Text("0/100", color = muted, fontSize = 10.sp) }
                }
                Text("АКТИВНЫЕ НАВЫКИ", color = gold, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { repeat(6) { Box(Modifier.weight(1f).height(44.dp).background(panel, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) { Text(if (it < 5) "—" else "🔒", color = muted) } } }
            }
            else -> {
                Text("ХАРАКТЕРИСТИКИ", color = gold, fontWeight = FontWeight.Bold)
                val descriptions = mapOf("Сила" to "Влияет на общий переносимый вес и на количество обрабатываемого материала за раз. Отвечает за навык кузнечного дела и за урон ближним оружием.", "Ловкость" to "Влияет на скорость выполнения действий и точность движений. Отвечает за эффективность кожевенного дела и владение одноручным оружием и оружием дальнего боя.", "Выносливость" to "Увеличивает запас здоровья и количество ОВ. ОВ тратится во время работы или боя. Влияет на эффективность блокирования.", "Интеллект" to "Влияет на запас маны и эффективность работы с рунами. Отвечает за навык рунической гравировки и определяет количество доступных ячеек активных навыков.", "Удача" to "Я в такое не верю.")
                descriptions.forEach { (name, desc) ->
                    Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(10.dp)).clickable { expandedStat = if (expandedStat == name) "" else name }.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(name, color = cream, modifier = Modifier.weight(1f))
                            Text("${stats[name] ?: 5}", color = gold, fontWeight = FontWeight.Bold)
                        }
                        if (expandedStat == name) Text(desc, color = muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }
        }
    }
}

@Composable
private fun ToolDetail(tool: Tool, rankIndex: Int, onUpgrade: (String) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) { Icon(Icons.Default.ArrowBack, null, tint = gold); Text("Назад", color = gold) }
        AsyncImage(model = tool.image, contentDescription = tool.name, modifier = Modifier.fillMaxWidth().aspectRatio(3f / 4f).clip(RoundedCornerShape(18.dp)))
        Text(tool.name, color = cream, fontSize = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp))
        Button(onClick = { onUpgrade(tool.name) }, enabled = rankIndex < 9, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color.Black)) { Text("Улучшить до ${rankNames[(rankIndex + 1).coerceAtMost(9)]}") }
        Text("ТРЕБОВАНИЯ ДЛЯ УЛУЧШЕНИЯ", color = gold, modifier = Modifier.padding(top = 14.dp))
        tool.requirements.forEach { Text("• $it", color = cream, modifier = Modifier.padding(5.dp)) }
    }
}

@Composable
private fun PlaceholderScreen(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        if (title.isNotEmpty()) Text(title, color = cream, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Color.LightGray, textAlign = TextAlign.Center)
    }
}
