package com.example.blacksmithspath

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val bg = Color(0xFF171411)
private val panel = Color(0xFF28221C)
private val gold = Color(0xFFC58A43)
private val cream = Color(0xFFF0E4D0)

private data class Tool(val name: String, val image: String, val description: String, val requirements: List<String>)
private val tools = listOf(
    Tool("Печь с подачей воздуха", "https://images.pexels.com/photos/12841912/pexels-photo-12841912.jpeg?auto=compress&cs=tinysrgb&w=900", "Печь для нагрева и плавки металла.", listOf("Материалы: пока не требуются", "Навык: кузнечное дело 1 уровня", "Стоимость: бесплатно")),
    Tool("Наковальня", "https://images.pexels.com/photos/5846089/pexels-photo-5846089.jpeg?auto=compress&cs=tinysrgb&w=900", "Основное рабочее место для ковки заготовок.", listOf("Материалы: пока не требуются", "Навык: кузнечное дело 1 уровня", "Стоимость: бесплатно")),
    Tool("Кузнечный молот", "https://images.pexels.com/photos/19460423/pexels-photo-19460423.jpeg?auto=compress&cs=tinysrgb&w=900", "Ручной инструмент для придания формы металлу.", listOf("Материалы: пока не требуются", "Сила: 5", "Стоимость: бесплатно")),
    Tool("Рабочий верстак", "https://images.pexels.com/photos/32979598/pexels-photo-32979598.jpeg?auto=compress&cs=tinysrgb&w=900", "Стол для подготовки и сборки металлических деталей.", listOf("Материалы: пока не требуются", "Навык: кузнечное дело 1 уровня", "Стоимость: бесплатно")),
    Tool("Точильный камень", "https://images.pexels.com/photos/5845914/pexels-photo-5845914.jpeg?auto=compress&cs=tinysrgb&w=900", "Инструмент для заточки и доводки кромки.", listOf("Материалы: пока не требуются", "Ловкость: 5", "Стоимость: бесплатно"))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setContent { BlacksmithApp() }
    }
}

@Composable
private fun BlacksmithApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var room by remember { mutableIntStateOf(0) }
    var selectedTool by remember { mutableStateOf<Tool?>(null) }
    val ranks = remember { mutableStateMapOf<String, Int>().apply { tools.forEach { put(it.name, 0) } } }
    MaterialTheme(colorScheme = darkColorScheme(background = bg, surface = panel, primary = gold, onPrimary = Color.Black, onBackground = cream, onSurface = cream)) {
        Column(Modifier.fillMaxSize().background(bg)) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (selectedTool != null) {
                    ToolDetail(selectedTool!!, rankIndex = ranks[selectedTool!!.name] ?: 0, onUpgrade = { name -> ranks[name] = ((ranks[name] ?: 0) + 1).coerceAtMost(9) }, onBack = { selectedTool = null })
                } else {
                    when (selectedTab) {
                        0 -> WorkshopScreen(room, ranks, onRoomChange = { room = it }, onTool = { selectedTool = it })
                        1 -> PlaceholderScreen("Производство", "Здесь появится очередь производственных работ")
                        2 -> CharacterScreen()
                        3 -> PlaceholderScreen("Карта", "Карта мира появится позже")
                        else -> PlaceholderScreen("Настройки", "Настройки игры")
                    }
                }
            }
            NavigationBar(containerColor = Color(0xFF211C17), contentColor = cream) {
                val entries = listOf("Мастерская", "Производство", "Персонаж", "Карта", "Настройки")
                val icons = listOf(Icons.Default.Build, Icons.Default.Construction, Icons.Default.Person, Icons.Default.Map, Icons.Default.Settings)
                entries.forEachIndexed { index, label ->
                    NavigationBarItem(selected = selectedTab == index, onClick = { selectedTab = index; selectedTool = null }, icon = {
                        if (index == 2) {
                            Box(Modifier.size(46.dp).background(if (selectedTab == index) gold else Color(0xFF493522), CircleShape), contentAlignment = Alignment.Center) {
                                Icon(icons[index], contentDescription = label, tint = if (selectedTab == index) Color(0xFF21170D) else gold, modifier = Modifier.size(25.dp))
                            }
                        } else Icon(icons[index], contentDescription = label)
                    }, label = { Text(label, fontSize = 9.sp, maxLines = 1) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = gold, selectedTextColor = gold, indicatorColor = Color(0xFF493522), unselectedIconColor = Color.LightGray, unselectedTextColor = Color.LightGray))
                }
            }
        }
    }
}

@Composable
private fun WorkshopScreen(room: Int, ranks: Map<String, Int>, onRoomChange: (Int) -> Unit, onTool: (Tool) -> Unit) {
    val titles = listOf("Кузница", "Обработка кожи", "Руническая гравировка")
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).pointerInput(room) {
        var total = 0f
        detectHorizontalDragGestures(onHorizontalDrag = { _, drag -> total += drag }, onDragEnd = {
            if (total < -70) onRoomChange((room + 1).coerceAtMost(2))
            if (total > 70) onRoomChange((room - 1).coerceAtLeast(0))
            total = 0f
        })
    }) {
        Spacer(Modifier.height(18.dp))
        Text("ПУТЬ КУЗНЕЦА", color = gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(titles[room], color = cream, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("${room + 1} / 3  •  Свайп для смены комнаты", color = Color(0xFFB8A995), fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        if (room == 0) {
            Text("ИНСТРУМЕНТЫ КУЗНИЦЫ", color = gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(8.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(tools) { tool -> ToolTile(tool, ranks[tool.name] ?: 0) { onTool(tool) } }
            }
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Lock, null, tint = gold, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Комната закрыта", color = cream, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Эта мастерская станет доступна позже", color = Color.LightGray, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

private val rankNames = listOf("F", "E", "D", "C", "B", "A", "S", "SS", "SSS", "EX")

@Composable
private fun ToolTile(tool: Tool, rankIndex: Int, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(panel).clickable(onClick = onClick).padding(9.dp)) {
        AsyncImage(model = tool.image, contentDescription = tool.name, modifier = Modifier.fillMaxWidth().aspectRatio(3f / 4f).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.height(8.dp))
        Text(tool.name, color = cream, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, minLines = 2)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("РАНГ ${rankNames[rankIndex]}", color = gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, null, tint = gold, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun ToolDetail(tool: Tool, rankIndex: Int, onUpgrade: (String) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) { Icon(Icons.Default.ArrowBack, null, tint = gold); Spacer(Modifier.width(6.dp)); Text("Назад", color = gold) }
        AsyncImage(model = tool.image, contentDescription = tool.name, modifier = Modifier.fillMaxWidth().aspectRatio(3f / 4f).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.height(16.dp))
        Text(tool.name, color = cream, fontSize = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("РАНГ ${rankNames[rankIndex]}  •  НАЧАЛЬНЫЙ УРОВЕНЬ", color = gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Text(tool.description, color = Color(0xFFD0C4B4), fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))
        Button(onClick = { onUpgrade(tool.name) }, enabled = rankIndex < 9, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = Color.Black, disabledContainerColor = Color(0xFF66543D), disabledContentColor = Color.LightGray)) {
            Icon(Icons.Default.Upgrade, null); Spacer(Modifier.width(8.dp)); Text(if (rankIndex < 9) "Улучшить до ${rankNames[rankIndex + 1]}" else "Максимальный ранг", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text("ТРЕБОВАНИЯ ДЛЯ УЛУЧШЕНИЯ", color = gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        tool.requirements.forEach { req ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = gold, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(9.dp)); Text(req, color = cream, fontSize = 13.sp)
            }
        }
        Text("Временно: улучшение бесплатно", color = Color(0xFF8FC28C), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(24.dp))
    }
}


@Composable
private fun CharacterScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Персонаж", color = cream, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(panel).padding(18.dp)) {
            Text("НАЧИНАЮЩИЙ МАСТЕР", color = gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("Уровень 1", color = cream, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Свободные очки характеристик: 0", color = Color(0xFFB8A995), fontSize = 12.sp)
        }
        Spacer(Modifier.height(18.dp))
        Text("ХАРАКТЕРИСТИКИ", color = gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        listOf("Сила", "Ловкость", "Выносливость", "Интеллект", "Удача").forEach { stat ->
            Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stat, color = cream, fontSize = 15.sp)
                Text("5", color = gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            HorizontalDivider(color = Color(0xFF443A30))
        }
    }
}

@Composable
private fun PlaceholderScreen(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = cream, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp)); Text(subtitle, color = Color.LightGray, textAlign = TextAlign.Center)
    }
}
