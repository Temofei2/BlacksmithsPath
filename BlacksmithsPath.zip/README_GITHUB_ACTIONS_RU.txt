СБОРКА APK ЧЕРЕЗ GITHUB ACTIONS

Структура архива сохранена: сам Android-проект находится в папке BlacksmithsPath, а workflow GitHub Actions — в корневой папке .github.

Как загрузить:
1. Распакуйте архив.
2. Загрузите в корень GitHub-репозитория обе папки: BlacksmithsPath и .github. Не загружайте только содержимое BlacksmithsPath.
3. Сделайте Commit/Push.
4. Откройте GitHub → Actions → Build Android APK.
5. После успешного запуска скачайте artifact blacksmiths-path-debug-apk.

Workflow автоматически определяет расположение проекта: BlacksmithsPath/ (сохранённая структура) или корень репозитория. Поэтому проверка не должна падать из-за жёстко заданного пути.

Требования сборки: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, compileSdk 35.
