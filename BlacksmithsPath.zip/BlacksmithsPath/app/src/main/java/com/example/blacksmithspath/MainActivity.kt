@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.blacksmithspath

import android.os.Bundle
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive

private val bg = Color(0xFF171411)
private val panel = Color(0xFF28221C)
private val goldColor = Color(0xFFC58A43)
private val cream = Color(0xFFF0E4D0)
private val muted = Color(0xFFB8A995)
private val red = Color(0xFFC84D45)

private fun round2(value: Double): Double = floor(value * 100.0 + 0.5) / 100.0

private fun skillXpThreshold(skillName: String, level: Int): Long {
    val safeLevel = level.coerceAtLeast(1)
    val combatSkills = setOf("Двуручное оружие", "Одноручное оружие", "Дальний бой", "Блокирование")
    if (skillName !in combatSkills) return 100L * safeLevel
    val exponent = safeLevel - 1
    return if (exponent >= 56) Long.MAX_VALUE else 200L shl exponent
}
private fun limitTwoDecimals(raw: String): String {
    val normalized = raw.replace(',', '.')
    val dot = normalized.indexOf('.')
    if (dot < 0) return normalized.filter { it.isDigit() }
    val whole = normalized.substring(0, dot).filter { it.isDigit() }
    val fraction = normalized.substring(dot + 1).filter { it.isDigit() }
    if (fraction.length <= 2) return whole + "." + fraction
    val parsed = (whole.ifBlank { "0" } + "." + fraction).toDoubleOrNull() ?: return whole + "." + fraction.take(2)
    return format2(round2(parsed)).replace(',', '.')
}
private fun format2(value: Double): String = "%.2f".format(round2(value))

private fun rankedDefense(baseDefense: Double, rank: Int): Double =
    ceil(baseDefense.coerceAtLeast(0.0) * 1.5.pow(rank.coerceAtLeast(0)))

private fun rankedDamage(baseMin: Double, baseMax: Double, rank: Int): Pair<Double, Double> {
    var currentMin = ceil(baseMin.coerceAtLeast(0.0))
    var currentMax = ceil(baseMax.coerceAtLeast(currentMin))
    for (step in 1..rank.coerceAtLeast(0)) {
        val previousRatio = (currentMin / currentMax.coerceAtLeast(1.0)).coerceIn(0.000001, 1.0)
        val compression = (1.0 + 0.25 * (step - 1)) / (1.0 + 0.25 * step)
        val nextMax = ceil(currentMax * 1.5)
        val nextMin = ceil(nextMax * previousRatio.pow(compression))
        currentMin = nextMin
        currentMax = nextMax
    }
    return currentMin to currentMax
}

private data class Tool(
    val name: String,
    val image: String,
    val description: String,
    val requirements: List<String>,
    val rankNames: List<String> = List(7) { name },
    val rankDescriptions: List<String> = List(7) { description }
)

private val forgeTool = Tool(
    "Кузница",
    "https://images.pexels.com/photos/12841912/pexels-photo-12841912.jpeg?auto=compress&cs=tinysrgb&w=900",
    "Основное место нагрева и плавки металлов. Не входит в пять основных инструментов кузнеца.",
    listOf("Вместимость и максимальная температура зависят от уровня печи"),
    listOf("Маленькая глиняная печь", "Укреплённая кирпичная печь", "Каменная кузнечная печь", "Большая кузнечная печь", "Профессиональная кузнечная печь", "Совершенная печь кузнечного мастера", "Легендарная руническая кузница"),
    listOf("Простая печь. Вместимость: 5 кг. Максимальная температура: 300 °C.", "Укреплённая печь. Вместимость: 7 кг. Максимальная температура: 500 °C.", "Каменная печь. Вместимость: 10 кг. Максимальная температура: 700 °C.", "Большая печь. Вместимость: 13 кг. Максимальная температура: 1000 °C.", "Профессиональная печь. Вместимость: 17 кг. Максимальная температура: 1500 °C.", "Совершенная печь. Вместимость: 22 кг. Максимальная температура: 2000 °C.", "Легендарная руническая кузница. Вместимость: 28 кг. Максимальная температура: 3000 °C.")
)

private val bedTool = Tool(
    "Кровать",
    "https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=900",
    "Место для отдыха и восстановления выносливости.",
    listOf("Сон: 8 часов", "Восстановление ОВ зависит от ранга"),
    listOf("Неудобная старая кровать", "Улучшенная кожаная кровать", "Хорошая кровать", "Мягкая кровать", "Комфортная кровать", "Очень удобная кровать", "Царское ложе"),
    listOf("Восстанавливает 100 ОВ за сон.", "Восстанавливает 150 ОВ за сон.", "Восстанавливает 200 ОВ за сон.", "Восстанавливает 300 ОВ за сон.", "Восстанавливает 400 ОВ за сон.", "Восстанавливает 500 ОВ за сон.", "Восстанавливает 1000 ОВ за сон.")
)

private val chestTool = Tool(
    "Сундук",
    "https://images.pexels.com/photos/1666065/pexels-photo-1666065.jpeg?auto=compress&cs=tinysrgb&w=900",
    "Хранилище предметов. Вместимость увеличивается с рангом.",
    listOf("Вместимость зависит от ранга сундука"),
    listOf("Маленький сундук", "Небольшой сундук", "Средний сундук", "Большой сундук", "Огромный сундук", "Гигантский сундук", "Легендарный сундук"),
    listOf("Вместимость: 5 ячеек.", "Вместимость: 10 ячеек.", "Вместимость: 15 ячеек.", "Вместимость: 20 ячеек.", "Вместимость: 25 ячеек.", "Вместимость: 35 ячеек.", "Вместимость: 50 ячеек.")
)

private val blacksmithTools = listOf(
    Tool(
        "Наковальня с кузнечными клещами",
        "https://images.pexels.com/photos/5846089/pexels-photo-5846089.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Единый комплект для ковки и удержания заготовок. Наковальня и клещи улучшаются вместе.",
        listOf("Навык: кузнечное дело 1 уровня"),
        listOf("Ржавая наковальня с клещами", "Железная наковальня с клещами", "Стальная наковальня с клещами", "Кобальтовая наковальня с клещами", "Наковальня из чёрного железа с клещами", "Наковальня из титанового сплава с клещами", "Наковальня из звёздного железа с клещами"),
        listOf(
            "Старая железная наковальня с неровной поверхностью и ржавыми клещами с плохим захватом. Подходит для простейшей ковки.",
            "Железная наковальня с ровной рабочей поверхностью и надёжными клещами. Подходит для изготовления базового оружия и экипировки.",
            "Прочная стальная конструкция, выдерживающая сильные удары. Позволяет точнее обрабатывать металлические заготовки.",
            "Твёрдая рабочая поверхность и прочные клещи. Подходит для обработки тяжёлых и твёрдых заготовок.",
            "Массивный комплект с высокой прочностью и хорошей совместимостью с рунической энергией.",
            "Лёгкая и исключительно прочная конструкция, обеспечивающая точную обработку сложных заготовок.",
            "Редкий комплект из внеземного металла с необычными свойствами. Обеспечивает исключительную точность и стабильность ковки."
        )
    ),
    Tool(
        "Кузнечный молот",
        "https://images.pexels.com/photos/19460423/pexels-photo-19460423.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Основной инструмент кузнеца для придания формы раскалённому металлу.",
        listOf("Сила: 5"),
        listOf("Ржавый кузнечный молот", "Примитивный кузнечный молот", "Усиленный кузнечный молот", "Мастерский кузнечный молот", "Рунический кузнечный молот", "Титановый кузнечный молот", "Молот стихийного мастерства"),
        listOf(
            "Старая железная головка с ржавчиной и грубой рукоятью из обычного дерева. Имеет плохой баланс и неровную ударную поверхность.",
            "Простой железный молот с рукоятью из обычного дерева. Подходит для базовой ковки и изготовления простых изделий.",
            "Стальная головка и дубовая рукоять обеспечивают хорошую прочность и стабильность при ударах.",
            "Кобальтовая головка и рукоять из железного дерева позволяют работать с твёрдыми металлическими заготовками.",
            "Головка из чёрного железа и рукоять из магического дерева обеспечивают хорошую проводимость рунической энергии.",
            "Головка из титанового сплава и титановая рукоять с кожаной намоткой. Отличается высокой прочностью, малым весом и превосходным балансом.",
            "Головка из звёздного железа и рукоять из древа стихий. Обладает высокой прочностью и способностью взаимодействовать с различными элементальными энергиями."
        )
    ),
    Tool(
        "Кузнечный верстак",
        "https://images.pexels.com/photos/32979598/pexels-photo-32979598.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Рабочее место для фиксации, измерения и сборки металлических деталей.",
        listOf("Навык: кузнечное дело 1 уровня"),
        listOf("Старый кузнечный верстак", "Укреплённый кузнечный верстак", "Профессиональный кузнечный верстак", "Усиленный кузнечный верстак", "Мастерский кузнечный верстак", "Совершенный верстак кузнечного мастера", "Верстак великого кузнечного мастера"),
        listOf(
            "Старый деревянный стол с потёртой поверхностью и простыми деревянными упорами. Подходит для размещения небольших заготовок и ручной работы.",
            "Прочная деревянная конструкция с усиленной столешницей и кузнечными тисками. Удобен для фиксации небольших деталей и сборки простых изделий.",
            "Массивная столешница с металлическими креплениями, тисками и набором кузнечных струбцин. Позволяет надёжно фиксировать детали во время сборки.",
            "Стальная рама, толстая рабочая поверхность, тиски, струбцины и поворотный зажим. Позволяет закреплять заготовки под нужным углом.",
            "Прочная конструкция с точной системой фиксации, струбцинами и ручной сверлильной стойкой. Подходит для крупных и сложных заготовок.",
            "Высококачественная рабочая поверхность, усиленная рама, точные механизмы фиксации и механический измерительный калибр. Обеспечивает высокую точность сборки.",
            "Легендарная рабочая станция с идеальной системой фиксации, измерительными приспособлениями, сверлильной оснасткой и универсальным механическим манипулятором. Предназначена для изделий высочайшего качества."
        )
    ),
    Tool(
        "Точильный камень",
        "https://images.pexels.com/photos/5845914/pexels-photo-5845914.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Оборудование для заточки и доводки режущей кромки.",
        listOf("Ловкость: 5"),
        listOf("Простой точильный камень", "Механический точильный круг", "Усиленный точильный станок", "Профессиональный точильный станок", "Мастерская точильная установка", "Рунический точильный станок", "Автоматический рунический точильный комплекс"),
        listOf(
            "Обычный камень на деревянной подставке. Заточка выполняется вручную и требует постоянного контроля угла и давления.",
            "Каменный круг с ножным приводом. Поддерживает равномерное вращение и ускоряет заточку, освобождая руки мастера.",
            "Прочная металлическая конструкция с улучшенным приводом и двумя точильными кругами разной зернистости. Позволяет выполнять грубую обработку и чистовую заточку.",
            "Оснащён регулируемыми упорами и механизмом фиксации изделия. Помогает выдерживать одинаковый угол и получать ровную режущую кромку.",
            "Установка со сменными абразивными кругами, системой подачи охлаждающей жидкости и регулируемой скоростью вращения. Подходит для высокопрочных металлов.",
            "Высокоточная установка с руническим приводом. Руны стабилизируют вращение, регулируют скорость и помогают поддерживать постоянное давление.",
            "Легендарная установка с автоматической фиксацией изделия, определением угла, регулировкой давления и скорости, сменой абразивных кругов и системой охлаждения. Мастеру остаётся установить изделие и задать параметры."
        )
    )
)

private val craftTools = listOf(
    Tool(
        "Примитивная деревянная рама",
        "https://images.pexels.com/photos/6068960/pexels-photo-6068960.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Рама из необработанной сосны с простой верёвочной системой. Подходит для первичной растяжки и сушки кожи, но прогибается под натяжением.",
        listOf("Комната закрыта"),
        listOf("Примитивная деревянная рама", "Укреплённая рама кожевника", "Прочная дубовая рама", "Усиленная кожевенная конструкция", "Мастерская рама кожевника", "Совершенная рама мастера", "Легендарная рама великого ремесленника"),
        listOf(
            "Рама из необработанной сосны с простой верёвочной системой. Подходит для первичной растяжки и сушки кожи, но прогибается под натяжением.",
            "Рама из обработанной сосны с укреплёнными соединениями. Подходит для равномерной растяжки и сушки кожи.",
            "Прочная дубовая рама с железными креплениями. Подходит для надёжной фиксации кожи и равномерного натяжения.",
            "Конструкция из выдержанного ясеня со стальными креплениями. Подходит для точной растяжки и стабильной сушки кожи.",
            "Верстачная рама из клеёной твёрдой древесины с коваными стальными деталями. Подходит для обработки крупных шкур и точного контроля натяжения.",
            "Рама из отборной клеёной древесины и высококачественной стали. Подходит для равномерной обработки кожи без перекосов.",
            "Легендарная рама из редкой чёрной древесины и легендарного сплава с исключительной жёсткостью и системой натяжения. Подходит для обработки кожи высочайшего качества."
        )
    ),
    Tool(
        "Грубое шило",
        "https://images.pexels.com/photos/4210860/pexels-photo-4210860.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Шило с деревянной рукоятью и грубым железным остриём. Подходит для прокалывания кожи и выполнения простых неровных швов.",
        listOf("Комната закрыта"),
        listOf("Грубое шило", "Шило с иглами для шитья", "Улучшенное шило с набором игл", "Кожевенное шило с иглами мастера", "Мастерский набор шила и игл", "Совершенный набор для шитья", "Легендарный набор великого кожевника"),
        listOf(
            "Шило с деревянной рукоятью и грубым железным остриём. Подходит для прокалывания кожи и выполнения простых неровных швов.",
            "Шило с обработанной рукоятью, стальным остриём и простыми иглами. Подходит для более ровных отверстий и аккуратных швов.",
            "Шило из твёрдой древесины с закалённым стальным остриём и набором игл. Подходит для равномерных отверстий и плотных швов.",
            "Кожевенное шило с прочной полированной рукоятью и качественными стальными иглами. Подходит для аккуратных проколов и плотных ровных швов.",
            "Набор из отборной древесины и инструментальной стали. Подходит для мелких равномерных стежков и стабильного натяжения нити.",
            "Набор из редкой твёрдой древесины и высококачественной легированной стали. Подходит для почти незаметных швов и двойной строчки.",
            "Полный набор из легендарного сплава, качественной древесины и специальных игл. Подходит для тончайших ровных швов и прочной двойной строчки."
        )
    ),
    Tool(
        "Простой нож для отделки кожи",
        "https://images.pexels.com/photos/4226876/pexels-photo-4226876.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Нож из обычной стали с деревянной рукоятью. Подходит для обрезки неровностей и грубой отделки кожаных краёв.",
        listOf("Комната закрыта"),
        listOf("Простой нож для отделки кожи", "Нож с инструментом для обработки кромок", "Набор для раскроя и обработки кромок", "Кожевенный набор с полировщиком", "Профессиональный набор отделочника", "Совершенный набор кожевенного мастера", "Легендарный набор мастера отделки"),
        listOf(
            "Нож из обычной стали с деревянной рукоятью. Подходит для обрезки неровностей и грубой отделки кожаных краёв.",
            "Нож из улучшенной стали с рукоятью из твёрдой древесины и простым инструментом для снятия фаски. Подходит для аккуратной обрезки и начальной обработки кромок.",
            "Набор из закалённого ножа, инструмента для снятия фаски и канавкореза. Подходит для раскроя кожи, формирования кромок и декоративных канавок.",
            "Набор из инструментальной стали и полированной древесины с полировщиком кромок и шлифовальными принадлежностями. Подходит для сглаживания и полировки кожаных краёв.",
            "Профессиональный набор с ножом для утончения кожи, инструментами для кромок и полировки. Подходит для тонкой подгонки толщины и качественной отделки.",
            "Совершенный набор из легированной стали и отборной древесины с аппликатором краски для кромок, тонкой шлифовкой и финишной полировкой. Подходит для безупречной отделки.",
            "Полный легендарный комплект для раскроя, утончения, обработки кромок, шлифовки, окрашивания и полировки кожи. Подходит для отделки высочайшего качества."
        )
    ),
    Tool(
        "Грубый скобель",
        "https://images.pexels.com/photos/5845914/pexels-photo-5845914.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Скобель с деревянными рукоятями и грубым железным лезвием. Подходит для снятия коры и первичной грубой обработки древесины.",
        listOf("Комната закрыта"),
        listOf("Грубый скобель", "Простой рубанок", "Рубанок и рашпиль", "Набор деревообработчика", "Профессиональный набор деревообработчика", "Совершенный набор мастера", "Легендарный набор великого мастера"),
        listOf(
            "Скобель с деревянными рукоятями и грубым железным лезвием. Подходит для снятия коры и первичной грубой обработки древесины.",
            "Рубанок с деревянным корпусом и железным лезвием. Подходит для выравнивания поверхности древесины и придания заготовкам простой формы.",
            "Рубанок и металлический рашпиль с деревянной рукоятью. Подходят для выравнивания поверхностей, снятия неровностей и обработки закруглённых участков.",
            "Рубанок, рашпиль и набор стамесок разных размеров. Подходят для точной обработки древесины, создания пазов, углублений и сложных форм.",
            "Инструменты из качественной стали с прочными рукоятями. Подходят для точной подгонки деталей и получения гладкой поверхности.",
            "Высококачественные рубанок, рашпиль и стамески с точной заточкой. Подходят для тонкой обработки, сложной резьбы и идеальной подгонки деталей.",
            "Инструменты из редких материалов с безупречной обработкой и заточкой. Подходят для создания сложнейших деревянных изделий с исключительной точностью и качеством поверхности."
        )
    ),
    Tool(
        "Простой деревянный верстак",
        "https://images.pexels.com/photos/32979598/pexels-photo-32979598.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Грубый деревянный стол с простыми деревянными тисками. Подходит для закрепления небольших заготовок и выполнения простых работ.",
        listOf("Комната закрыта"),
        listOf("Простой деревянный верстак", "Укреплённый столярный верстак", "Столярный верстак с оснасткой", "Крепкий столярный верстак", "Профессиональный верстак", "Совершенный верстак столярного мастера", "Легендарный верстак великого ремесленника"),
        listOf(
            "Грубый деревянный стол с простыми деревянными тисками. Подходит для закрепления небольших заготовок и выполнения простых работ.",
            "Прочная столешница, улучшенные тиски и набор ручных струбцин. Подходит для надёжной фиксации деталей и сборки деревянных изделий.",
            "Усиленные тиски, упоры, струбцины, угольник и разметочный рейсмус. Подходит для точной разметки, подгонки и обработки заготовок.",
            "Массивная столешница, металлические тиски, упоры, струбцины, ручная дрель и набор свёрл. Подходит для сверления отверстий и точной сборки конструкций.",
            "Усиленная конструкция, две системы тисков, набор струбцин, ручная дрель со свёрлами, разметочные инструменты и приспособления для соединения деталей. Подходит для изготовления сложных изделий.",
            "Столешница из отборной древесины, точные металлические тиски, направляющие, набор свёрл, ручные зажимы, измерительные инструменты и приспособления для сложных соединений. Подходит для ювелирно точной сборки.",
            "Легендарная столешница, совершенная система тисков и фиксаторов, полный комплект измерительных и сверлильных инструментов, специальные приспособления для сложных соединений. Подходит для создания изделий высочайшего качества."
        )
    )
)

private val runeTools = listOf(
    Tool("Рукоять для гравировки", "https://images.pexels.com/photos/5974300/pexels-photo-5974300.jpeg?auto=compress&cs=tinysrgb&w=900", "Ручной инструмент для нанесения рун.", listOf("Комната закрыта")),
    Tool("Набор гравировальных резцов", "https://images.pexels.com/photos/5974301/pexels-photo-5974301.jpeg?auto=compress&cs=tinysrgb&w=900", "Резцы для рун разных форм.", listOf("Комната закрыта")),
    Tool("Гравировальные тиски", "https://images.pexels.com/photos/5974302/pexels-photo-5974302.jpeg?auto=compress&cs=tinysrgb&w=900", "Фиксация предмета при гравировке.", listOf("Комната закрыта")),
    Tool("Полировальные камни", "https://images.pexels.com/photos/5974303/pexels-photo-5974303.jpeg?auto=compress&cs=tinysrgb&w=900", "Полировка рунических линий.", listOf("Комната закрыта")),
    Tool("Глубиномер гравировки", "https://images.pexels.com/photos/5974304/pexels-photo-5974304.jpeg?auto=compress&cs=tinysrgb&w=900", "Контроль глубины нанесения рун.", listOf("Комната закрыта"))
)
private val rankNames = listOf("F", "E", "D", "C", "B", "A", "S")
private data class FieldMonster(
    val name: String, val rank: String, val level: Int, val hp: Int, val minAttack: Int, val maxAttack: Int,
    val defense: Double, val speed: Int, val goldMin: Int, val goldMax: Int, val xp: Int, val loot: List<String>, val ov: Int = 20,
    val phase2HpThreshold: Double? = null, val phase2AttackMultiplier: Double = 1.0,
    val phase2SpeedBonus: Int = 0, val phase2DefenseBonus: Double = 0.0
)

private data class DamageNumber(val id: Long, val value: String, val x: Float, val y: Float)

private fun forestMonster(name: String, level: Int): FieldMonster = when (name) {
    "Кабан" -> FieldMonster(name,"F",level,150+10*level,20,25+2*level,(2.5+0.5*level).toDouble(),5,3,7,40+5*level,listOf("Кожа F 4 кг","Костный нарост F 1 шт."))
    "Малый волк" -> FieldMonster(name,"F",level,120+10*level,30,40+2*level,(1+0.5*level).toDouble(),10,9,15,50+2*level,listOf("Шкура F 3 кг","Клыки волка F 1 шт."))
    "Волк" -> FieldMonster(name,"E",level,140+12*level,38+2*level,50+(2.5*level).toInt(),(5+level).toDouble(),15,20,38,100+3*level,listOf("Шкура E 6 кг","Клыки волка F 1 шт."))
    else -> FieldMonster("Лесной паук","E",level,160+13*level,50+(2.5*level).toInt(),70+(2.7*level).toInt(),(3+1.5*level).toDouble(),18,25,40,120+3*level,listOf("Шёлк паука E 6 шт.","Хитин E 8 шт."))
}

private fun itemIconRes(item: Item): Int? {
    val n=item.name.lowercase()
    return when {
        n.startsWith("ядро силы") -> R.drawable.core_str
        n.startsWith("ядро ловкости") -> R.drawable.core_agi
        n.startsWith("ядро интеллекта") -> R.drawable.core_int
        n.startsWith("ядро выносливости") -> R.drawable.core_end
        n.startsWith("ядро удачи") -> R.drawable.core_luk
        n.contains("обычн") && n.contains("дерев") || n.contains("обычное дерево") -> R.drawable.icon_wood_ordinary_f
        n.contains("дуб") -> R.drawable.icon_wood_oak_e
        n.contains("железн") && n.contains("дерев") -> R.drawable.icon_wood_iron_d
        n.contains("магическ") && n.contains("дерев") -> R.drawable.icon_wood_magical_b
        (n.contains("дерев") || n.contains("древ")) && n.contains("жизни") -> R.drawable.icon_wood_life_a
        (n.contains("дерев") || n.contains("древ")) && n.contains("ман") -> R.drawable.icon_wood_mana_a
        n.contains("стих") && (n.contains("дерев") || n.contains("древ")) -> R.drawable.icon_wood_elemental_s
        n.contains("пустот") && (n.contains("дерев") || n.contains("древ")) -> R.drawable.icon_wood_void_ss
        n.contains("миров") && (n.contains("дерев") || n.contains("древ")) -> R.drawable.icon_wood_world_sss
        n.contains("древесин") || n.contains("дерево f") -> R.drawable.icon_wood_ordinary_f
        n.contains("желез") && (n.contains("руда") || n.contains("слиток") || n.contains("металл") || n.contains("железо")) -> if(n.contains("руд")) R.drawable.icon_ore_iron_f else R.drawable.icon_metal_iron_f
        n.contains("серебр") -> if(n.contains("руд")) R.drawable.icon_ore_silver_e else R.drawable.icon_metal_silver_e
        n.contains("золот") -> if(n.contains("руд")) R.drawable.icon_ore_gold_d else R.drawable.icon_metal_gold_d
        n.contains("титан") -> if(n.contains("руд")) R.drawable.icon_ore_titan_d else R.drawable.icon_metal_titan_d
        n.contains("платин") -> if(n.contains("руд")) R.drawable.icon_ore_platina_c else R.drawable.icon_metal_platina_c
        n.contains("орихалк") -> if(n.contains("руд")) R.drawable.icon_ore_orichalcum_b else R.drawable.icon_metal_orichalcum_b
        n.contains("адамант") -> if(n.contains("руд")) R.drawable.icon_ore_adamant_a else R.drawable.icon_metal_adamant_a
        n.contains("мифрил") -> if(n.contains("руд")) R.drawable.icon_ore_mithril_s else R.drawable.icon_metal_mithril_s
        n.contains("дракон") && (n.contains("сталь") || n.contains("руда")) -> if(n.contains("руд")) R.drawable.icon_ore_dragon_ss else R.drawable.icon_metal_dragon_ss
        n.contains("бездна") || n.contains("бездны") || n.contains("руда бездны") -> if(n.contains("руд")) R.drawable.icon_ore_abyss_sss else R.drawable.icon_metal_abyss_sss
        n.contains("бурый уголь") -> R.drawable.icon_coal_brown
        n.contains("каменный уголь") -> R.drawable.icon_coal_stone
        n.contains("крепкий уголь") -> R.drawable.icon_coal_strong
        n.contains("чистый уголь") -> R.drawable.icon_coal_clean
        n.contains("сердце вулкана") -> R.drawable.icon_coal_volcano_heart
        else -> null
    }
}

private fun monsterIconRes(name:String):Int? = when(name) {
    "Кабан" -> R.drawable.icon_monster_boar_f
    "Малый волк" -> R.drawable.icon_monster_little_wolf_f
    "Волк" -> R.drawable.icon_monster_wolf_e
    "Лесной паук" -> R.drawable.icon_monster_forest_spider_e
    "Слизень" -> R.drawable.icon_monster_slime_f
    else -> null
}

@Composable
private fun ItemIcon(item:Item?, modifier:Modifier=Modifier) {
    val res=item?.let(::itemIconRes)
    if(res!=null) Image(painterResource(res),contentDescription=item?.name,modifier=modifier)
    else Icon(Icons.Default.Inventory2,contentDescription=item?.name,tint=goldColor,modifier=modifier)
}

private fun migrateArmorName(name: String): String {
    val rank = name.substringAfterLast(" ", "")
    val base = name.substringBeforeLast(" ", name)
    val migrated = when (base) {
        "Кольчуга" -> "Кольчужная рубаха"
        "Кольчужные нарукавники" -> "Кольчужные наручи"
        "Нагрудник" -> "Латная кираса"
        "Наплечники" -> "Латная кираса"
        "Латный нагрудник" -> "Латная кираса"
        "Латные наплечники" -> "Латная кираса"
        "Двуручный молот" -> "Боевой молот"
        "Перчатки" -> "Латные рукавицы"
        "Поножи" -> "Латные поножи"
        "Усиленные сапоги" -> "Латные сапоги"
        "Латные доспехи" -> "Латная кираса"
        else -> base
    }
    return if (migrated != base && rank in listOf("F","E","D","C","B","A","S","SS","SSS")) "$migrated $rank" else name
}

private data class Item(
    val id: Int, val name: String, val description: String, val amount: Double,
    val unit: String, val weightEach: Double, val price: Int = 0,
    val equipmentSlot: String? = null, val equipped: Boolean = false, val stackTag: String = "",
    val minDamage: Double = 0.0, val maxDamage: Double = 0.0,
    val damageType: String = "", val weaponGrip: String = "", val defenseValue: Double = 0.0,
    val attackBonus: Double = 0.0, val speedBonus: Double = 0.0,
    val strengthBonus: Double = 0.0, val agilityBonus: Double = 0.0, val intelligenceBonus: Double = 0.0,
    val enduranceBonus: Double = 0.0, val luckBonus: Double = 0.0, val spellDamageBonus: Double = 0.0,
    val durability: Double = 0.0, val maxDurability: Double = 0.0, val minPrice: Int = 0
)

// Единое описание занятых ячеек экипировки. Для новых предметов список можно
// расширять, не меняя обработчики надевания в разных частях интерфейса.
private fun sameItemIdentity(a: Item, b: Item): Boolean = a.id == b.id && a.name == b.name && a.unit == b.unit

private fun workCraftBonusPercent(name: String): Double = when (equipmentBaseName(name)) {
    "Кузнечный молот", "Полумаска кузнеца", "Фартук кузнеца" -> 5.0
    else -> 0.0
}

/** Общий обработчик надевания: меню предмета и экран персонажа используют одну проверку. */
private fun equipFromInventory(
    inventory: MutableList<Item>, equipment: MutableMap<String, Item>, item: Item,
    preferredSlot: String? = null, requestedAmount: Double = 1.0
): Boolean {
    val index = inventory.indexOfFirst { sameItemIdentity(it, item) }
    if (index < 0) return false
    val source = inventory[index]
    if (source.equipmentSlot == null || source.amount < 1.0) return false
    val stackableSlot = source.equipmentSlot.startsWith("Зелье") || source.equipmentSlot == "Стрелы"
    val equipCount = if (stackableSlot) ceil(requestedAmount).coerceIn(1.0, source.amount) else 1.0
    val slots = equipmentSlotsFor(source, preferredSlot, equipment)
    if (slots.isEmpty() || slots.any { equipment[it] != null }) return false
    val wornId = (inventory.map { it.id } + equipment.values.map { it.id }).maxOrNull()?.plus(1) ?: 1
    if (source.amount > equipCount) inventory[index] = source.copy(amount = round2(source.amount - equipCount)) else inventory.removeAt(index)
    val worn = source.copy(id = wornId, amount = equipCount, equipped = true)
    slots.forEach { equipment[it] = worn.copy(equipmentSlot = it) }
    return true
}

private fun unequipToInventory(inventory: MutableList<Item>, equipment: MutableMap<String, Item>, item: Item): Boolean {
    val worn = equipment.values.firstOrNull { sameItemIdentity(it, item) } ?: return false
    equipment.entries.removeAll { sameItemIdentity(it.value, worn) }
    addToStack(inventory, worn.copy(equipped = false, equipmentSlot = if (worn.equipmentSlot?.startsWith("Оружие") == true) "Оружие 1" else worn.equipmentSlot))
    return true
}

private fun equipmentSlotsFor(item: Item, preferredSlot: String? = null, equipment: Map<String, Item> = emptyMap()): List<String> {
    return when (equipmentBaseName(item.name)) {
        "Латная кираса" -> listOf("Тело", "Наплечники", "Наплечники 2")
        "Кольчужные наручи" -> listOf("Перчатки", "Наплечники", "Наплечники 2")
        "Кольчужные поножи" -> listOf("Поножи", "Ступни")
        "Латные наплечники" -> listOf("Наплечники", "Наплечники 2")
        "Коромысло", "Стремянка" -> listOf(preferredSlot?.takeIf { it in listOf("Наплечники", "Наплечники 2") && equipment[it] == null }
            ?: if (equipment["Наплечники"] == null) "Наплечники" else "Наплечники 2")
        else -> if (item.equipmentSlot?.startsWith("Оружие") == true) {
            if (item.weaponGrip == "Двуручное") listOf("Оружие 1", "Оружие 2")
            else {
                val target = preferredSlot?.takeIf { it in listOf("Оружие 1", "Оружие 2") && equipment[it] == null }
                    ?: if (equipment["Оружие 1"] == null) "Оружие 1" else "Оружие 2"
                listOf(target)
            }
        } else if (item.equipmentSlot?.startsWith("Кольцо") == true || item.equipmentSlot?.startsWith("Зелье") == true) {
            listOf(preferredSlot ?: item.equipmentSlot!!)
        } else listOf(item.equipmentSlot ?: preferredSlot ?: return emptyList())
    }
}

private fun displayedAttackRange(equipment:Map<String,Item>,stats:Map<String,Int>,skillLevels:Map<String,Int>): Pair<Int,Int> {
    val weapons=equipment.values.distinctBy{it.id}.filter{it.damageType.isNotBlank()}
    val strength=(stats["Сила"]?:5)+equipment.values.distinctBy{it.id}.sumOf{it.strengthBonus}.toInt()+if(weapons.isNotEmpty())1 else 0
    val agility=(stats["Ловкость"]?:5)+equipment.values.distinctBy{it.id}.sumOf{it.agilityBonus}.toInt()
    if(weapons.isEmpty()){val value=2*strength+agility;return value to value}
    val primary=equipment["Оружие 1"]?.takeIf{it.damageType.isNotBlank()} ?: equipment["Оружие 2"]?.takeIf{it.damageType.isNotBlank()} ?: weapons.first()
    if(primary.damageType.contains("маг", ignoreCase=true)) return 0 to 0
    val secondarySlot=if(equipment["Оружие 1"]?.id==primary.id) "Оружие 2" else "Оружие 1"
    val secondary=if(primary.weaponGrip=="Двуручное")null else equipment[secondarySlot]?.takeIf{it.id!=primary.id && it.damageType.isNotBlank() && !it.damageType.contains("маг",true)}
    val skill=if(primary.weaponGrip=="Двуручное")"Двуручное оружие" else "Одноручное оружие"
    val multiplier=.98+.02*(skillLevels[skill]?:1).coerceAtLeast(1)
    val statBonus=when(primary.damageType){"Дробящий"->2.0*strength;"Рубящий"->3.0*strength+agility;"Колющий"->2.0*agility;else->2.0*strength+agility}
    val weaponMin = primary.minDamage * effectiveWeaponMultiplier(primary) + (secondary?.let { it.minDamage * effectiveWeaponMultiplier(it) } ?: 0.0)
    val weaponMax = primary.maxDamage * effectiveWeaponMultiplier(primary) + (secondary?.let { it.maxDamage * effectiveWeaponMultiplier(it) } ?: 0.0)
    val min=((weaponMin+statBonus)*multiplier).toInt().coerceAtLeast(1)
    val max=((weaponMax+statBonus)*multiplier).toInt().coerceAtLeast(min)
    return min to max
}

private val durabilityRankOrder = listOf("F", "E", "D", "C", "B", "A", "S", "SS", "SSS")

private fun equipmentBaseName(name: String): String =
    if (name.substringAfterLast(" ") in durabilityRankOrder) name.substringBeforeLast(" ") else name

private fun baseArmorDurability(name: String): Double = when (equipmentBaseName(name)) {
    "Кожаный шлем" -> 80.0
    "Кожаный нагрудник" -> 120.0
    "Кожаный плащ" -> 70.0
    "Кожаные перчатки" -> 70.0
    "Кожаные штаны" -> 100.0
    "Кожаные сапоги" -> 80.0
    "Кольчужный шлем" -> 120.0
    "Кольчужная рубаха" -> 180.0
    "Кольчужные наручи" -> 140.0
    "Кольчужные поножи" -> 180.0
    "Латный шлем" -> 160.0
    "Латная кираса" -> 400.0
    "Латный нагрудник" -> 240.0
    "Латные наплечники" -> 160.0
    "Латные рукавицы" -> 120.0
    "Латные поножи" -> 200.0
    "Латные сапоги" -> 120.0
    "Ведро" -> 90.0
    "Бочка" -> 180.0
    "Мешок" -> 110.0
    "Деревянные башмаки" -> 120.0
    "Рукавицы" -> 70.0
    "Коромысло" -> 120.0
    "Стремянка" -> 200.0
    else -> 0.0
}

private fun baseWeaponDurability(name: String): Double = when (equipmentBaseName(name)) {
    "Кинжал" -> 100.0
    "Топор" -> 160.0
    "Секира" -> 180.0
    "Копьё" -> 130.0
    "Длинный меч" -> 150.0
    "Двуручный меч" -> 200.0
    "Кузнечный молот" -> 180.0
    "Боевой молот", "Двуручный молот" -> 220.0
    "Кирка" -> 200.0
    "Лук" -> 100.0
    "Дубинка" -> 120.0
    "Боевой посох" -> 140.0
    "Рогатка" -> 80.0
    "Бумеранг" -> 100.0
    "Скалка" -> 110.0
    "Метла" -> 80.0
    "Сковорода" -> 150.0
    "Вилы" -> 160.0
    "Деревянный щит" -> 120.0
    "Металлический щит" -> 220.0
    "Тяжёлый металлический щит" -> 300.0
    else -> 0.0
}

private fun baseItemDurability(name: String): Double =
    baseArmorDurability(name).takeIf { it > 0.0 } ?: baseWeaponDurability(name)

private fun savedItemMaxDurability(name: String): Double {
    val rankNames = listOf("F", "E", "D", "C", "B", "A", "S", "SS", "SSS")
    val rank = rankNames.indexOf(name.substringAfterLast(" ")).coerceAtLeast(0)
    return ceil(baseItemDurability(name) * 1.5.pow(rank))
}

private fun effectiveDefense(item: Item): Double {
    if (item.defenseValue <= 0.0 || item.maxDurability <= 0.0) return item.defenseValue
    val ratio = (item.durability / item.maxDurability).coerceIn(0.0, 1.0)
    val penalty = when {
        ratio >= 0.51 -> 0.0
        ratio >= 0.26 -> 0.25
        ratio > 0.0 -> 0.375
        else -> 0.50
    }
    return item.defenseValue * (1.0 - penalty)
}

private fun shieldBaseBlockChance(item: Item): Double = when (equipmentBaseName(item.name)) {
    "Деревянный щит" -> 20.0
    "Металлический щит" -> 30.0
    "Тяжёлый металлический щит" -> 40.0
    else -> 0.0
}

/** Шанс блока повторяет ступени снижения защиты щита при износе. */
private fun effectiveShieldBlockChance(item: Item): Double {
    val base = shieldBaseBlockChance(item)
    if (base <= 0.0 || item.maxDurability <= 0.0) return 0.0
    val ratio = (item.durability / item.maxDurability).coerceIn(0.0, 1.0)
    val multiplier = when { ratio >= 0.51 -> 1.0; ratio >= 0.26 -> 0.75; ratio > 0.0 -> 0.625; else -> 0.5 }
    return base * multiplier
}

private fun tryShieldBlock(equipment: MutableMap<String, Item>): Boolean {
    val shield = equipment.values.distinctBy { it.id }.firstOrNull { shieldBaseBlockChance(it) > 0.0 } ?: return false
    if (kotlin.random.Random.nextDouble(0.0, 100.0) >= effectiveShieldBlockChance(shield)) return false
    val updated = shield.copy(durability = (shield.durability - 1.0).coerceAtLeast(0.0))
    equipment.entries.toList().forEach { (slot, equipped) -> if (equipped.id == shield.id) equipment[slot] = updated.copy(equipmentSlot = slot) }
    return true
}

private fun itemRankIndex(item: Item): Int =
    durabilityRankOrder.indexOf(item.name.substringAfterLast(" ")).coerceAtLeast(0)

private fun monsterRankIndex(rank: String): Int = durabilityRankOrder.indexOf(rank).coerceAtLeast(0)

/** Снимает одну единицу прочности со случайной части брони, сохраняя разброс износа в пределах 10 п.п. */
private fun damageOneArmorPoint(equipment: MutableMap<String, Item>, allowedIds: Set<Int>? = null) {
    val armor = equipment.values.distinctBy { it.id }.filter {
        baseArmorDurability(it.name) > 0.0 && it.maxDurability > 0.0 && it.durability > 0.0 &&
            (allowedIds == null || it.id in allowedIds)
    }
    if (armor.isEmpty()) return

    fun wearPercent(item: Item, durability: Double = item.durability): Double =
        (1.0 - durability / item.maxDurability).coerceIn(0.0, 1.0) * 100.0

    val candidates = armor.filter { candidate ->
        val after = (candidate.durability - 1.0).coerceAtLeast(0.0)
        val projected = armor.map { item -> wearPercent(item, if (item.id == candidate.id) after else item.durability) }
        projected.maxOrNull()!! - projected.minOrNull()!! <= 10.000001
    }
    if (candidates.isEmpty()) return

    // Выбор остаётся случайным среди всех частей, для которых следующий пункт
    // износа не нарушит ограничение в 10 процентных пунктов.
    val chosen = candidates.random()
    val updated = chosen.copy(durability = (chosen.durability - 1.0).coerceAtLeast(0.0))
    equipment.entries.toList().forEach { (slot, item) ->
        if (item.id == chosen.id) equipment[slot] = updated.copy(equipmentSlot = slot)
    }
}

private fun damageArmorFromMonsterHit(equipment: MutableMap<String, Item>, monsterRank: String) {
    val enemyRank = monsterRankIndex(monsterRank)
    // Броня выше ранга противника не изнашивается. При комплекте одного ранга
    // это даёт ровно 1 + разницу рангов единиц прочности за попадание.
    val eligible = equipment.values.distinctBy { it.id }.filter {
        baseArmorDurability(it.name) > 0.0 && it.maxDurability > 0.0 && it.durability > 0.0 && itemRankIndex(it) <= enemyRank
    }
    if (eligible.isEmpty()) return
    val struckPiece = eligible.random()
    val damagePerHit = maxOf(0, 1 + enemyRank - itemRankIndex(struckPiece))
    val eligibleIds = eligible.map { it.id }.toSet()
    repeat(damagePerHit) { damageOneArmorPoint(equipment, eligibleIds) }
}

private fun effectiveWeaponMultiplier(item: Item): Double {
    if (item.damageType.isBlank() || item.maxDurability <= 0.0) return 1.0
    val ratio = (item.durability / item.maxDurability).coerceIn(0.0, 1.0)
    return when {
        ratio <= 0.0 -> 0.50
        ratio <= 0.50 -> 0.75
        else -> 1.0
    }
}

/** Износ одноручного оружия распределяется случайно; разница процента износа не более 10 п.п. */
private fun damageWeaponsAfterHits(equipment: MutableMap<String, Item>, weapons: List<Item>, successfulHits: Int) {
    if (successfulHits <= 0) return
    val active = weapons.distinctBy { it.id }.filter { it.damageType.isNotBlank() && it.maxDurability > 0.0 && it.durability > 0.0 }
    if (active.isEmpty()) return
    repeat(successfulHits) {
        val current = active.mapNotNull { original -> equipment.values.firstOrNull { it.id == original.id } }
            .distinctBy { it.id }.filter { it.durability > 0.0 }
        if (current.isEmpty()) return@repeat
        fun wear(item: Item, durability: Double = item.durability) =
            (1.0 - durability / item.maxDurability).coerceIn(0.0, 1.0) * 100.0
        val candidates = current.filter { candidate ->
            val after = (candidate.durability - 1.0).coerceAtLeast(0.0)
            val values = current.map { wear(it, if (it.id == candidate.id) after else it.durability) }
            values.maxOrNull()!! - values.minOrNull()!! <= 10.000001
        }
        val chosen = (candidates.ifEmpty { current }).random()
        val updated = chosen.copy(durability = (chosen.durability - 1.0).coerceAtLeast(0.0))
        equipment.entries.toList().forEach { (slot, item) ->
            if (item.id == chosen.id) equipment[slot] = updated.copy(equipmentSlot = slot)
        }
    }
}

private fun armorSpeedPenalty(name: String): Double = when (equipmentBaseName(name)) {
    "Кожаный шлем", "Кожаный нагрудник", "Кожаный плащ", "Кожаные перчатки", "Кожаные штаны", "Кожаные сапоги" -> -1.0
    "Кольчужный шлем" -> -2.0
    "Кольчужная рубаха" -> -4.0
    "Кольчужные наручи" -> -5.0
    "Кольчужные поножи" -> -4.0
    "Латный шлем" -> -5.0
    "Латная кираса" -> -30.0
    "Латный нагрудник" -> -20.0
    "Латные наплечники" -> -10.0
    "Латные рукавицы" -> -5.0
    "Латные поножи" -> -12.0
    "Латные сапоги" -> -8.0
    "Ведро" -> -2.0
    "Бочка" -> -6.0
    "Мешок" -> -3.0
    "Деревянные башмаки" -> -3.0
    "Рукавицы" -> -2.0
    "Коромысло" -> -4.0
    "Стремянка" -> -7.0
    else -> 0.0
}

private fun isFunnyEquipment(name: String): Boolean =
    equipmentBaseName(name) in setOf("Ведро", "Бочка", "Мешок", "Деревянные башмаки", "Рукавицы", "Коромысло", "Стремянка")

private fun itemWithEquipmentStats(id:Int,name:String,description:String,weight:Double,price:Int=0): Item {
    val baseName = equipmentBaseName(name)
    val data = when(baseName) {
        "Кожаный шлем" -> Triple("Голова",0.0,2.0)
        "Полумаска кузнеца" -> Triple("Голова",0.0,0.0)
        "Кожаный нагрудник" -> Triple("Тело",0.0,5.0)
        "Фартук кузнеца" -> Triple("Тело",0.0,0.0)
        "Кожаный плащ" -> Triple("Наплечники",0.0,1.0)
        "Кожаные перчатки" -> Triple("Перчатки",0.0,1.0)
        "Кожаные штаны" -> Triple("Поножи",0.0,3.0)
        "Кожаные сапоги" -> Triple("Ступни",0.0,1.0)
        "Ведро" -> Triple("Голова",0.0,2.0)
        "Бочка" -> Triple("Тело",0.0,5.0)
        "Мешок" -> Triple("Поножи",0.0,2.0)
        "Деревянные башмаки" -> Triple("Ступни",0.0,2.0)
        "Рукавицы" -> Triple("Перчатки",0.0,1.0)
        "Коромысло", "Стремянка" -> Triple("Наплечники",0.0,if(baseName=="Стремянка") 4.0 else 2.0)
        "Латный шлем" -> Triple("Голова",0.0,8.0)
        "Кольчужный шлем" -> Triple("Голова",0.0,5.0)
        "Кольчужная рубаха" -> Triple("Тело",0.0,12.0)
        "Латная кираса" -> Triple("Тело",0.0,22.0)
        "Латный нагрудник" -> Triple("Тело",0.0,17.0)
        "Латные наплечники" -> Triple("Наплечники",0.0,5.0)
        "Кольчужные наручи" -> Triple("Перчатки",0.0,7.0)
        "Латные рукавицы" -> Triple("Перчатки",0.0,4.0)
        "Латные поножи" -> Triple("Поножи",0.0,9.0)
        "Кольчужные поножи" -> Triple("Поножи",0.0,9.0)
        "Латные сапоги" -> Triple("Ступни",0.0,3.0)
        "Деревянный щит" -> Triple("Оружие 1",0.0,2.0)
        "Металлический щит" -> Triple("Оружие 1",0.0,5.0)
        "Тяжёлый металлический щит" -> Triple("Оружие 1",0.0,8.0)
        "Кузнечный молот" -> Triple("Оружие 1",2.0,4.0)
        "Боевой молот" -> Triple("Оружие 1",5.0,10.0)
        "Длинный меч" -> Triple("Оружие 1",2.0,5.0)
        "Двуручный меч" -> Triple("Оружие 1",5.0,9.0)
        "Секира" -> Triple("Оружие 1",5.0,8.0)
        "Топор" -> Triple("Оружие 1",3.0,5.0)
        "Копьё" -> Triple("Оружие 1",2.0,4.0)
        "Кинжал" -> Triple("Оружие 1",1.0,3.0)
        "Кирка" -> Triple("Оружие 1",3.0,5.0)
        "Лук" -> Triple("Оружие 1",3.0,5.0)
        "Дубинка" -> Triple("Оружие 1",2.0,4.0)
        "Боевой посох" -> Triple("Оружие 1",2.0,5.0)
        "Рогатка" -> Triple("Оружие 1",1.0,3.0)
        "Бумеранг" -> Triple("Оружие 1",2.0,3.0)
        "Скалка" -> Triple("Оружие 1",2.0,4.0)
        "Метла" -> Triple("Оружие 1",1.0,3.0)
        "Сковорода" -> Triple("Оружие 1",3.0,5.0)
        "Вилы" -> Triple("Оружие 1",4.0,6.0)
        else -> Triple("",0.0,0.0)
    }
    val type = when(baseName) {
        "Кузнечный молот", "Боевой молот", "Боевой посох", "Дубинка", "Бумеранг", "Скалка", "Метла", "Сковорода" -> "Дробящий"
        "Длинный меч", "Двуручный меч", "Топор", "Секира" -> "Рубящий"
        "Копьё", "Кинжал", "Кирка", "Лук" -> "Колющий"
        "Рогатка" -> "Дробящий"
        "Вилы" -> "Колющий"
        else -> ""
    }
    val grip = when(baseName) {
        "Боевой молот", "Двуручный меч", "Копьё", "Секира", "Боевой посох", "Рогатка", "Метла", "Вилы" -> "Двуручное"
        "Деревянный щит", "Металлический щит", "Тяжёлый металлический щит" -> "Одноручное"
        else -> if(type.isNotBlank()) "Одноручное" else ""
    }
    val speed = when(baseName) {
        "Кинжал" -> 10.0
        "Топор", "Кузнечный молот", "Сковорода", "Вилы" -> -5.0
        "Секира" -> -12.0
        "Двуручный меч", "Боевой молот" -> -15.0
        "Кирка" -> -8.0
        "Лук" -> -5.0
        "Дубинка" -> -3.0
        "Рогатка" -> 15.0
        "Бумеранг" -> 3.0
        "Скалка" -> 5.0
        "Метла" -> 10.0
        "Деревянный щит" -> -1.0
        "Металлический щит" -> -3.0
        "Тяжёлый металлический щит" -> -6.0
        else -> 0.0
    }
    val defense = when(baseName) {
        "Секира", "Двуручный меч" -> 2.0
        "Копьё" -> 1.0
        "Боевой молот" -> 3.0
        "Боевой посох" -> 2.0
        "Сковорода" -> 1.0
        else -> if(type.isBlank()) data.third else 0.0
    }
    val spellBonus = if(baseName=="Боевой посох") 3.0 else 0.0
    val slot = data.first.takeIf { it.isNotBlank() }
    val finalMin = if(type.isBlank()) 0.0 else data.second
    val finalMax = if(type.isBlank()) 0.0 else data.third
    val itemDurability = baseItemDurability(name)
    val finalSpeed = if (baseArmorDurability(name) > 0.0) armorSpeedPenalty(name) else speed
    return Item(id,name,description,1.0,"шт.",round2(weight),price,slot,false,"",finalMin,finalMax,type,grip,defense,0.0,finalSpeed,spellDamageBonus=spellBonus,durability=itemDurability,maxDurability=itemDurability)
}

private data class MaterialNeed(val label: String, val amount: Double, val unit: String, val aliases: List<String>)
private data class CraftRecipe(val name: String, val description: String, val needs: List<MaterialNeed>, val resultWeight: Double = 1.0)

private fun craftRecipe(name: String): CraftRecipe {
    fun metal(v: Double) = MaterialNeed("Металл", v, "кг", listOf("Железо", "Сталь", "Кобальт", "Чёрное железо", "Адамант", "Орихалк", "Титановый сплав", "Звёздное железо", "Проводящий металл", "Драконья сталь", "Мифрил", "Металл бездны", "Серебро", "Золото"))
    fun coal(v: Double) = MaterialNeed("Уголь", v, "кг", listOf("Уголь", "Бурый уголь", "Каменный уголь", "Крепкий уголь", "Чистый уголь", "Сердце вулкана"))
    fun wood(v: Double) = MaterialNeed("Рукоять (древесина)", v, "кг", listOf("Древесина", "Обычное дерево", "Дуб", "Железное дерево", "Магическое дерево", "Дерево жизни", "Дерево маны", "Древо стихий", "Древо пустоты", "Мировое древо"))
    fun leather(v: Double) = MaterialNeed("Кожа", v, "кг", listOf("Кожа", "Шкура"))
    fun thread(v: Double) = MaterialNeed("Нить", v, "кг", listOf("Нить", "Волокно"))
    val pair = when(name) {
        "Кувалда" -> "Тяжёлое двуручное оружие для мощных ударов." to listOf(metal(1.2),coal(.2),wood(.5))
        "Секира" -> "Двуручное рубящее оружие с тяжёлым лезвием." to listOf(metal(1.0),coal(.2),wood(.4))
        "Копьё" -> "Длинное оружие для колющих атак и удержания противника на расстоянии." to listOf(metal(.8),coal(.2),wood(.8))
        "Меч" -> "Сбалансированное двуручное оружие для рубящих и колющих ударов." to listOf(metal(1.0),coal(.2),wood(.3))
        "Булава" -> "Одноручное ударное оружие с металлической головкой." to listOf(metal(.7),coal(.15),wood(.3))
        "Длинный меч" -> "Одноручный меч с удлинённым клинком и удобной рукоятью." to listOf(metal(.9),coal(.2),wood(.25))
        "Короткий меч" -> "Компактный меч для быстрых атак и ближнего боя." to listOf(metal(.6),coal(.15),wood(.2))
        "Кинжал" -> "Небольшое лёгкое оружие для быстрых точных ударов." to listOf(metal(.35),coal(.1),wood(.15))
        "Топор" -> "Одноручное рубящее оружие для боя и хозяйственных работ." to listOf(metal(.65),coal(.15),wood(.3))
        "Шлем" -> "Металлическая защита головы от ударов и осколков." to listOf(metal(1.1),coal(.2))
        "Латный нагрудник" -> "Защитная металлическая пластина для корпуса." to listOf(metal(2.5),coal(.4))
        "Латные рукавицы" -> "Защитные перчатки с металлическими накладками." to listOf(metal(.8),coal(.15),leather(.2))
        "Латные поножи" -> "Защита голеней и коленей от повреждений." to listOf(metal(1.5),coal(.25),leather(.2))
        "Сапоги" -> "Прочные сапоги с усиленной подошвой и кожаным верхом." to listOf(leather(.8),thread(.1),metal(.15))
        "Наконечники" -> "Металлические наконечники для стрел и метательного оружия." to listOf(metal(.2),coal(.1))
        "Ожерелье" -> "Украшение на прочной основе для ношения на шее." to listOf(metal(.2),coal(.1),leather(.1))
        "Кольца" -> "Небольшие металлические кольца для украшения или рун." to listOf(metal(.1),coal(.05))
        "Производственные инструменты" -> "Набор простых рабочих инструментов для ремесла." to listOf(metal(.8),coal(.2),wood(.4))
        "Декор" -> "Декоративная деталь из обработанного дерева и металла." to listOf(wood(.5),metal(.1),coal(.05))
        "Выделанная кожа" -> "Подготовленная кожа для дальнейшего изготовления изделий." to listOf(leather(1.0),MaterialNeed("Крепёж и реагенты",1.0,"шт.",listOf("Кости","Рога")))
        "Деревянная заготовка" -> "Ровная деревянная заготовка для будущих изделий." to listOf(wood(1.0))
        "Кожаный ремень" -> "Прочный ремень из обработанной кожи." to listOf(leather(.4),thread(.05))
        "Ножны" -> "Кожаные ножны для безопасного ношения клинка." to listOf(leather(.5),thread(.08))
        "Деревянный щит" -> "Лёгкий щит из соединённых деревянных деталей." to listOf(wood(1.5),leather(.2))
        "Рукоять оружия" -> "Подогнанная рукоять для металлического оружия." to listOf(wood(.3),leather(.05))
        "Руническая пластина" -> "Металлическая пластина, подготовленная для нанесения рунической схемы." to listOf(metal(.3),coal(.05))
        "Рунический камень" -> "Каменная основа для хранения простой руны." to listOf(MaterialNeed("Камень",.5,"кг",listOf("Камень")),coal(.05))
        "Гравировка предмета" -> "Нанесение рунической схемы на подготовленную поверхность." to listOf(MaterialNeed("Ядро характеристики",1.0,"шт.",listOf("Ядро силы","Ядро ловкости","Ядро интеллекта","Ядро выносливости","Ядро удачи")))
        else -> "Изделие из доступных материалов." to listOf(metal(.5),coal(.1))
    }
    return CraftRecipe(name,pair.first,pair.second)
}

private fun sameStack(a: Item, b: Item): Boolean =
    a.name == b.name && a.description == b.description && a.unit == b.unit &&
    a.weightEach == b.weightEach && a.equipmentSlot == b.equipmentSlot &&
    a.stackTag == b.stackTag && a.minDamage == b.minDamage && a.maxDamage == b.maxDamage && a.damageType == b.damageType && a.weaponGrip == b.weaponGrip && a.defenseValue == b.defenseValue && a.speedBonus == b.speedBonus && a.spellDamageBonus == b.spellDamageBonus && a.strengthBonus == b.strengthBonus && a.agilityBonus == b.agilityBonus &&
    a.intelligenceBonus == b.intelligenceBonus && a.enduranceBonus == b.enduranceBonus && a.luckBonus == b.luckBonus && a.durability == b.durability && a.maxDurability == b.maxDurability && !a.equipped && !b.equipped

private fun addToStack(target: MutableList<Item>, item: Item, amount: Double = item.amount) {
    var remaining = round2(amount).coerceAtLeast(0.0)
    if (item.unit == "шт.") {
        while (remaining > 0.0001) {
            val existing = target.firstOrNull { sameStack(it, item) && it.amount < 9999.0 }
            if (existing != null) {
                val placed = minOf(9999.0 - existing.amount, remaining)
                val index = target.indexOf(existing)
                target[index] = existing.copy(amount = round2(existing.amount + placed))
                remaining = round2(remaining - placed)
            } else {
                val newId = if (target.any { it.id == item.id }) (target.maxOfOrNull { it.id } ?: item.id) + 1 else item.id
                val placed = minOf(9999.0, remaining)
                target.add(item.copy(id = newId, amount = round2(placed), weightEach=round2(item.weightEach), equipped = false))
                remaining = round2(remaining - placed)
            }
        }
    } else {
        val existing = target.firstOrNull { sameStack(it, item) }
        if (existing != null) {
            val index = target.indexOf(existing)
            target[index] = existing.copy(amount = round2(existing.amount + remaining))
        } else {
            val newId = if (target.any { it.id == item.id }) (target.maxOfOrNull { it.id } ?: item.id) + 1 else item.id
            target.add(item.copy(id = newId, amount = round2(amount), weightEach=round2(item.weightEach), equipped = false))
        }
    }
}
private data class Merchant(val name: String, val job: String, val race: String, val stock: List<Item>)
private val merchants = listOf(
    Merchant("Борк", "Шахтёр", "Дварф", listOf(
        Item(301,"Железная руда F","Железная руда F-ранга.",100.0,"кг",1.0,10),
        Item(302,"Серебряная руда E","Серебряная руда E-ранга.",100.0,"кг",1.0,20),
        Item(303,"Золотая руда D","Золотая руда D-ранга.",100.0,"кг",1.0,40),
        Item(304,"Титановая руда D","Титановая руда D-ранга.",100.0,"кг",1.0,40),
        Item(305,"Платиновая руда C","Платиновая руда C-ранга.",100.0,"кг",1.0,80),
        Item(306,"Орихалковая руда B","Орихалковая руда B-ранга.",100.0,"кг",1.0,160),
        Item(307,"Адамантовая руда A","Адамантовая руда A-ранга.",100.0,"кг",1.0,320),
        Item(308,"Мифриловая руда S","Мифриловая руда S-ранга.",100.0,"кг",1.0,640),
        Item(309,"Драконья руда SS","Руда для выплавки драконьей стали SS-ранга.",100.0,"кг",1.0,1280),
        Item(310,"Руда бездны SSS","Руда бездны SSS-ранга.",100.0,"кг",1.0,2560),
        Item(311,"Бурый уголь","Топливо для плавки. Теплотворность: 15 МДж/кг. Цена энергии: 0,60 G/МДж.",100.0,"кг",1.0,9),
        Item(312,"Каменный уголь","Топливо для плавки. Теплотворность: 30 МДж/кг. Цена энергии: 0,80 G/МДж.",100.0,"кг",1.0,24),
        Item(313,"Крепкий уголь","Высококачественное топливо для плавки. Теплотворность: 50 МДж/кг. Цена энергии: 1,00 G/МДж.",100.0,"кг",1.0,50),
        Item(314,"Чистый уголь","Очищенное топливо высокой эффективности. Теплотворность: 100 МДж/кг. Цена энергии: 1,50 G/МДж.",100.0,"кг",1.0,150),
        Item(315,"Сердце вулкана","Редкое энергетическое топливо. Теплотворность: 500 МДж/кг. Цена энергии: 2,50 G/МДж.",100.0,"кг",1.0,1250),
        Item(316,"Железо F","Железо F-ранга.",100.0,"кг",1.0,25),
        Item(317,"Серебро E","Серебро E-ранга.",100.0,"кг",1.0,50),
        Item(318,"Золото D","Золото D-ранга.",100.0,"кг",1.0,100),
        Item(319,"Титан D","Титан D-ранга.",100.0,"кг",1.0,100),
        Item(320,"Платина C","Платина C-ранга.",100.0,"кг",1.0,200),
        Item(321,"Орихалк B","Орихалк B-ранга.",100.0,"кг",1.0,400),
        Item(322,"Адамантий A","Адамантий A-ранга.",100.0,"кг",1.0,800),
        Item(323,"Мифрил S","Мифрил S-ранга.",100.0,"кг",1.0,1600),
        Item(324,"Драконья сталь SS","Драконья сталь SS-ранга.",100.0,"кг",1.0,3200),
        Item(325,"Металл бездны SSS","Металл бездны SSS-ранга.",100.0,"кг",1.0,6400))),
    Merchant("Милош", "Фермер", "Человек", listOf(
        Item(104,"Грубая кожа F","Необработанная кожа.",100.0,"кг",1.0,8),
        Item(105,"Мягкая кожа F","Подготовленная мягкая кожа.",100.0,"кг",1.0,12),
        Item(106,"Кости F","Кости монстров F ранга. Тип материала: защитный.",100.0,"шт.",0.1,2),
        Item(107,"Рога","Материал для изготовления.",100.0,"шт.",0.2,3))),
    Merchant("Финн", "Лесоруб", "Зверолюд", listOf(
        Item(108,"Обычное дерево F","Самая распространённая древесина. Легко обрабатывается, но обладает невысокой прочностью и плохо выдерживает сильные нагрузки.",100.0,"кг",1.0,4),
        Item(116,"Дуб E","Плотная и прочная древесина. Хорошо выдерживает механические нагрузки, отличается долговечностью и подходит для изготовления надёжных рукоятей.",100.0,"кг",1.0,8),
        Item(117,"Железное дерево D","Чрезвычайно плотная древесина, по твёрдости сопоставимая с некоторыми металлами. Отличается высокой прочностью и устойчивостью к повреждениям.",100.0,"кг",1.0,16),
        Item(131,"Магическое дерево B","Древесина, пропитанная природной магической энергией. Обладает повышенной прочностью и способностью проводить магическую энергию.",100.0,"кг",1.0,64),
        Item(132,"Дерево жизни A","Редкая древесина, наполненная жизненной энергией. Отличается высокой прочностью, восстанавливает свою структуру и обладает целебными свойствами.",100.0,"кг",1.0,128),
        Item(133,"Дерево маны A","Древесина, накапливающая и проводящая ману. Особенно хорошо подходит для магических инструментов и предметов с руническими схемами.",100.0,"кг",1.0,128),
        Item(134,"Древо стихий S","Легендарное дерево, вобравшее энергию всех стихий. Его древесина обладает высокой прочностью и способна взаимодействовать с различными элементальными энергиями.",100.0,"кг",1.0,256),
        Item(135,"Древо пустоты S","Таинственное дерево, связанное с энергией пустоты. Его древесина обладает необычной структурой, высокой устойчивостью к магическому воздействию и способностью взаимодействовать с энергией пустоты.",100.0,"кг",1.0,256),
        Item(136,"Мировое древо SS","Древнейшее и величайшее дерево мироздания. Его древесина содержит первозданную энергию, обладает невероятной прочностью и сохраняет свойства под воздействием сил высшего порядка.",100.0,"кг",1.0,512),
        Item(109,"Ветки F","Подходят для простых заготовок.",100.0,"шт.",0.1,2))),
    Merchant("Ларс", "Авантюрист", "Человек", listOf(
        Item(110,"Ядро силы F","Ядро монстра F ранга. Повышает STR.",100.0,"шт.",0.1,10),
        Item(113,"Ядро ловкости F","Ядро монстра F ранга. Повышает AGI.",100.0,"шт.",0.1,10),
        Item(114,"Ядро интеллекта F","Ядро монстра F ранга. Повышает INT.",100.0,"шт.",0.1,10),
        Item(118,"Ядро выносливости F","Ядро монстра F ранга. Повышает END.",100.0,"шт.",0.1,10),
        Item(119,"Ядро удачи F","Ядро монстра F ранга. Повышает LUC.",100.0,"шт.",0.1,10),
        Item(111,"Шкура волка F","Шкура волка F ранга. Тип материала: скоростной.",100.0,"кг",1.0,12),
        Item(115,"Костный нарост F","Костный нарост F ранга. Тип материала: защитный.",100.0,"шт.",0.1,7),
        Item(112,"Клыки волка F","Острые клыки волка F ранга. Тип материала: атакующий.",100.0,"шт.",0.05,5))),
    Merchant("Йохан", "Торговец зельями и книгами навыков", "Человек", listOf(
        Item(140,"Малое зелье здоровья","Восстанавливает игроку 50 HP.",99.0,"шт.",0.25,20,equipmentSlot="Зелье 1"),
        Item(141,"Малое зелье выносливости","Восстанавливает игроку 25 ОВ.",99.0,"шт.",0.25,25,equipmentSlot="Зелье 2"),
        Item(142,"Книга навыков: Огненный шар","Изучение активного боевого заклинания «Огненный шар».",1.0,"шт.",0.2,50)))
 ,
    Merchant("Гаррет", "Оружейник", "Человек", listOf(
        itemWithEquipmentStats(150,"Кинжал F","Лёгкий колющий клинок.",0.5,12),
        itemWithEquipmentStats(151,"Топор F","Одноручное рубящее оружие.",0.95,19),
        itemWithEquipmentStats(152,"Кузнечный молот F","Одноручное дробящее оружие.",1.0,21),
        itemWithEquipmentStats(153,"Длинный меч F","Одноручное рубящее оружие.",1.2,28),
        itemWithEquipmentStats(154,"Секира F","Двуручное рубящее оружие.",1.4,29),
        itemWithEquipmentStats(155,"Копьё F","Двуручное колющее оружие.",1.6,28),
        itemWithEquipmentStats(156,"Боевой молот F","Тяжёлое дробящее оружие.",2.5,52),
        itemWithEquipmentStats(157,"Двуручный меч F","Тяжёлый меч с рубящим уроном.",2.0,44),
        itemWithEquipmentStats(158,"Кольчужный шлем F","Кольчужная защита головы с кожаной подкладкой.",0.65,10),
        itemWithEquipmentStats(159,"Латный шлем F","Металлический шлем.",2.0,40),
        itemWithEquipmentStats(160,"Кольчужная рубаха F","Кольчужная защита только корпуса с кожаной подкладкой.",2.6,52),
        itemWithEquipmentStats(161,"Латная кираса F","Единая латная защита корпуса и обоих плеч.",6.5,130),
        itemWithEquipmentStats(164,"Кольчужные наручи F","Кольчужная защита рук и плеч с кожаной подкладкой.",1.3,26),
        itemWithEquipmentStats(165,"Латные рукавицы F","Металлическая защита кистей.",0.8,16),
        itemWithEquipmentStats(166,"Латные поножи F","Металлическая защита ног.",1.5,30),
        itemWithEquipmentStats(167,"Кольчужные поножи F","Кольчужная защита ног и ступней с кожаной подкладкой.",1.6,32),
        itemWithEquipmentStats(168,"Латные сапоги F","Металлическая защита ступней.",1.0,20),
        itemWithEquipmentStats(169,"Деревянный щит F","Деревянный щит для базовой защиты.",2.0,34)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setContent { BlacksmithApp() }
    }
}

@Composable
private fun BlacksmithApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val focusManager = LocalFocusManager.current
    var showResetConfirm by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var room by remember { mutableIntStateOf(0) }
    var showStorage by remember { mutableStateOf(false) }
    var craftRoomUnlocked by remember { mutableStateOf(true) }
    var runeRoomUnlocked by remember { mutableStateOf(false) }
    var location by remember { mutableStateOf("Дом") }
    var region by remember { mutableStateOf("Город Белмонт") }
    var gateFromRegion by remember { mutableStateOf("Город Белмонт") }
    var gatePassPaid by remember { mutableStateOf(false) }
    var level by remember { mutableIntStateOf(1) }
    var xp by remember { mutableIntStateOf(0) }
    var freePoints by remember { mutableIntStateOf(0) }
    var goldBalance by remember { mutableIntStateOf(100) }
    var reputation by remember { mutableIntStateOf(0) }
    var multiplier by remember { mutableStateOf("1") }
    val stats = remember { mutableStateMapOf("Сила" to 5, "Ловкость" to 5, "Выносливость" to 5, "Интеллект" to 5, "Удача" to 5) }
    val skills = listOf("Кузнечное дело","Ремесленное дело","Руническая гравировка","Двуручное оружие","Одноручное оружие","Дальний бой","Блокирование")
    val skillXp = remember { mutableStateMapOf<String, Int>().apply { skills.forEach { put(it,0) } } }
    val skillLevels = remember { mutableStateMapOf<String, Int>().apply { skills.forEach { put(it,1) } } }
    val toolRanks = remember { mutableStateMapOf<String, Int>().apply { (listOf(forgeTool,bedTool,chestTool)+blacksmithTools+craftTools+runeTools).forEach { put(it.name,0) } } }
    val chestCapacity = listOf(5,10,15,20,25,35,50).getOrElse((toolRanks["Сундук"] ?: 0).coerceIn(0,6)) { 5 }
    val inventory = remember { mutableStateListOf<Item>().apply { add(Item(1,"Начальный молот кузнеца","При экипировке повышает силу на 1.",1.0,"шт.",2.0,equipmentSlot="Оружие 1")) } }
    val storage = remember { mutableStateListOf<Item>() }
    var inventoryRefreshToken by remember { mutableIntStateOf(0) }
    val equipment = remember { mutableStateMapOf<String, Item>() }
    var drawerItem by remember { mutableStateOf<Item?>(null) }
    var drawerStorage by remember { mutableStateOf(false) }
    var quantityText by remember { mutableStateOf("") }
    var drawerSliderValue by remember { mutableFloatStateOf(0f) }
    var confirmDelete by remember { mutableStateOf(false) }
    var toastQueue by remember { mutableStateOf(listOf<Pair<Long,String>>()) }
    var toastCounter by remember { mutableLongStateOf(0L) }
    fun pushToast(message: String) { if(message.isNotBlank()) { toastCounter++; toastQueue = (toastQueue + (toastCounter to message)).takeLast(4) } }
    LaunchedEffect(toastQueue.firstOrNull()?.first) { if(toastQueue.isNotEmpty()) { delay(1500); toastQueue = toastQueue.drop(1) } }
    var merchant by remember { mutableStateOf<Merchant?>(null) }
    var buyItem by remember { mutableStateOf<Item?>(null) }
    var buyQty by remember { mutableStateOf("") }
    var buySliderValue by remember { mutableFloatStateOf(1f) }
    var expandedStat by remember { mutableStateOf("") }
    var subTab by remember { mutableIntStateOf(0) }
    var productionMessage by remember { mutableStateOf("Выбери доступную мастерскую и инструмент.") }
    var pendingUpgrade by remember { mutableStateOf<Pair<Tool, Int>?>(null) }
    var fieldResearch by remember { mutableIntStateOf(0) }
    var forestResearch by remember { mutableIntStateOf(0) }
    var forestSelectedMonster by remember { mutableStateOf("Кабан") }
    var forestMapReset by remember { mutableIntStateOf(0) }
    val huntingResearch = remember { mutableStateMapOf<String, Int>() }
    var autoExplore by remember { mutableStateOf(false) }
    var gameDay by remember { mutableIntStateOf(1) }
    var gameMinutes by remember { mutableIntStateOf(7 * 60) }
    var bedRank by remember { mutableIntStateOf(0) }
    var bedDialog by remember { mutableStateOf(false) }
    var currentHp by remember { mutableIntStateOf(0) }
    var currentMp by remember { mutableIntStateOf(0) }
    var currentOv by remember { mutableIntStateOf(0) }
    var inBattle by remember { mutableStateOf(false) }
    var battleMonster by remember { mutableStateOf<FieldMonster?>(null) }
    var battleInstance by remember { mutableIntStateOf(0) }
    var monsterHp by remember { mutableIntStateOf(0) }
    var monsterOv by remember { mutableIntStateOf(20) }
    var monsterPhase2 by remember { mutableStateOf(false) }
    var deathDialog by remember { mutableStateOf(false) }
    var deathPenalty by remember { mutableIntStateOf(0) }
    var battleNotice by remember { mutableStateOf("") }
    val damagePopups = remember { mutableStateListOf<DamageNumber>() }
    var damagePopupId by remember { mutableLongStateOf(0L) }
    var battleTick by remember { mutableIntStateOf(0) }
    var pendingWeaponXp by remember { mutableIntStateOf(0) }
    var pendingWeaponSkill by remember { mutableStateOf("Одноручное оружие") }
    var fireballLearned by remember { mutableStateOf(false) }
    var fireballCooldown by remember { mutableStateOf(false) }
    var fireballDrawer by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while(true) { delay(1000L); damagePopups.clear() } }
    var rewardDialog by remember { mutableStateOf(false) }
    val claimedFieldRewards = remember { mutableStateListOf<Int>() }
    val bedNames = listOf("Неудобная старая кровать", "Улучшенная кожаная кровать", "Хорошая кровать", "Мягкая кровать", "Комфортная кровать", "Очень удобная кровать", "Царское ложе")
    val bedOv = listOf(100, 150, 200, 300, 400, 500, 1000)
    fun advanceGameTime(minutes: Int) {
        val total = gameMinutes + minutes
        gameDay += total / (24 * 60)
        gameMinutes = total % (24 * 60)
    }

    LaunchedEffect(fireballCooldown) {
        if (fireballCooldown) { delay(3000L); fireballCooldown = false }
    }

    val equippedItemsForBonuses = equipment.values.distinctBy { it.id }
    val strength = (stats["Сила"] ?: 5) + equippedItemsForBonuses.sumOf { it.strengthBonus }.toInt() + if (equipment.containsKey("Оружие 1") || equipment.containsKey("Оружие 2")) 1 else 0
    val endurance = (stats["Выносливость"] ?: 5) + equippedItemsForBonuses.sumOf { it.enduranceBonus }.toInt()
    val intelligence = (stats["Интеллект"] ?: 5) + equippedItemsForBonuses.sumOf { it.intelligenceBonus }.toInt()
    val hpMax = 100 + 20 * endurance + 5 * level
    val mpMax = 50 + 15 * intelligence + 3 * level
    val ovMax = 50 + 10 * endurance + 2 * level
    LaunchedEffect(hpMax, mpMax, ovMax) {
        if (currentHp == 0) currentHp = hpMax
        if (currentMp == 0) currentMp = mpMax
        if (currentOv == 0) currentOv = ovMax
    }
    val carryMax = 30.0 + strength * 4.0
    val carryNow = inventory.sumOf { it.amount * it.weightEach } + equipment.values.distinctBy { it.id }.sumOf { it.amount * it.weightEach }
    val reputationRank = listOf(250,500,1000,2000,4000,8000).indexOfFirst { reputation < it }.let { if (it < 0) 6 else it }
    val reputationName = listOf("F","E","D","C","B","A","S")[reputationRank]
    val reputationBase = listOf(0,250,500,1000,2000,4000,8000)[reputationRank]
    val reputationNext = listOf(250,500,1000,2000,4000,8000,16000)[reputationRank]
    val reputationInRank = reputation - reputationBase

    fun addXp(amount: Int) {
        if(amount>0) pushToast("Получен опыт: +$amount")
        xp += amount
        while (xp >= level * 100) { xp -= level * 100; level += 1; freePoints += 2; pushToast("Новый уровень: $level") }
    }
    fun addSkillXp(skillName: String, amount: Int) {
        if (amount <= 0) return
        var currentLevel = (skillLevels[skillName] ?: 1).coerceAtLeast(1)
        var remainingXp = (skillXp[skillName] ?: 0).toLong() + amount.toLong()
        var gainedLevels = 0
        while (currentLevel < Int.MAX_VALUE) {
            val requiredXp = skillXpThreshold(skillName, currentLevel)
            if (requiredXp == Long.MAX_VALUE || remainingXp < requiredXp) break
            remainingXp -= requiredXp
            currentLevel++
            gainedLevels++
        }
        skillLevels[skillName] = currentLevel
        skillXp[skillName] = remainingXp.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        pushToast("Опыт навыка «$skillName»: +$amount")
        if (gainedLevels > 0) pushToast("Навык «$skillName» повышен до $currentLevel уровня")
    }
    fun finalizeWeaponXp() {
        if(pendingWeaponXp>0) {
            addSkillXp(pendingWeaponSkill, pendingWeaponXp)
            pendingWeaponXp=0
        }
    }
    fun moveItem(item: Item, fromStorage: Boolean, count: Double, destinationStorage: Boolean) {
        val source = if (fromStorage) storage else inventory
        val destination = if (destinationStorage) storage else inventory
        val found = source.firstOrNull { sameItemIdentity(it, item) } ?: return
        if (fromStorage && !destinationStorage && carryNow + count * item.weightEach > carryMax) { pushToast("Вы столько не унесёте."); return }
        if (!fromStorage && destinationStorage && location != "Дом") { pushToast("Выложить можно только дома."); return }
        if (!fromStorage && destinationStorage && storage.none { sameStack(it, found) } && storage.size >= chestCapacity) { pushToast("Сундук заполнен. Улучшите сундук, чтобы увеличить вместимость."); return }
        val safeCount = round2(count.coerceIn(0.0, found.amount))
        source.remove(found)
        if (found.amount > safeCount + 0.0001) source.add(found.copy(amount = round2(found.amount - safeCount)))
        addToStack(destination, found, safeCount)
        pushToast(if(destinationStorage)"В сундук: ${found.name} × $safeCount" else "Из сундука: ${found.name} × $safeCount")
        drawerItem = null
    }

    fun forestEncounter(multiplier:Double) {
        val names = listOf("Кабан","Малый волк","Волк","Лесной паук")
        val available = if(forestResearch < 125) names.take(2) else names
        val weights = mapOf("Кабан" to 20.0,"Малый волк" to 25.0,"Волк" to 15.0,"Лесной паук" to 10.0)
        val total = available.sumOf { weights[it] ?: 0.0 }
        if(Math.random() < (total*multiplier/100.0).coerceIn(0.0,1.0)) {
            val roll = Math.random()*total
            var cumulative = 0.0
            val name = available.first { n -> cumulative += (weights[n] ?: 0.0); roll < cumulative }
            val levelRange = when(name) { "Кабан" -> 5..10; "Малый волк" -> 8..10; "Волк" -> 11..20; else -> 15..20 }
            val monster = forestMonster(name,levelRange.random())
            battleInstance++;battleMonster=monster;monsterHp=monster.hp;monsterOv=monster.ov;monsterPhase2=false;damagePopups.clear();inBattle=true
        } else pushToast("Монстров нет.")
    }

    fun encounter(exploring: Boolean) {
        if (location == "Лес") { forestEncounter(if(exploring) 2.0 else 1.0); return }
        val chance = if (exploring) 1.0 else 0.5
        if (Math.random() < chance) {
            val levelRange = (1..5).toList()
            val monsterLevel = levelRange.random()
            val monster = FieldMonster("Слизень","F",monsterLevel,90+10*monsterLevel,5,7+monsterLevel,0.0,3,2,5,20+2*monsterLevel,listOf("Ядро силы F ×1","Слизь F"))
            battleInstance++
            battleMonster = monster; monsterHp = monster.hp; monsterOv = monster.ov; monsterPhase2 = false; damagePopups.clear(); inBattle = true
            if (currentHp <= 0) currentHp = hpMax
            if (currentMp <= 0) currentMp = mpMax
            if (currentOv <= 0) currentOv = ovMax
        } else pushToast("Монстров нет.")
    }

    fun finishVictory() {
        val m = battleMonster ?: return
        val earnedGold = (m.goldMin..m.goldMax).random()
        goldBalance += earnedGold
        addXp(m.xp)
        finalizeWeaponXp()
        fieldResearch = (fieldResearch + 2).coerceAtMost(100)
        // Выпавшие материалы действительно попадают в инвентарь.
        if (m.name == "Слизень") {
            addToStack(inventory, Item(200, "Ядро силы F", "Ядро монстра F ранга. Повышает STR.", 1.0, "шт.", 0.1))
            addToStack(inventory, Item(201, "Слизь F", "Материал, полученный после победы над слизнем.", 1.0, "шт.", 0.1))
            pushToast("Добыча: Ядро силы F ×1")
            pushToast("Добыча: Слизь F ×1")
        } else if(location=="Лес") {
            when(m.name) {
                "Кабан" -> { addToStack(inventory,Item(210,"Кожа F","Кожа лесного кабана. Тип материала: скоростной.",4.0,"кг",1.0));addToStack(inventory,Item(211,"Костный нарост F","Костный нарост F ранга. Тип материала: защитный.",1.0,"шт.",0.1));addToStack(inventory,Item(218,"Сухожилие F","Сухожилие кабана F ранга.",2.0,"шт.",0.05)) }
                "Малый волк" -> { addToStack(inventory,Item(212,"Шкура F","Шкура малого волка. Тип материала: скоростной.",3.0,"кг",1.0));addToStack(inventory,Item(213,"Клыки волка F","Острые клыки волка F ранга. Тип материала: атакующий.",1.0,"шт.",0.05));addToStack(inventory,Item(219,"Сухожилие F","Сухожилие малого волка F ранга.",2.0,"шт.",0.05)) }
                "Волк" -> { addToStack(inventory,Item(214,"Шкура E","Шкура лесного волка. Тип материала: скоростной.",6.0,"кг",1.0));addToStack(inventory,Item(215,"Клыки волка F","Острые клыки волка F ранга. Тип материала: атакующий.",1.0,"шт.",0.05));addToStack(inventory,Item(220,"Сухожилие E","Сухожилие лесного волка E ранга.",2.0,"шт.",0.05)) }
                "Лесной паук" -> { addToStack(inventory,Item(216,"Шёлк паука E","Шёлк лесного паука.",6.0,"шт.",0.05));addToStack(inventory,Item(217,"Хитин E","Панцирь лесного паука.",8.0,"шт.",0.1)) }
            }
        }
        pushToast("Получено золото: $earnedGold G")
        if(location=="Лес") when(m.name){
            "Кабан"->{pushToast("Добыча: Кожа F — 4 кг");pushToast("Добыча: Костный нарост F ×1");pushToast("Добыча: Сухожилие F ×2")}
            "Малый волк"->{pushToast("Добыча: Шкура F — 3 кг");pushToast("Добыча: Клыки волка F ×1");pushToast("Добыча: Сухожилие F ×2")}
            "Волк"->{pushToast("Добыча: Шкура E — 6 кг");pushToast("Добыча: Клыки волка F ×1");pushToast("Добыча: Сухожилие E ×2")}
            "Лесной паук"->{pushToast("Добыча: Шёлк паука E ×6");pushToast("Добыча: Хитин E ×8")}
        }
        battleNotice = "Вы победили ${m.name}. Получено $earnedGold G и ${m.xp} опыта."
        inBattle = false
        battleMonster = null
        if (autoExplore && location == "Поля") {
            encounter(true)
        } else if (autoExplore && location == "Лес" && forestResearch < 500) {
            advanceGameTime(15)
            forestResearch = (forestResearch + 2).coerceAtMost(500)
            if (forestResearch < 500) forestEncounter(2.0) else { autoExplore=false; pushToast("Исследование завершено. Теперь доступна охота.") }
        } else if (autoExplore && region == "Охотничьи угодья" && location != "Лес" && (huntingResearch[location] ?: 0) < 100) {
            advanceGameTime(15)
            huntingResearch[location] = ((huntingResearch[location] ?: 0) + 10).coerceAtMost(100)
            if ((huntingResearch[location] ?: 0) < 100) encounter(true) else { autoExplore=false; pushToast("Исследование завершено. Теперь доступна охота.") }
        } else {
            if (location == "Лес" && forestResearch >= 500) autoExplore=false
            if (region == "Охотничьи угодья" && (huntingResearch[location] ?: 0) >= 100) autoExplore=false
            pushToast(battleNotice)
        }
    }

    fun calculatePlayerAttackRange(): Pair<Int, Int> {
        val weapon1 = equipment["Оружие 1"]
        val weapon2 = equipment["Оружие 2"]
        val weapons = listOfNotNull(weapon1, weapon2)
        if (weapons.isEmpty()) {
            val value = (2.0 * strength + (stats["Ловкость"] ?: 5) + equipment.values.distinctBy { it.id }.sumOf { it.agilityBonus }).toInt().coerceAtLeast(1)
            return value to value
        }
        val primary = weapon1 ?: weapon2!!
        if (primary.damageType.contains("маг", ignoreCase = true)) return 0 to 0
        val twoHanded = primary.weaponGrip == "Двуручное"
        val skillName = if (twoHanded) "Двуручное оружие" else "Одноручное оружие"
        val mastery = (skillLevels[skillName] ?: 1).coerceAtLeast(1)
        val multiplier = 0.98 + 0.02 * mastery
        val second = if (twoHanded) null else weapon2?.takeIf { it.id != primary.id && !it.damageType.contains("маг", true) }
        val minWeapon = primary.minDamage * effectiveWeaponMultiplier(primary) + (second?.let { it.minDamage * effectiveWeaponMultiplier(it) } ?: 0.0)
        val maxWeapon = primary.maxDamage * effectiveWeaponMultiplier(primary) + (second?.let { it.maxDamage * effectiveWeaponMultiplier(it) } ?: 0.0)
        val str = strength.toDouble()
        val agi = ((stats["Ловкость"] ?: 5) + equipment.values.distinctBy { it.id }.sumOf { it.agilityBonus }.toInt()).toDouble()
        // Характеристики добавляются к уже итоговому урону оружия.
        val statBonus = str + agi
        val low = ((minWeapon + statBonus) * multiplier).toInt().coerceAtLeast(1)
        val high = ((maxWeapon + statBonus) * multiplier).toInt().coerceAtLeast(low)
        return low to high
    }

    fun playerDefense(): Int = equipment.values.distinctBy { it.id }.sumOf { effectiveDefense(it) }.toInt()

    fun addDamageNumbers(perHitDamage: Int, count: Int, displayBudget: Int) {
        val shown = minOf(count, displayBudget, 10)
        repeat(shown) {
            damagePopupId++
            damagePopups.add(DamageNumber(damagePopupId, "−$perHitDamage", kotlin.random.Random.nextFloat(), kotlin.random.Random.nextFloat()))
        }
    }

    LaunchedEffect(inBattle, battleInstance) {
        // Пакетная модель: за каждый короткий шаг вычисляется сразу количество атак,
        // а интерфейс показывает не более 10 отдельных чисел урона за секунду.
        val tickMs = 50L
        var gameTimeRemainderMs = 0L
        var playerAttackElapsedMs = 0.0
        var monsterAttackElapsedMs = 0.0
        var bothExhaustedMs = 0L
        var displayWindowMs = 0L
        var displayedDamageThisSecond = 0
        var fastPopupCadenceMs = 0L
        val m = battleMonster
        val encounterId = battleInstance
        while (inBattle && m != null && battleInstance == encounterId) {
            delay(tickMs)
            if (!inBattle || battleInstance != encounterId) break

            // Скорость пересчитывается динамически, если игрок сменил экипировку во время боя.
            val currentWeapon = equipment["Оружие 1"]?.takeIf{it.damageType.isNotBlank()} ?: equipment["Оружие 2"]?.takeIf{it.damageType.isNotBlank()}
            val hasMagicWeapon = currentWeapon?.damageType?.contains("маг", ignoreCase = true) == true
            val uniqueEquipment = equipment.values.distinctBy { it.id }
            val effectiveAgility = (stats["Ловкость"] ?: 5).toDouble() + uniqueEquipment.sumOf { it.agilityBonus }
            val weaponSpeedMultiplier = (1.0 + uniqueEquipment.sumOf { it.speedBonus } / 100.0).coerceAtLeast(0.05)
            val playerFrequency = if (hasMagicWeapon) 0.0 else Math.pow(10.0, effectiveAgility / 50.0) * weaponSpeedMultiplier
            val playerAttackIntervalMs = if (playerFrequency > 0.0) 1000.0 / playerFrequency else Double.POSITIVE_INFINITY

            gameTimeRemainderMs += tickMs
            if(playerFrequency > 0.0 && currentOv > 0) playerAttackElapsedMs += tickMs else playerAttackElapsedMs = 0.0
            if(monsterOv > 0) monsterAttackElapsedMs += tickMs else monsterAttackElapsedMs = 0.0
            displayWindowMs += tickMs
            while (gameTimeRemainderMs >= 1000L) {
                advanceGameTime(1)
                gameTimeRemainderMs -= 1000L
                battleTick++
            }
            if (displayWindowMs >= 1000L) {
                displayWindowMs %= 1000L
                displayedDamageThisSecond = 0
            }
            if (!monsterPhase2 && m.phase2HpThreshold != null && monsterHp <= (m.hp * m.phase2HpThreshold).toInt()) {
                monsterPhase2 = true
                pushToast("${m.name} переходит во вторую фазу!")
            }

            // Физические атаки игрока: один расчёт на пакет, 1 ОВ за каждый удар.
            if (currentOv > 0 && monsterHp > 0 && playerFrequency > 0.0 && playerAttackElapsedMs >= playerAttackIntervalMs) {
                val due = floor(playerAttackElapsedMs / playerAttackIntervalMs).toLong().coerceAtLeast(0L)
                val attacks = minOf(due, currentOv.toLong())
                if (attacks > 0) {
                    val range = calculatePlayerAttackRange()
                    val rawHit = if (range.first == range.second) range.first else kotlin.random.Random.nextInt(range.first, range.second + 1)
                    val enemyDefense = m.defense + if(monsterPhase2) m.phase2DefenseBonus else 0.0
                    val hitDamage = (rawHit - enemyDefense).toInt().coerceAtLeast(1)
                    val neededHits = ceil(monsterHp.toDouble() / hitDamage.toDouble()).toLong().coerceAtLeast(1L)
                    val appliedHits = minOf(attacks, neededHits)
                    val totalDamage = hitDamage.toLong() * appliedHits
                    monsterHp = (monsterHp.toLong() - totalDamage).coerceAtLeast(0L).toInt()
                    currentOv = (currentOv - appliedHits.toInt()).coerceAtLeast(0)
                    val mainWeapon = equipment["Оружие 1"] ?: equipment["Оружие 2"]
                    val usedWeapons = if (mainWeapon?.weaponGrip == "Двуручное") {
                        listOfNotNull(mainWeapon)
                    } else {
                        listOfNotNull(equipment["Оружие 1"], equipment["Оружие 2"])
                            .filter { it.damageType.isNotBlank() && !it.damageType.contains("маг", ignoreCase = true) }
                    }
                    // Каждое успешное попадание снимает одну единицу прочности, случайно распределяя её между парными одноручными оружиями.
                    damageWeaponsAfterHits(equipment, usedWeapons, appliedHits.toInt().coerceAtMost(Int.MAX_VALUE))
                    pendingWeaponSkill = if (mainWeapon?.weaponGrip == "Двуручное") "Двуручное оружие" else "Одноручное оружие"
                    pendingWeaponXp = (pendingWeaponXp.toLong() + appliedHits * 10L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                    playerAttackElapsedMs -= appliedHits.toDouble() * playerAttackIntervalMs
                    if (playerFrequency <= 10.0) {
                        val budget = (10 - displayedDamageThisSecond).coerceAtLeast(0)
                        addDamageNumbers(hitDamage, appliedHits.toInt().coerceAtMost(Int.MAX_VALUE), budget)
                        displayedDamageThisSecond += minOf(appliedHits.toInt().coerceAtMost(Int.MAX_VALUE), budget)
                    } else {
                        fastPopupCadenceMs += tickMs
                        if (displayedDamageThisSecond < 10 && fastPopupCadenceMs >= 100L) {
                            addDamageNumbers(hitDamage, 1, 1)
                            displayedDamageThisSecond++
                            fastPopupCadenceMs -= 100L
                        }
                    }
                }
            }
            if (monsterHp <= 0) {
                finishVictory()
                break
            }

            // Противник также атакует пакетами, пока у него есть ОВ.
            val currentMonsterSpeed = m.speed + if(monsterPhase2) m.phase2SpeedBonus else 0
            val currentMonsterFrequency = Math.pow(10.0, currentMonsterSpeed.toDouble() / 50.0)
            val currentMonsterAttackIntervalMs = 1000.0 / currentMonsterFrequency
            if (monsterOv > 0 && currentHp > 0 && monsterAttackElapsedMs >= currentMonsterAttackIntervalMs) {
                val due = floor(monsterAttackElapsedMs / currentMonsterAttackIntervalMs).toLong().coerceAtLeast(0L)
                val attacks = minOf(due, monsterOv.toLong())
                if (attacks > 0) {
                    var unblockedHits = 0L
                    repeat(attacks.toInt().coerceAtMost(Int.MAX_VALUE)) {
                        if (!tryShieldBlock(equipment)) unblockedHits++
                    }
                    val rawHit = ((m.minAttack..m.maxAttack).random() * if(monsterPhase2) m.phase2AttackMultiplier else 1.0).toInt()
                    val hitDamage = (rawHit - playerDefense()).coerceAtLeast(1)
                    val appliedHits = minOf(unblockedHits, ceil(currentHp.toDouble() / hitDamage.toDouble()).toLong().coerceAtLeast(1L))
                    currentHp = (currentHp.toLong() - hitDamage.toLong() * appliedHits).coerceAtLeast(0L).toInt()
                    monsterOv = (monsterOv - attacks.toInt()).coerceAtLeast(0)
                    // Блокированные удары не повреждают броню; она изнашивается только от прошедших атак.
                    repeat(appliedHits.toInt().coerceAtMost(Int.MAX_VALUE)) { damageArmorFromMonsterHit(equipment, m.rank) }
                    monsterAttackElapsedMs -= attacks.toDouble() * currentMonsterAttackIntervalMs
                }
            }
            if (currentHp <= 0) {
                finalizeWeaponXp()
                deathPenalty = floor(goldBalance * 0.01).toInt(); goldBalance -= deathPenalty
                gameDay += 1; gameMinutes = 7 * 60
                currentHp = hpMax; currentMp = mpMax
                autoExplore = false
                location = "Дом"; region = "Город Белмонт"; tab = 0; room = 0; showStorage = false
                merchant = null; gatePassPaid = false
                deathDialog = true; inBattle = false; battleMonster = null; break
            }

            // Если обе стороны истощены, даём 5 секунд на завершение действий/заклинаний.
            if (currentOv <= 0 && monsterOv <= 0) {
                bothExhaustedMs += tickMs
                if (bothExhaustedMs >= 5000L) {
                    finalizeWeaponXp()
                    inBattle = false
                    battleMonster = null
                    autoExplore = false
                    pushToast("Бой завершён: обе стороны истощены.")
                    break
                }
            } else {
                bothExhaustedMs = 0L
            }
        }
    }

    // Автосохранение одного слота на устройстве: файл настроек перезаписывается каждые 10 секунд.
    LaunchedEffect(Unit) {
        val prefs=context.getSharedPreferences("blacksmiths_path_save", Context.MODE_PRIVATE)
        fun itemJson(item:Item)=JSONObject().apply {
            put("id",item.id);put("name",item.name);put("description",item.description);put("amount",round2(item.amount));put("unit",item.unit);put("weightEach",round2(item.weightEach));put("price",item.price);put("equipmentSlot",item.equipmentSlot ?: JSONObject.NULL);put("equipped",item.equipped);put("stackTag",item.stackTag);put("minDamage",item.minDamage);put("maxDamage",item.maxDamage);put("damageType",item.damageType);put("weaponGrip",item.weaponGrip);put("defenseValue",item.defenseValue);put("attackBonus",item.attackBonus);put("speedBonus",item.speedBonus);put("strengthBonus",item.strengthBonus);put("agilityBonus",item.agilityBonus);put("intelligenceBonus",item.intelligenceBonus);put("enduranceBonus",item.enduranceBonus);put("luckBonus",item.luckBonus);put("spellDamageBonus",item.spellDamageBonus);put("durability",item.durability);put("maxDurability",item.maxDurability);put("minPrice",item.minPrice)
        }
        fun readItems(array:JSONArray): List<Item> = (0 until array.length()).mapNotNull { i -> runCatching {
            val o=array.getJSONObject(i)
            val originalName=o.getString("name")
            val migratedName=migrateArmorName(originalName)
            val oldMax=o.optDouble("maxDurability",0.0)
            val oldDur=o.optDouble("durability",0.0)
            val rankSuffix=migratedName.substringAfterLast(" ","")
            val factoryName=if(rankSuffix in listOf("F","E","D","C","B","A","S","SS","SSS")) "${migratedName.substringBeforeLast(" ")} F" else migratedName
            val base=itemWithEquipmentStats(o.getInt("id"),factoryName,o.optString("description"),round2(o.optDouble("weightEach")),o.optInt("price"))
            val rankNames=listOf("F","E","D","C","B","A","S","SS","SSS")
            val rank=rankNames.indexOf(migratedName.substringAfterLast(" ")).coerceAtLeast(0)
            val newMax=if(base.maxDurability>0.0) ceil(base.maxDurability*1.5.pow(rank)) else oldMax
            val migratedArmor=base.defenseValue>0.0 && base.maxDurability>0.0
            val newDur=if(migratedArmor) {
                if(oldMax>0.0) (oldDur/oldMax).coerceIn(0.0,1.0)*newMax else newMax
            } else if(oldMax>0.0) oldDur else savedItemMaxDurability(migratedName)
            Item(o.getInt("id"),migratedName,o.optString("description"),round2(o.optDouble("amount")),o.optString("unit"),round2(o.optDouble("weightEach")),o.optInt("price"),
                if(migratedArmor) base.equipmentSlot else if(o.isNull("equipmentSlot")) null else o.optString("equipmentSlot"),o.optBoolean("equipped"),o.optString("stackTag"),
                o.optDouble("minDamage")+o.optDouble("attackBonus"),o.optDouble("maxDamage")+o.optDouble("attackBonus"),o.optString("damageType"),o.optString("weaponGrip"),
                if(migratedArmor) rankedDefense(base.defenseValue,rank) else o.optDouble("defenseValue"),0.0,
                if(migratedArmor) base.speedBonus else o.optDouble("speedBonus"),o.optDouble("strengthBonus"),o.optDouble("agilityBonus"),o.optDouble("intelligenceBonus"),o.optDouble("enduranceBonus"),o.optDouble("luckBonus"),o.optDouble("spellDamageBonus"),
                newDur,newMax,o.optInt("minPrice",o.optInt("price")))
        }.getOrNull() }
        if(prefs.contains("snapshot")) runCatching {
            val root=JSONObject(prefs.getString("snapshot","{}") ?: "{}")
            level=root.optInt("level",level);xp=root.optInt("xp",xp);freePoints=root.optInt("freePoints",freePoints);goldBalance=root.optInt("gold",goldBalance);reputation=root.optInt("reputation",reputation)
            location=root.optString("location",location);region=root.optString("region",region);gateFromRegion=root.optString("gateFromRegion",gateFromRegion);gatePassPaid=root.optBoolean("gatePassPaid",gatePassPaid);val savedRoom=root.optInt("room",room);room=if(root.optInt("roomLayoutVersion",0)==0) when(savedRoom){0->2;1->1;2->3;else->0} else savedRoom.coerceIn(0,3);gameDay=root.optInt("day",gameDay);gameMinutes=root.optInt("minutes",gameMinutes)
            fieldResearch=root.optInt("research",fieldResearch);forestResearch=root.optInt("forestResearch",forestResearch);val hr=root.optJSONObject("huntingResearch");if(hr!=null) listOf("Заброшенная шахта","Небольшое поселение","Болото","Подземелье","Город мёртвых","Бездна").forEach{huntingResearch[it]=hr.optInt(it,0).coerceIn(0,100)};autoExplore=root.optBoolean("autoExplore",autoExplore);bedRank=root.optInt("bedRank",bedRank).coerceIn(0,6);toolRanks["Кровать"]=bedRank;fireballLearned=root.optBoolean("fireball",fireballLearned)
            craftRoomUnlocked=true;runeRoomUnlocked=root.optBoolean("runeUnlocked",false);multiplier=root.optString("multiplier",multiplier)
            currentHp=root.optInt("hp",currentHp);currentMp=root.optInt("mp",currentMp);currentOv=root.optInt("ov",currentOv)
            val st=root.optJSONObject("stats");if(st!=null) stats.keys.toList().forEach{stats[it]=st.optInt(it,stats[it]?:5)}
            val lv=root.optJSONObject("skillLevels");if(lv!=null) skills.forEach{skillLevels[it]=lv.optInt(it,1)}
            val sx=root.optJSONObject("skillXp");if(sx!=null) skills.forEach{skillXp[it]=sx.optInt(it,0)}
            val tr=root.optJSONObject("toolRanks");if(tr!=null) toolRanks.keys.toList().forEach{toolRanks[it]=tr.optInt(it,0).coerceIn(0,6)};toolRanks["Кровать"]=bedRank
            inventory.clear();inventory.addAll(readItems(root.optJSONArray("inventory")?:JSONArray()))
            storage.clear();storage.addAll(readItems(root.optJSONArray("storage")?:JSONArray()))
            equipment.clear();val eq=root.optJSONArray("equipment")?:JSONArray();readItems(eq).forEach{item->equipmentSlotsFor(item,item.equipmentSlot,equipment).forEach{slot->equipment[slot]=item}}
            claimedFieldRewards.clear();val rewards=root.optJSONArray("claimedRewards")?:JSONArray();for(i in 0 until rewards.length()) claimedFieldRewards.add(rewards.optInt(i))
        }
        while(true) {
            delay(10_000L)
            val root=JSONObject().apply {
                put("level",level);put("xp",xp);put("freePoints",freePoints);put("gold",goldBalance);put("reputation",reputation);put("location",location);put("region",region);put("gateFromRegion",gateFromRegion);put("gatePassPaid",gatePassPaid);put("room",room);put("roomLayoutVersion",1)
                put("day",gameDay);put("minutes",gameMinutes);put("research",fieldResearch);put("forestResearch",forestResearch);put("huntingResearch",JSONObject().apply{huntingResearch.forEach{(k,v)->put(k,v)}});put("autoExplore",autoExplore);put("bedRank",bedRank);put("fireball",fireballLearned)
                put("craftUnlocked",craftRoomUnlocked);put("runeUnlocked",runeRoomUnlocked);put("multiplier",multiplier);put("hp",currentHp);put("mp",currentMp);put("ov",currentOv)
                put("stats",JSONObject().apply{stats.forEach{(k,v)->put(k,v)}});put("skillLevels",JSONObject().apply{skills.forEach{put(it,skillLevels[it]?:1)}});put("skillXp",JSONObject().apply{skills.forEach{put(it,skillXp[it]?:0)}});put("toolRanks",JSONObject().apply{toolRanks.forEach{(k,v)->put(k,v)}})
                put("inventory",JSONArray().apply{inventory.forEach{put(itemJson(it))}});put("storage",JSONArray().apply{storage.forEach{put(itemJson(it))}});put("equipment",JSONArray().apply{equipment.values.forEach{put(itemJson(it))}});put("claimedRewards",JSONArray().apply{claimedFieldRewards.forEach{put(it)}})
            }
            prefs.edit().putString("snapshot",root.toString()).apply()
        }
    }

    val topAttackRange = displayedAttackRange(equipment, stats, skillLevels)
    val topDefense = equipment.values.distinctBy { it.id }.sumOf { effectiveDefense(it) }.toInt()
    val topWeapon = equipment["Оружие 1"]?.takeIf{it.damageType.isNotBlank()} ?: equipment["Оружие 2"]?.takeIf{it.damageType.isNotBlank()}
    val uniqueEquipmentForSpeed = equipment.values.distinctBy { it.id }
    val effectiveAgilityForSpeed = (stats["Ловкость"] ?: 5).toDouble() + uniqueEquipmentForSpeed.sumOf { it.agilityBonus }
    val weaponSpeedMultiplierForSpeed = (1.0 + uniqueEquipmentForSpeed.sumOf { it.speedBonus } / 100.0).coerceAtLeast(0.05)
    val topSpeed = if(topWeapon?.damageType?.contains("маг", true)==true) 0.0 else Math.pow(10.0, effectiveAgilityForSpeed / 50.0) * weaponSpeedMultiplierForSpeed

    MaterialTheme(colorScheme = darkColorScheme(background=bg, surface=panel, primary=goldColor, onPrimary=Color.Black, onBackground=cream, onSurface=cream)) {
        Box(Modifier.fillMaxSize().background(bg)) {
            Column(Modifier.fillMaxSize()) {
                if (tab == 0) {
                    StatusHeader(level,currentHp.coerceAtLeast(0),hpMax,currentMp.coerceAtLeast(0),mpMax,currentOv.coerceAtLeast(0),ovMax,reputationName,reputationInRank,reputationNext-reputationBase,goldBalance,"${topAttackRange.first}–${topAttackRange.second}",topDefense,topSpeed,
                        "${displayedAttackRange(emptyMap(), stats, skillLevels).let { "${it.first}–${it.second}" }}", "${topAttackRange.first}–${topAttackRange.second}",
                        "${topAttackRange.first-displayedAttackRange(emptyMap(), stats, skillLevels).first} / ${topAttackRange.second-displayedAttackRange(emptyMap(), stats, skillLevels).second}",
                        100 + 20 * (stats["Выносливость"] ?: 5) + 5 * level, hpMax,
                        Math.pow(10.0, (stats["Ловкость"] ?: 5).toDouble() / 50.0), topSpeed)
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        0 -> {
                            if (location == "Лес" && inBattle && battleMonster != null) {
                                BattleScreen(battleMonster!!,monsterHp,monsterOv,currentHp,currentMp,currentOv,hpMax,mpMax,ovMax,phase2=monsterPhase2, damageNumbers=damagePopups.toList(), onDamageNumberExpired={ id -> damagePopups.removeAll { it.id == id } },
                                    hpPotion=equipment["Зелье 1"],ovPotion=equipment["Зелье 2"],fireballLearned=fireballLearned,fireballCooldown=fireballCooldown,
                                    onHpPotion={val potion=equipment["Зелье 1"];if(potion!=null){if(potion.amount>1)equipment["Зелье 1"]=potion.copy(amount=potion.amount-1)else equipment.remove("Зелье 1");currentHp=(currentHp+50).coerceAtMost(hpMax)}},
                                    onOvPotion={val potion=equipment["Зелье 2"];if(potion!=null){if(potion.amount>1)equipment["Зелье 2"]=potion.copy(amount=potion.amount-1)else equipment.remove("Зелье 2");currentOv=(currentOv+25).coerceAtMost(ovMax)}},
                                    onFireball={when{fireballCooldown->pushToast("Навык перезаряжается");currentMp<25->pushToast("Недостаточно маны");else->{currentMp-=25;val spellBonus=equipment.values.distinctBy{it.id}.sumOf{it.spellDamageBonus}
                                    val fireDamage=(50.0*(1.0+spellBonus/100.0)-(battleMonster?.defense?:0.0)-if(monsterPhase2)(battleMonster?.phase2DefenseBonus?:0.0)else 0.0).toInt().coerceAtLeast(1);monsterHp=(monsterHp-fireDamage).coerceAtLeast(0);damagePopupId++;damagePopups.add(DamageNumber(damagePopupId,"−$fireDamage",kotlin.random.Random.nextFloat(),kotlin.random.Random.nextFloat()));fireballCooldown=true;if(monsterHp<=0)finishVictory()}}},
                                    onEscape={finalizeWeaponXp();inBattle=false;battleMonster=null;autoExplore=false;pushToast("Вы сдались. Бой завершён.")})
                            } else if (location == "Дом") {
                                Column(Modifier.fillMaxSize()) {
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=8.dp, vertical=7.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                                        listOf("Спальня","Мастерская","Кузница","Руническая гравировка").forEachIndexed { i, title ->
                                            FilterChip(selected=!showStorage && room==i,onClick={room=i;showStorage=false;pendingUpgrade=null},label={Text(title,fontSize=11.sp)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=goldColor,selectedLabelColor=Color.Black,labelColor=cream))
                                        }
                                    }
                                    Box(Modifier.weight(1f).fillMaxWidth().pointerInput(room,showStorage) {
                                        var drag = 0f
                                        detectHorizontalDragGestures(onHorizontalDrag={ _, amount -> drag += amount }, onDragEnd={
                                            if (!showStorage && drag < -70f) { room=(room+1).coerceAtMost(3); pendingUpgrade=null }
                                            else if (!showStorage && drag > 70f) { room=(room-1).coerceAtLeast(0); pendingUpgrade=null }
                                            drag=0f
                                        })
                                    }) {
                                        if (showStorage) StorageScreen(storage, chestCapacity, chestTool.rankNames[(toolRanks["Сундук"] ?: 0).coerceIn(0,6)]) { item -> drawerItem=item; drawerStorage=true; quantityText="";drawerSliderValue=0f }
                                        else when(room) {
                                            0 -> WorkshopRoom("Спальня",emptyList(),toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(6)}}, onMessage={message->when(message){"__OPEN_BED__"->bedDialog=true;"__OPEN_CHEST__"->showStorage=true;else->productionMessage=message}}, message=productionMessage, onRequestUpgrade={tool,current->if(tool.name=="Кровать") bedDialog=true else pendingUpgrade=tool to current}, extraTools=listOf(bedTool,chestTool))
                                            1 -> WorkshopRoom("Мастерская",craftTools,toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(6)}}, onMessage={productionMessage=it}, message=productionMessage, onRequestUpgrade={tool,current->pendingUpgrade=tool to current}, locked=false)
                                            2 -> WorkshopRoom("Кузница",blacksmithTools,toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(6)}}, onMessage={productionMessage=it}, message=productionMessage, onRequestUpgrade={tool,current->pendingUpgrade=tool to current}, extraTools=listOf(forgeTool))
                                            else -> WorkshopRoom("Руническая гравировка",runeTools,toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(6)}}, onMessage={productionMessage=it}, message=productionMessage, onRequestUpgrade={tool,current->pendingUpgrade=tool to current}, locked=!runeRoomUnlocked, unlockCost=500, gold=goldBalance, onUnlock={goldBalance-=500;runeRoomUnlocked=true})
                                        }
                                    }
                                    Button(onClick={showStorage=!showStorage}, modifier=Modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=5.dp), colors=ButtonDefaults.buttonColors(containerColor=if(showStorage)goldColor else panel,contentColor=if(showStorage)Color.Black else cream)) { Text(if(showStorage)"Вернуться" else "Сундук") }
                                }
                            } else if (location == "Рынок") {
                                if (merchant == null) MarketScreen(merchants) { merchant=it }
                                else Box(Modifier.fillMaxSize().pointerInput(merchant) {
                                    var drag = 0f
                                    detectHorizontalDragGestures(onHorizontalDrag={ _, amount -> drag += amount }, onDragEnd={
                                        if (drag > 70f) { merchant=null; buyItem=null }
                                        drag=0f
                                    })
                                }) { MerchantScreen(merchant!!,goldBalance,{item->buyItem=item;buyQty="";buySliderValue=1f},{merchant=null}) }
                            } else if (location == "Поля" && inBattle && battleMonster != null) {
                                BattleScreen(battleMonster!!,monsterHp,monsterOv,currentHp,currentMp,currentOv,hpMax,mpMax,ovMax,phase2=monsterPhase2, damageNumbers=damagePopups.toList(), onDamageNumberExpired={ id -> damagePopups.removeAll { it.id == id } },
                                    hpPotion=equipment["Зелье 1"], ovPotion=equipment["Зелье 2"], fireballLearned=fireballLearned, fireballCooldown=fireballCooldown,
                                    onHpPotion={
                                        val potion=equipment["Зелье 1"]
                                        if(potion!=null) { if(potion.amount>1) equipment["Зелье 1"]=potion.copy(amount=potion.amount-1) else equipment.remove("Зелье 1"); currentHp=(currentHp+50).coerceAtMost(hpMax); pushToast("Зелье здоровья: +50 HP") }
                                        else pushToast("Нет зелья здоровья")
                                    },
                                    onOvPotion={
                                        val potion=equipment["Зелье 2"]
                                        if(potion!=null) { if(potion.amount>1) equipment["Зелье 2"]=potion.copy(amount=potion.amount-1) else equipment.remove("Зелье 2"); currentOv=(currentOv+25).coerceAtMost(ovMax); pushToast("Зелье выносливости: +25 ОВ") }
                                        else pushToast("Нет зелья выносливости")
                                    },
                                    onFireball={
                                        when {
                                            fireballCooldown -> pushToast("Навык перезаряжается")
                                            currentMp<25 -> pushToast("Недостаточно маны")
                                            else -> { currentMp-=25; val spellBonus=equipment.values.distinctBy{it.id}.sumOf{it.spellDamageBonus}; val fireDamage=(50.0*(1.0+spellBonus/100.0)-(battleMonster?.defense?:0.0)-if(monsterPhase2)(battleMonster?.phase2DefenseBonus?:0.0)else 0.0).toInt().coerceAtLeast(1); monsterHp=(monsterHp-fireDamage).coerceAtLeast(0); damagePopupId++; damagePopups.add(DamageNumber(damagePopupId,"−$fireDamage",kotlin.random.Random.nextFloat(),kotlin.random.Random.nextFloat())); fireballCooldown=true; if(monsterHp<=0) finishVictory() }
                                        }
                                    },
                                    onEscape={ finalizeWeaponXp();inBattle=false; battleMonster=null; autoExplore=false; pushToast("Вы сдались. Бой завершён.") })
                            } else if (location == "Поля") {
                                FieldLocationScreen(fieldResearch, autoExplore, onAutoExplore={autoExplore=it}, onRest={ advanceGameTime(30); currentOv=(currentOv+5).coerceAtMost(ovMax); encounter(false) }, onExplore={
                                    fieldResearch=(fieldResearch+1).coerceAtMost(100); encounter(true)
                                    if(fieldResearch in listOf(25,50,75,100) && fieldResearch !in claimedFieldRewards) { claimedFieldRewards.add(fieldResearch); goldBalance+=50; rewardDialog=true }
                                })
                            } else if (location == "Лес") {
                                ForestAdventureScreen(resetKey=forestMapReset, onEncounter={ name ->
                                    val range=when(name){"Кабан"->5..10;"Малый волк"->8..10;"Волк"->11..20;else->15..20}
                                    val m=forestMonster(name,range.random());battleInstance++;battleMonster=m;monsterHp=m.hp;monsterOv=m.ov;monsterPhase2=false;inBattle=true
                                }, onGold={ goldBalance+=50; pushToast("Найдено событие: +50 G") }, onBoss={
                                    val m=forestMonster("Лесной паук",20);battleInstance++;battleMonster=m;monsterHp=m.hp;monsterOv=m.ov;monsterPhase2=false;inBattle=true
                                })
                                /* Старые действия леса сохранены ниже для последующего возвращения к сбору ресурсов.
                                ForestLocationScreen(forestResearch, autoExplore, onAutoExplore={autoExplore=it}, onLog={
                                    if(currentOv<5) pushToast("Вы истощены")
                                    else {
                                        currentOv-=5
                                        advanceGameTime(60)
                                        val str=(stats["Сила"] ?: 5)+equipment.values.distinctBy{it.id}.sumOf{it.strengthBonus}.toInt()
                                        val luck=(stats["Удача"] ?: 5)+equipment.values.distinctBy{it.id}.sumOf{it.luckBonus}.toInt()
                                        val common=(0.2*str+0.1*luck).coerceAtLeast(0.0)
                                        val oak=if(str in 11..20) (0.1*str+0.1*luck) else 0.0
                                        var freeWeight=(carryMax-carryNow).coerceAtLeast(0.0)
                                        val oakTaken=minOf(oak,freeWeight)
                                        if(oakTaken>0){addToStack(inventory,Item(702,"Дубовая древесина E","Плотная дубовая древесина.",oakTaken,"кг",1.0));freeWeight-=oakTaken;pushToast("Получено: Дубовая древесина E — ${"%.2f".format(oakTaken)} кг")}
                                        val commonTaken=minOf(common,freeWeight)
                                        if(commonTaken>0){addToStack(inventory,Item(701,"Обычная древесина F","Древесина из леса.",commonTaken,"кг",1.0));pushToast("Получено: Обычная древесина F — ${"%.2f".format(commonTaken)} кг")}
                                        if(oakTaken+commonTaken+0.0001<oak+common)pushToast("Грузоподъёмность почти исчерпана. Редкая древесина получена в приоритете.")
                                        forestResearch=(forestResearch+1).coerceAtMost(500)
                                        encounter(false)
                                    }
                                },onRest={minutes->advanceGameTime(minutes);currentOv=(currentOv+5).coerceAtMost(ovMax);forestEncounter(0.5)},onExplore={
                                    if(forestResearch>=500) pushToast("Исследование завершено. Выберите противника для охоты.")
                                    else { advanceGameTime(15);forestResearch=(forestResearch+2).coerceAtMost(500);if(forestResearch<500) encounter(true) }
                                },onFind={name->
                                    forestSelectedMonster=name
                                    val range=when(name){"Кабан"->5..10;"Малый волк"->8..10;"Волк"->11..20;else->15..20}
                                    val m=forestMonster(name,range.random());battleInstance++;battleMonster=m;monsterHp=m.hp;monsterOv=m.ov;inBattle=true
                                })
                                */
                            } else if (location == "Ворота крепости") {
                                GateLocationScreen(
                                    agility=(stats["Ловкость"] ?: 5)+equipment.values.distinctBy{it.id}.sumOf{it.agilityBonus}.toInt(),
                                    luck=(stats["Удача"] ?: 5)+equipment.values.distinctBy{it.id}.sumOf{it.luckBonus}.toInt(),
                                    region=gateFromRegion,
                                    canCrossTime=canCrossGateNow(gameMinutes),
                                    onExitCity={ if(canCrossGateNow(gameMinutes) && goldBalance>=50){goldBalance-=50;advanceGameTime(20); region="Окрестности города";gateFromRegion="Окрестности города";gatePassPaid=true; location="Ворота крепости"; tab=3; pushToast("Проход оплачен. Вы у ворот со стороны окрестностей. Выберите локацию на карте.")}else if(!canCrossGateNow(gameMinutes)) pushToast("Ворота закрыты. Проход доступен с 8:00 до 18:00") else pushToast("Нужно 50 G для прохода") },
                                    onEnterCity={ if(canCrossGateNow(gameMinutes) && goldBalance>=50){goldBalance-=50;val destination=if(gateFromRegion=="Охотничьи угодья")"Окрестности города" else "Город Белмонт";val minutes=if(destination=="Окрестности города")20 else 10;advanceGameTime(minutes);region=destination;gateFromRegion=destination;gatePassPaid=true;location="Ворота крепости";tab=3;pushToast("Проход оплачен. Вы у ворот со стороны ${if(destination=="Город Белмонт")"города" else "окрестностей"}. Выберите локацию на карте.")}else if(!canCrossGateNow(gameMinutes)) pushToast("Ворота закрыты. Проход доступен с 8:00 до 18:00") else pushToast("Нужно 50 G для прохода") },
                                    onSneak={
                                        val chance=((stats["Ловкость"]?:5)+equipment.values.distinctBy{it.id}.sumOf{it.agilityBonus}.toInt()+2*((stats["Удача"]?:5)+equipment.values.distinctBy{it.id}.sumOf{it.luckBonus}.toInt())).coerceIn(0,100)
                                        if(Math.random()*100 < chance) {
                                            if(gateFromRegion=="Город Белмонт" || gateFromRegion=="Охотничьи угодья") { advanceGameTime(20);region="Окрестности города" }
                                            else { advanceGameTime(10);region="Город Белмонт" }
                                            gateFromRegion=region;gatePassPaid=true;location="Ворота крепости";tab=3;pushToast("Удалось проскользнуть! Вы у ворот. Выберите локацию на карте.")
                                        } else { goldBalance-=20;reputation-=10;advanceGameTime(5);pushToast("Стража заметила вас! Потеряно 20 G и 10 репутации") }
                                    }
                                )
                            } else if(region=="Охотничьи угодья") {
                                val actionLabel=when(location){"Заброшенная шахта"->"Добыча руды";"Болото"->"Рубка леса";"Подземелье"->"Поиск сокровищ";"Город мёртвых"->"Поиск реликвий";"Бездна"->"Искать повелителя";else->"Собирать ресурсы"}
                                FieldRegionScreen(location,actionLabel,huntingResearch[location]?:0,autoExplore,onAutoExplore={autoExplore=it},onAction={
                                    if(currentOv<5)pushToast("Вы истощены") else {
                                        currentOv-=5;advanceGameTime(60)
                                        when(location){
                                            "Заброшенная шахта"->{val qty=1.0+((stats["Сила"]?:5)+equipment.values.distinctBy{it.id}.sumOf{it.strengthBonus}.toInt())*0.1;addToStack(inventory,Item(730,"Железная руда F","Руда из заброшенной шахты.",qty,"кг",1.0));pushToast("Получено: Железная руда F — ${format2(qty)} кг")}
                                            "Болото"->{val qty=0.2*((stats["Сила"]?:5)+equipment.values.distinctBy{it.id}.sumOf{it.strengthBonus}.toInt())+0.1*((stats["Удача"]?:5)+equipment.values.distinctBy{it.id}.sumOf{it.luckBonus}.toInt());addToStack(inventory,Item(731,"Болотная древесина F","Влажная древесина из болотной окраины.",qty,"кг",1.0));pushToast("Получено: Болотная древесина F — ${format2(qty)} кг")}
                                            "Подземелье"->{goldBalance+=5;addToStack(inventory,Item(732,"Старая монета F","Найденная в подземелье монета.",1.0,"шт.",0.05));pushToast("Найдено сокровище: 5 G");pushToast("Получено: Старая монета F")}
                                            "Город мёртвых"->{addToStack(inventory,Item(733,"Сломанная реликвия F","Фрагмент древнего артефакта.",1.0,"шт.",0.2));pushToast("Получена реликвия: Сломанная реликвия F")}
                                            "Бездна"->pushToast("Вы ощущаете присутствие повелителя, но пока не можете его найти.")
                                            "Небольшое поселение"->pushToast("Вы осматриваете окрестности поселения.")
                                        }
                                        encounter(false)
                                    }
                                },onRest={minutes->advanceGameTime(minutes);currentOv=(currentOv+5).coerceAtMost(ovMax);encounter(false)},onExplore={
                                    val progress=huntingResearch[location]?:0
                                    if(progress>=100) pushToast("Исследование завершено. Выберите противника для охоты.")
                                    else {advanceGameTime(15);huntingResearch[location]=(progress+10).coerceAtMost(100);if((huntingResearch[location]?:0)<100) encounter(true) else pushToast("Исследование завершено. Теперь доступна охота.")}
                                },onHunt={name->
                                    val baseLevel=when(location){"Заброшенная шахта"->8;"Небольшое поселение"->6;"Болото"->10;"Подземелье"->14;"Город мёртвых"->18;else->22}
                                    val lvl=baseLevel+(0..3).random()
                                    val m=FieldMonster(name,if(lvl<10)"F" else if(lvl<20)"E" else "D",lvl,90+lvl*18,8+lvl,12+lvl*2,lvl*0.6,5+lvl,3+lvl,7+lvl,30+lvl*8,listOf("Трофей: $name"))
                                    battleInstance++;battleMonster=m;monsterHp=m.hp;monsterOv=m.ov;inBattle=true
                                })
                            } else LocationScreen(location)
                        }
                        1 -> CreateScreen(inventory, storage, equipment, skillLevels, (carryMax-carryNow).coerceAtLeast(0.0), toolRanks["Кузница"] ?: 0, chestCapacity, currentOv=currentOv, onConsumeOv={ cost -> currentOv=(currentOv-cost).coerceAtLeast(0) }, onAdvanceTime={ minutes -> advanceGameTime(minutes) }, onGainSkillXp={ skillName, amount -> addSkillXp(skillName, amount) }, onInventoryChanged={ inventoryRefreshToken++ })
                        2 -> CharacterScreen(level, xp, freePoints, stats, inventoryRefreshToken, skillLevels, skillXp, inventory, equipment, currentHp, currentMp, currentOv, hpMax, mpMax, ovMax, subTab, {subTab=it}, {item->drawerItem=item;drawerStorage=false;quantityText="";drawerSliderValue=0f}, fireballLearned, {fireballDrawer=true}, {slot,item->
                            val source = inventory.firstOrNull { sameItemIdentity(it, item) }
                            if (source == null) pushToast("Предмет отсутствует в инвентаре")
                            else if (source.equipmentSlot == null) pushToast("Этот предмет нельзя экипировать")
                            else if (!equipFromInventory(inventory, equipment, source, slot)) pushToast("Один из необходимых слотов занят")
                        }, {slot->
                            val worn = equipment[slot]
                            if (worn != null) unequipToInventory(inventory, equipment, worn)
                        },expandedStat,{expandedStat=it}, {name-> if(freePoints>0){stats[name]=(stats[name]?:5)+1;freePoints--}else pushToast("Нет свободных очков")})
                        3 -> MapScreen(location,region,gateFromRegion,gatePassPaid) { name,targetRegion,travelMinutes ->
                            advanceGameTime(travelMinutes)
                            if(targetRegion=="Ворота крепости") { gateFromRegion=region; gatePassPaid=false }
                            if(location=="Ворота крепости" && targetRegion!="Ворота крепости") gatePassPaid=false
                            location=name; region=targetRegion; merchant=null; autoExplore=false; inBattle=false; battleMonster=null; if(name=="Лес") forestMapReset++; tab=0
                        }
                        else -> SettingsScreen(multiplier,{multiplier=it},{addXp((80*multiplier.toDouble()).toInt())},{goldBalance+=55},{showResetConfirm=true})
                    }
                }
                if(tab==0 && !inBattle) {
                    CarryBar(carryNow,carryMax)
                }
                NavigationBar(containerColor=Color(0xFF211C17),contentColor=cream) {
                    val labels=listOf("Ты здесь","Чертежи","Персонаж","Карта","Настройки")
                    val icons=listOf(Icons.Default.Place,Icons.Default.Build,Icons.Default.Person,Icons.Default.Map,Icons.Default.Settings)
                    labels.forEachIndexed { i,label ->
                        NavigationBarItem(selected=tab==i,onClick={tab=i;drawerItem=null;merchant=null;pendingUpgrade=null},icon={
                            if(i==2) Box(Modifier.size(45.dp).background(if(tab==i)goldColor else Color(0xFF493522),CircleShape),contentAlignment=Alignment.Center){Icon(icons[i],null,tint=if(tab==i)Color.Black else goldColor)}
                            else Icon(icons[i],null)
                        },label={if(label.isNotEmpty())Text(label,fontSize=9.sp,maxLines=1)},colors=NavigationBarItemDefaults.colors(selectedIconColor=goldColor,selectedTextColor=goldColor,indicatorColor=Color(0xFF493522),unselectedIconColor=Color.LightGray,unselectedTextColor=Color.LightGray))
                    }
                }
            }
            if(tab==0 || tab==1) {
                Box(Modifier.align(Alignment.BottomStart).padding(start=12.dp, bottom=78.dp).size(66.dp).clip(CircleShape).background(Color(0xFF211C17)).border(1.dp,goldColor,CircleShape), contentAlignment=Alignment.Center) {
                    Column(horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
                        Text(String.format("%02d:%02d",gameMinutes/60,gameMinutes%60), color=cream, fontSize=14.sp, fontWeight=FontWeight.Bold)
                        Text("День $gameDay", color=goldColor, fontSize=9.sp)
                    }
                }
            }
            if(bedDialog) {
                val nextBed = (bedRank + 1).coerceAtMost(6)
                AlertDialog(
                    onDismissRequest={bedDialog=false},
                    title={Text("Кровать", color=goldColor)},
                    text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("Текущая: ${bedNames[bedRank]}", color=cream, fontWeight=FontWeight.Bold)
                        Text("Ранг ${rankNames[bedRank]} · восстановление +${bedOv[bedRank]} ОВ", color=muted)
                        Divider(color=muted)
                        if(bedRank<6) {
                            Text("Следующая: ${bedNames[nextBed]}", color=cream, fontWeight=FontWeight.Bold)
                            Text("Ранг ${rankNames[nextBed]} · восстановление +${bedOv[nextBed]} ОВ", color=muted)
                        } else Text("Достигнут максимальный ранг S.", color=goldColor)
                    }},
                    confirmButton={Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick={advanceGameTime(8*60);currentHp=hpMax;currentMp=mpMax;currentOv=(currentOv+bedOv[bedRank]).coerceAtMost(ovMax);pushToast("Сон: HP и MP восстановлены, ОВ +${bedOv[bedRank]}")}) { Text("Спать", color=goldColor) }
                        TextButton(onClick={if(bedRank<6){bedRank++;toolRanks["Кровать"]=bedRank}}) { Text("Улучшить", color=if(bedRank<6)goldColor else muted) }
                    }},
                    dismissButton={TextButton(onClick={bedDialog=false}){Text("Закрыть",color=cream)}},
                    containerColor=panel
                )
            }
            if(rewardDialog) AlertDialog(onDismissRequest={rewardDialog=false},title={Text("Награда 50G")},text={Text("Вы достигли контрольной точки исследования поля.")},confirmButton={TextButton(onClick={rewardDialog=false}){Text("Закрыть")}})
            if(deathDialog) AlertDialog(onDismissRequest={deathDialog=false},title={Text("Вы умерли")},text={Text("Вы потеряли ${deathPenalty}G")},confirmButton={TextButton(onClick={deathDialog=false}){Text("Закрыть")}})
            if(fireballDrawer) {
                Row(Modifier.fillMaxSize().background(Color(0x99000000)),horizontalArrangement=Arrangement.End) {
                    Spacer(Modifier.weight(1f).fillMaxHeight().clickable{focusManager.clearFocus()})
                    Column(Modifier.fillMaxHeight().fillMaxWidth(.75f).background(panel).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("Огненный шар",color=goldColor,fontSize=21.sp,fontWeight=FontWeight.Bold)
                        Text("Потребляет 25 MP, наносит противнику 50 урона огнём. Время отката 3с.",color=cream,fontSize=14.sp)
                        Spacer(Modifier.weight(1f))
                        Button(onClick={fireballLearned=false;fireballDrawer=false;pushToast("Огненный шар забыт")},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=red)){Text("Забыть")}
                        TextButton(onClick={fireballDrawer=false},modifier=Modifier.fillMaxWidth()){Text("Закрыть",color=goldColor)}
                    }
                }
            }
            if(drawerItem!=null) {
                val item=drawerItem!!
                Row(Modifier.fillMaxSize().background(Color(0x99000000)),horizontalArrangement=Arrangement.End) {
                    Spacer(Modifier.weight(1f).fillMaxHeight().clickable{quantityText="";drawerSliderValue=0f;focusManager.clearFocus();drawerItem=null} )
                    Column(Modifier.fillMaxHeight().fillMaxWidth(.75f).background(panel).clickable { focusManager.clearFocus() }.padding(15.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(54.dp).background(Color(0xFF44382B),RoundedCornerShape(9.dp)),contentAlignment=Alignment.Center){ItemIcon(item,Modifier.size(38.dp))}
                            Spacer(Modifier.width(9.dp)); Text(item.name,color=cream,fontWeight=FontWeight.Bold,fontSize=17.sp)
                        }
                        Text(item.description,color=muted,fontSize=12.sp)
                        if(item.equipmentSlot!=null) Text("Слот экипировки: ${item.equipmentSlot}",color=muted,fontSize=11.sp)
                        if(item.damageType.isNotBlank()) Text("Тип урона: ${item.damageType} • Хват: ${item.weaponGrip} • Урон: ${ceil(item.minDamage).toInt()}–${ceil(item.maxDamage).toInt()}",color=goldColor,fontSize=12.sp)
                        if(item.maxDurability>0.0 && !isFunnyEquipment(item.name)) Text("Прочность: ${item.durability.toInt()} / ${item.maxDurability.toInt()}",color=muted,fontSize=11.sp)
                        else if(item.weaponGrip.isNotBlank()) Text("Хват: ${item.weaponGrip}",color=goldColor,fontSize=12.sp)
                        if(item.speedBonus!=0.0) Text("Скорость атаки: ${if(item.speedBonus>0) "+" else ""}${format2(item.speedBonus)}%",color=goldColor,fontSize=12.sp)
                        if(workCraftBonusPercent(item.name)>0.0) Text("Скорость изготовления предметов того же ранга: +${format2(workCraftBonusPercent(item.name))}%",color=goldColor,fontSize=12.sp)
                        if(item.spellDamageBonus!=0.0) Text("Урон заклинаний: +${format2(item.spellDamageBonus)}%",color=goldColor,fontSize=12.sp)
                        if(item.defenseValue>0 && !isFunnyEquipment(item.name)) Text("Защита: ${format2(effectiveDefense(item))}",color=goldColor,fontSize=12.sp);if(shieldBaseBlockChance(item)>0.0) Text("Шанс блока: ${format2(effectiveShieldBlockChance(item))}%",color=goldColor,fontSize=12.sp)
                        Text("Вес: ${format2(item.weightEach)} кг за ${if(item.unit=="кг")"кг" else "шт."} • Цена: ${item.price} G / ${item.unit}",color=muted,fontSize=11.sp)
                        if(item.minPrice>0) Text("Минимальная стоимость изготовления: ${item.minPrice} G",color=goldColor,fontSize=12.sp)
                        val available=item.amount
                        val rawSelected=quantityText.replace(',','.').toDoubleOrNull()?.coerceIn(0.0,available)?:drawerSliderValue.toDouble().coerceIn(0.0,available)
                        val selected=if(item.unit=="кг") round2(rawSelected) else kotlin.math.ceil(rawSelected)
                        if(item.unit!="кг") Text("Вес: 1 шт. — ${format2(item.weightEach)} кг\nВсего: ${format2(selected*item.weightEach)} кг",color=muted,fontSize=12.sp)
                        Spacer(Modifier.weight(1f))
                        Text("Количество",color=goldColor,fontWeight=FontWeight.Bold)
                        OutlinedTextField(value=quantityText,onValueChange={quantityText=if(item.unit=="кг") limitTwoDecimals(it) else it.filter{c->c.isDigit()};drawerSliderValue=quantityText.replace(',','.').toFloatOrNull()?:0f},modifier=Modifier.fillMaxWidth(.48f),singleLine=true,placeholder={Text("",color=muted)},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),keyboardActions=androidx.compose.foundation.text.KeyboardActions(onDone={focusManager.clearFocus()}),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=cream,unfocusedTextColor=cream))
                        QuantitySlider(value=selected,maximum=available,unit=item.unit,onValueChange={drawerSliderValue=it.toFloat();quantityText="";focusManager.clearFocus()})
                        if(item.equipmentSlot!=null) {
                            if(equipment.values.any{sameItemIdentity(it,item)}) Button(onClick={unequipToInventory(inventory,equipment,item);drawerItem=null},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Снять")}
                            else Button(onClick={
                                val source=inventory.firstOrNull { sameItemIdentity(it,item) }
                                if(source!=null && equipFromInventory(inventory,equipment,source,requestedAmount=selected)) drawerItem=null
                                else if(source==null) pushToast("Предмет отсутствует") else pushToast("Один из необходимых слотов занят")
                            },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Надеть")}
                        }
                        if(drawerStorage) Button(onClick={
                            val count=if(item.unit=="кг") floor(selected*100)/100 else ceil(selected).coerceAtLeast(1.0)
                            moveItem(item,true,count,false)
                        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Забрать")}
                        else Button(onClick={
                            val count=if(item.unit=="кг") floor(selected*100)/100 else ceil(selected).coerceAtLeast(1.0)
                            moveItem(item,false,count,true)
                        },enabled=location=="Дом"&&!item.equipped,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Выложить")}
                        OutlinedButton(onClick={confirmDelete=true},enabled=!item.equipped && !equipment.values.any{sameItemIdentity(it,item)},modifier=Modifier.fillMaxWidth()){Text("Выбросить",color=cream)}
                        TextButton(onClick={drawerItem=null},modifier=Modifier.fillMaxWidth()){Text("Закрыть меню",color=goldColor)}
                    }
                }
                if(confirmDelete) AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Удаление предмета")},text={Text("Вы точно хотите удалить предмет?\n${item.name} — $quantityText")},confirmButton={TextButton(onClick={
                    val source = if(drawerStorage) storage else inventory
                    val foundIndex = source.indexOfFirst { sameItemIdentity(it, item) }
                    if(foundIndex>=0) {
                        val found=source[foundIndex]
                        val rawDeleteAmount=quantityText.replace(',','.').toDoubleOrNull()?.coerceIn(0.0,found.amount)
                            ?: drawerSliderValue.toDouble().coerceIn(0.0,found.amount)
                        val amount=if(rawDeleteAmount>0.0) { if(found.unit=="кг") round2(rawDeleteAmount) else ceil(rawDeleteAmount) } else found.amount
                        val safe=amount.coerceIn(0.0,found.amount)
                        val remainder=round2(found.amount-safe)
                        if(safe>0.0) {
                            if(remainder<=0.0001) source.removeAt(foundIndex)
                            else source[foundIndex]=found.copy(amount=remainder)
                        } else pushToast("Укажи количество для выбрасывания")
                    }
                    drawerItem=null;confirmDelete=false
                }){Text("Удалить")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("Отмена")}},containerColor=panel,titleContentColor=cream,textContentColor=cream)
            }
            if(buyItem!=null && merchant!=null) {
                val product=buyItem!!
                AlertDialog(onDismissRequest={buyItem=null},title={Text(product.name)},text={
                    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        ItemIcon(product,Modifier.size(64.dp))
                        Text("Цена: ${product.price} G / ${product.unit} • Вес: ${format2(product.weightEach)} кг за единицу")
                        if(product.equipmentSlot!=null) Text("Слот экипировки: ${product.equipmentSlot}")
                        if(product.damageType.isNotBlank()) Text("Тип: ${product.damageType} • ${product.weaponGrip} • Урон ${ceil(product.minDamage).toInt()}–${ceil(product.maxDamage).toInt()}")
                        else if(product.weaponGrip.isNotBlank()) Text("Хват: ${product.weaponGrip}")
                        if(product.defenseValue>0) Text("Защита: ${format2(effectiveDefense(product))}");if(shieldBaseBlockChance(product)>0.0) Text("Шанс блока: ${format2(effectiveShieldBlockChance(product))}%")
                        if(product.speedBonus!=0.0) Text("Скорость атаки: ${if(product.speedBonus>0) "+" else ""}${format2(product.speedBonus)}%")
                        if(product.spellDamageBonus!=0.0) Text("Урон заклинаний: +${format2(product.spellDamageBonus)}%")
                        Text(product.description)
                        val precision = if(product.unit=="кг") 100.0 else 1.0
                        val maxByGold = if(product.price>0) floor(goldBalance.toDouble()/product.price*precision)/precision else 0.0
                        val maxByWeight = if(product.weightEach>0) floor(((carryMax-carryNow).coerceAtLeast(0.0)/product.weightEach)*precision)/precision else 0.0
                        val maxBuy = if(product.name=="Книга навыков: Огненный шар") 1.0 else minOf(product.amount,maxByGold,maxByWeight,9999.0).coerceAtLeast(0.0)
                        val rawQty=buyQty.replace(',','.').toDoubleOrNull()?.coerceIn(0.0,maxBuy)?:buySliderValue.toDouble().coerceIn(0.0,maxBuy)
                        val qty=if(product.unit=="кг") round2(rawQty) else ceil(rawQty)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value=buyQty,onValueChange={if(product.name!="Книга навыков: Огненный шар") { buyQty=if(product.unit=="кг") limitTwoDecimals(it) else it.filter{c->c.isDigit()};buySliderValue=buyQty.replace(',','.').toFloatOrNull()?:0f }},placeholder={Text("")},enabled=product.name!="Книга навыков: Огненный шар",singleLine=true,modifier=Modifier.fillMaxWidth(.48f),keyboardOptions=KeyboardOptions(keyboardType=if(product.unit=="кг")KeyboardType.Decimal else KeyboardType.Number))
                        if(product.name!="Книга навыков: Огненный шар" && maxBuy>0.0) QuantitySlider(value=qty.coerceIn(0.0,maxBuy),maximum=maxBuy,unit=product.unit,onValueChange={buySliderValue=it.toFloat();buyQty="";focusManager.clearFocus()})
                        Text("Можно купить: ${if(product.unit=="кг")"%.2f".format(maxBuy) else maxBuy.toInt()} ${product.unit}")
                        Text("Золото: ${"%.2f".format(qty*product.price)} G")
                        Text("Добавляемый вес: ${"%.2f".format(qty*product.weightEach)} кг")
                    }
                },confirmButton={TextButton(onClick={
                    val rawQty=if(product.name=="Книга навыков: Огненный шар")1.0 else buyQty.replace(',','.').toDoubleOrNull()?:buySliderValue.toDouble()
                    val qty=if(product.unit=="кг") round2(rawQty).coerceAtLeast(0.0) else ceil(rawQty).coerceAtLeast(0.0)
                    val price=ceil(qty*product.price).toInt()
                    if(qty<=0) pushToast("Укажи количество")
                    else if(price>goldBalance)pushToast("Недостаточно золота")
                    else if(carryNow+qty*product.weightEach>carryMax)pushToast("Вы столько не унесёте.")
                    else if(product.name=="Книга навыков: Огненный шар") {
                        if(fireballLearned) pushToast("Навык уже изучен")
                        else { goldBalance-=price; fireballLearned=true; pushToast("Огненный шар изучен") }
                        buyItem=null
                    }
                    else {goldBalance-=price;addToStack(inventory,product.copy(id=(inventory.maxOfOrNull{it.id}?:200)+1,amount=qty));pushToast("Куплено: ${product.name} × ${if(product.unit=="кг")"%.2f".format(qty) else qty.toInt()} ${product.unit}");buyItem=null}
                }){Text("Купить")}},dismissButton={TextButton(onClick={buyItem=null}){Text("Отмена")}},containerColor=panel,titleContentColor=cream,textContentColor=cream)
            }
            if(pendingUpgrade!=null) {
                val (upgradeTool, currentRank)=pendingUpgrade!!
                val nextRank=currentRank+1
                Dialog(onDismissRequest={pendingUpgrade=null}) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(panel).padding(20.dp),
                        verticalArrangement=Arrangement.spacedBy(11.dp)
                    ) {
                        Text("Улучшение инструмента",color=cream,fontSize=19.sp,fontWeight=FontWeight.Bold)
                        Text(upgradeTool.rankNames.getOrElse(currentRank){upgradeTool.name},color=muted,fontSize=13.sp)
                        Text("↓",color=goldColor,fontSize=20.sp)
                        Text(upgradeTool.rankNames.getOrElse(nextRank){rankNames[nextRank]},color=goldColor,fontWeight=FontWeight.Bold,fontSize=17.sp)
                        Text(upgradeTool.rankDescriptions.getOrElse(nextRank){upgradeTool.description},color=cream,fontSize=12.sp)
                        Text("Ранг: ${rankNames[currentRank]} → ${rankNames[nextRank]}",color=muted,fontSize=11.sp)
                        Button(onClick={
                            toolRanks[upgradeTool.name]=nextRank
                            productionMessage="${upgradeTool.rankNames.getOrElse(currentRank){upgradeTool.name}} улучшен до ${upgradeTool.rankNames.getOrElse(nextRank){rankNames[nextRank]}}."
                            pendingUpgrade=null
                        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF388E3C),contentColor=Color.White)) { Text("Улучшить") }
                        Button(onClick={pendingUpgrade=null},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=red,contentColor=Color.White)) { Text("Отменить") }
                    }
                }
            }
            if(showResetConfirm) AlertDialog(
                onDismissRequest={showResetConfirm=false},
                title={Text("Начать заново",color=goldColor)},
                text={Text("Вы уверены что хотите сбросить текущий прогресс и начать заново? Все уровни, ресурсы и навыки обнуляется",color=cream)},
                confirmButton={Button(onClick={
                    context.getSharedPreferences("blacksmiths_path_save", Context.MODE_PRIVATE).edit().clear().apply()
                    level=1;xp=0;freePoints=0;goldBalance=100;reputation=0;multiplier="1"
                    stats.clear();stats.putAll(mapOf("Сила" to 5,"Ловкость" to 5,"Выносливость" to 5,"Интеллект" to 5,"Удача" to 5))
                    skills.forEach{skillLevels[it]=1;skillXp[it]=0};toolRanks.keys.toList().forEach{toolRanks[it]=0}
                    inventory.clear();inventory.add(Item(1,"Начальный молот кузнеца","При экипировке повышает силу на 1.",1.0,"шт.",2.0,equipmentSlot="Оружие 1"))
                    storage.clear();equipment.clear();craftRoomUnlocked=true;runeRoomUnlocked=false;location="Дом";region="Город Белмонт";room=0;showStorage=false
                    fieldResearch=0;forestResearch=0;huntingResearch.clear();autoExplore=false;gameDay=1;gameMinutes=7*60;bedRank=0;fireballLearned=false
                    currentHp=100+20*5+5;currentMp=50+15*5+3;currentOv=50+10*5+2
                    inBattle=false;battleMonster=null;deathDialog=false;fireballCooldown=false;claimedFieldRewards.clear()
                    tab=0;drawerItem=null;merchant=null;buyItem=null;pushToast("Игра начата заново");showResetConfirm=false
                },colors=ButtonDefaults.buttonColors(containerColor=red,contentColor=Color.White)){Text("Подтвердить",fontWeight=FontWeight.Bold)}},
                dismissButton={Button(onClick={showResetConfirm=false},colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF388E3C),contentColor=Color.White)){Text("Отмена")}},containerColor=panel)
            if(toastQueue.isNotEmpty()) {
                Column(Modifier.align(Alignment.BottomCenter).padding(bottom=76.dp).fillMaxWidth(), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(4.dp)) {
                    toastQueue.forEach { notice ->
                        Text(notice.second, color=cream, fontSize=11.sp, textAlign=TextAlign.Center,
                            modifier=Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xE62A241E)).padding(horizontal=12.dp, vertical=7.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusHeader(level:Int,hp:Int,hpMax:Int,mp:Int,mpMax:Int,ov:Int,ovMax:Int,rank:String,rep:Int,repMax:Int,goldBalance:Int,attack:String,defense:Int,speed:Double,
    baseAttack:String,finalAttack:String,attackEffect:String,baseHp:Int,finalHp:Int,baseSpeed:Double,finalSpeed:Double) {
    var detail by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().background(Color(0xFF211C17)).padding(horizontal=13.dp,vertical=7.dp), verticalArrangement=Arrangement.spacedBy(4.dp)) {
        Text("Уровень $level", color=goldColor, fontSize=11.sp, fontWeight=FontWeight.Bold)
        listOf(Triple("Здоровье",hp to hpMax,Color(0xFFC84D45)), Triple("Мана",mp to mpMax,Color(0xFF438BD4)), Triple("ОВ",ov to ovMax,Color(0xFFE2AD35))).forEach { (label,values,color) ->
            Row(Modifier.fillMaxWidth().then(if(label=="Здоровье") Modifier.clickable { detail="Здоровье" } else Modifier), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Text(label, color=cream, fontSize=10.sp, modifier=Modifier.width(66.dp))
                Text("${values.first}/${values.second}", color=cream, fontSize=10.sp, modifier=Modifier.width(55.dp))
                LinearProgressIndicator(progress={(values.first.toFloat()/values.second.coerceAtLeast(1)).coerceIn(0f,1f)}, modifier=Modifier.weight(1f).height(5.dp), color=color, trackColor=panel)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("Атака: $attack", color=cream, fontSize=10.sp, modifier=Modifier.clickable { detail="Атака" })
            Text("Защита: $defense", color=cream, fontSize=10.sp)
            Text("Скорость: ${format2(speed)} атак/с", color=cream, fontSize=10.sp, modifier=Modifier.clickable { detail="Скорость" })
        }
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Text("Репутация: $rank — $rep/$repMax",color=goldColor,fontSize=11.sp,modifier=Modifier.weight(1f))
            Text("Золото: $goldBalance G",color=goldColor,fontSize=12.sp,fontWeight=FontWeight.Bold)
        }
    }
    if(detail.isNotEmpty()) AlertDialog(onDismissRequest={detail=""}, title={Text(detail,color=goldColor)},
        text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
            val base=when(detail){"Атака"->baseAttack;"Здоровье"->baseHp.toString();else->format2(baseSpeed)}
            val final=when(detail){"Атака"->finalAttack;"Здоровье"->finalHp.toString();else->format2(finalSpeed)}
            val effect=when(detail){"Атака"->attackEffect;"Здоровье"->"${finalHp-baseHp}";else->format2(finalSpeed-baseSpeed)}
            Text("Без экипировки: $base",color=cream)
            Text("Влияние экипировки: $effect",color=muted)
            Text("После экипировки: $final",color=goldColor,fontWeight=FontWeight.Bold)
        }}, confirmButton={TextButton(onClick={detail=""}){Text("Закрыть",color=goldColor)}}, containerColor=panel)
}
@Composable
private fun CarryBar(weight:Double,max:Double) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF211C17)).padding(horizontal=12.dp,vertical=4.dp)) {
        LinearProgressIndicator(progress={(weight/max).toFloat().coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(3.dp),color=goldColor,trackColor=panel)
        Text("${format2(weight)} / ${"%.0f".format(max)} кг",color=muted,fontSize=9.sp,modifier=Modifier.align(Alignment.End))
    }
}
@Composable
private fun WorkshopRoom(title:String,tools:List<Tool>,ranks:Map<String,Int>,onRank:(String)->Unit,onMessage:(String)->Unit,message:String,onRequestUpgrade:(Tool,Int)->Unit,locked:Boolean=false,unlockCost:Int=0,gold:Int=0,onUnlock:()->Unit={},extraTools:List<Tool> = emptyList()) {
    Column(Modifier.fillMaxSize().padding(horizontal=14.dp)) {
        if(locked) {
            Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)){Icon(Icons.Default.Lock,null,tint=goldColor,modifier=Modifier.size(42.dp));Text("Комната закрыта",color=cream,fontSize=20.sp);Text("Разблокировка: $unlockCost G",color=goldColor);Button(onClick=onUnlock,enabled=gold>=unlockCost,colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Разблокировать")};if(gold<unlockCost)Text("Недостаточно золота. Есть: $gold G",color=red,fontSize=12.sp)}}
        } else {
            LazyVerticalGrid(columns=GridCells.Fixed(2),modifier=Modifier.weight(1f),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                items(extraTools+tools) { tool ->
                    val current = (ranks[tool.name] ?: 0).coerceIn(0, 6)
                    val currentName = tool.rankNames.getOrElse(current) { tool.name }
                    val currentDescription = tool.rankDescriptions.getOrElse(current) { tool.description }
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(panel).clickable{if(tool.name=="Кровать") onMessage("__OPEN_BED__") else if(tool.name=="Сундук") onMessage("__OPEN_CHEST__") else onMessage("$currentName. $currentDescription")}.padding(8.dp)) {
                        AsyncImage(model=tool.image,contentDescription=currentName,modifier=Modifier.fillMaxWidth().aspectRatio(3f/4f).clip(RoundedCornerShape(8.dp)))
                        Text(currentName,color=cream,fontSize=12.sp,fontWeight=FontWeight.SemiBold,minLines=2)
                        Text("Ранг ${rankNames[current]}",color=goldColor,fontSize=10.sp)
                        Button(onClick={ if (current < 6) onRequestUpgrade(tool,current) },enabled=current < 6,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(2.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Улучшить",fontSize=11.sp)}
                        if(tool.name=="Сундук") Text(currentDescription,color=muted,fontSize=9.sp) else tool.requirements.forEach{Text(it,color=muted,fontSize=9.sp)}
                    }
                }
            }
            if(message.isNotBlank()) Text(message,color=goldColor,fontSize=10.sp)
        }
    }
}
@Composable
private fun StorageScreen(items:List<Item>,capacity:Int,chestName:String,onItem:(Item)->Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(chestName,color=cream,fontSize=24.sp,fontWeight=FontWeight.Bold)
        Text("Ячейки: ${items.size}/$capacity · Предметы не учитываются в переносимом весе.",color=muted,fontSize=11.sp)
        LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.fillMaxSize(),contentPadding=PaddingValues(top=10.dp),verticalArrangement=Arrangement.spacedBy(6.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            items(maxOf(capacity,items.size)) { i -> val item=items.getOrNull(i)
                Box(Modifier.aspectRatio(1f).background(panel,RoundedCornerShape(7.dp)).clickable{item?.let(onItem)},contentAlignment=Alignment.Center) {
                    if(item!=null) Column(horizontalAlignment=Alignment.CenterHorizontally){ItemIcon(item,Modifier.size(28.dp));Text("${if(item.unit=="кг")format2(item.amount) else item.amount.toInt()} ${item.unit}",color=muted,fontSize=8.sp,textAlign=TextAlign.Center)}
                    else Text("·",color=muted)
                }
            }
        }
    }
}
@Composable
private fun MarketScreen(merchants:List<Merchant>,onSelect:(Merchant)->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text("Рынок",color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
        merchants.forEach { m ->
            Row(Modifier.fillMaxWidth().padding(vertical=5.dp).background(panel,RoundedCornerShape(12.dp)).clickable{onSelect(m)}.padding(13.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Store,null,tint=goldColor,modifier=Modifier.size(34.dp));Spacer(Modifier.width(10.dp))
                Column { Text(m.name,color=cream,fontWeight=FontWeight.Bold);Text("${m.job} • ${m.race}",color=muted,fontSize=11.sp) }
                Spacer(Modifier.weight(1f));Text("Торговать ›",color=goldColor,fontSize=11.sp)
            }
        }
    }
}
@Composable
private fun MerchantScreen(merchant:Merchant,goldBalance:Int,onBuy:(Item)->Unit,onLeave:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        TextButton(onClick=onLeave){Text("← К торговцам",color=goldColor)}
        Text(merchant.name,color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
        Text("${merchant.job} • ${merchant.race}",color=muted)
        Text("«Что брать будешь?»",color=goldColor,modifier=Modifier.padding(vertical=10.dp))
        merchant.stock.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(vertical=4.dp).background(panel,RoundedCornerShape(10.dp)).padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                ItemIcon(item,Modifier.size(42.dp));Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)){Text(item.name,color=cream,fontWeight=FontWeight.SemiBold);Text("${item.price} G / ${item.unit} • ${format2(item.weightEach)} кг за ед.",color=muted,fontSize=11.sp);if(item.description.contains("Тип:") || item.description.contains("Тип материала:"))Text(item.description,color=goldColor,fontSize=10.sp);if(item.damageType.isNotBlank())Text("${item.damageType} • ${format2(item.minDamage)}–${format2(item.maxDamage)} урона • ${item.weaponGrip}",color=muted,fontSize=10.sp);if(item.defenseValue>0)Text("Защита: ${format2(effectiveDefense(item))}",color=muted,fontSize=10.sp);if(shieldBaseBlockChance(item)>0.0)Text("Блок: ${format2(effectiveShieldBlockChance(item))}%",color=muted,fontSize=10.sp)}
                Button(onClick={onBuy(item)},colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Купить")}
            }
        }
    }
}
@Composable
private fun MapScreen(location:String,region:String,gateFromRegion:String,gatePassPaid:Boolean,onMove:(String,String,Int)->Unit) {
    fun huntingIndex(name:String):Int = listOf("Лес","Заброшенная шахта","Небольшое поселение","Болото","Подземелье","Город мёртвых","Бездна").indexOf(name).coerceAtLeast(0)
    fun travelTime(targetName:String,targetRegion:String):Int {
        if (targetName == location && targetRegion == region) return 0
        if (targetRegion == region) return when(region) {
            "Город Белмонт" -> 10
            "Окрестности города" -> 20
            "Охотничьи угодья" -> 30 * kotlin.math.abs(huntingIndex(targetName) - huntingIndex(location)).coerceAtLeast(1)
            else -> 0
        }
        return when {
            (region == "Окрестности города" && targetRegion == "Охотничьи угодья") ||
            (region == "Охотничьи угодья" && targetRegion == "Окрестности города") -> 30 + 30 * huntingIndex(if(targetRegion == "Охотничьи угодья") targetName else location)
            (region == "Город Белмонт" && targetRegion == "Ворота крепости") || (region == "Ворота крепости" && targetRegion == "Город Белмонт") -> 10
            (region == "Окрестности города" && targetRegion == "Ворота крепости") || (region == "Ворота крепости" && targetRegion == "Окрестности города") -> 20
            (region == "Охотничьи угодья" && targetRegion == "Ворота крепости") || (region == "Ворота крепости" && targetRegion == "Охотничьи угодья") -> 30 + 30 * huntingIndex(if(targetRegion == "Охотничьи угодья") targetName else location)
            else -> 0
        }
    }
    fun formatTravelTime(minutes:Int):String = when {
        minutes <= 0 -> "0 мин."
        minutes < 60 -> "$minutes мин."
        minutes % 60 == 0 -> "${minutes / 60} ч."
        else -> "${minutes / 60} ч. ${minutes % 60} мин."
    }
    val allGroups = listOf(
        Triple("Город Белмонт", "Городские улицы и крепостные стены.", listOf(
            "Замок" to "Здесь живёт король.",
            "Рынок" to "Здесь можно купить всё, что тебе нужно.",
            "Доска объявлений" to "Заказы, поручения и объявления жителей.",
            "Дом" to "Дряхлый, но свой."
        )),
        Triple("Ворота крепости", "Отдельный промежуточный регион между городом и внешними землями.", listOf(
            "Ворота крепости" to "Промежуточный пункт между городом и внешними землями. Проход платный или через скрытное проникновение."
        )),
        Triple("Окрестности города", "Земли за крепостными стенами.", listOf(
            "Конюшня" to "Лошади Феллисии.",
            "Ферма" to "Скотный двор Милоша.",
            "Поселение" to "Здесь живут шахтёры, лесорубы и травники.",
            "Поля" to "Колосистая пшеница и мелкие вредители."
        )),
        Triple("Охотничьи угодья", "Опасные места за пределами безопасных земель.", listOf(
            "Лес" to "Подходит для рубки древесины.",
            "Заброшенная шахта" to "Здесь можно добывать руду.",
            "Небольшое поселение" to "Несколько соломенных домиков с копьями вокруг.",
            "Болото" to "Топи, в которые нечасто ходят люди.",
            "Подземелье" to "Чем выше риски, тем больше прибыль.",
            "Город мёртвых" to "В начале было обычным кладбищем.",
            "Бездна" to "Оттуда ещё никто не возвращался."
        ))
    )
    val groups = if(location=="Ворота крепости") {
        val visible = if(!gatePassPaid) listOf("Ворота крепости") else when(region) {
            "Окрестности города" -> listOf("Окрестности города", "Ворота крепости", "Охотничьи угодья")
            "Город Белмонт" -> listOf("Город Белмонт", "Ворота крепости")
            "Охотничьи угодья" -> listOf("Охотничьи угодья", "Ворота крепости", "Окрестности города")
            else -> listOf("Ворота крепости")
        }
        allGroups.filter { it.first in visible }
    } else when(region) {
        "Город Белмонт" -> allGroups.filter { it.first in listOf("Город Белмонт", "Ворота крепости") }
        "Окрестности города" -> allGroups.filter { it.first in listOf("Окрестности города", "Ворота крепости", "Охотничьи угодья") }
        "Охотничьи угодья" -> allGroups.filter { it.first in listOf("Охотничьи угодья", "Окрестности города") }
        else -> allGroups.filter { it.first == region || it.first == "Ворота крепости" }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(region,color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        groups.forEach { (groupName,subtitle,places) ->
            Text(groupName,color=goldColor,fontSize=18.sp,fontWeight=FontWeight.Bold)
            Text(subtitle,color=muted,fontSize=10.sp)
            places.forEach { (name,desc) ->
                Row(Modifier.fillMaxWidth().padding(vertical=3.dp).background(panel,RoundedCornerShape(12.dp)).padding(11.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Place,null,tint=goldColor);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text(name,color=cream,fontWeight=FontWeight.Bold);Text(desc,color=muted,fontSize=10.sp)}
                    if(location==name && (groupName==region || name=="Ворота крепости")) Text("Вы здесь",color=goldColor,fontSize=10.sp)
                    else {
                        val targetRegion = groupName
                        val canMove = when {
                            location == name && (groupName==region || name=="Ворота крепости") -> false
                            location == "Ворота крепости" -> gatePassPaid
                            region == "Город Белмонт" -> targetRegion in listOf("Город Белмонт", "Ворота крепости")
                            region == "Ворота крепости" -> targetRegion == "Ворота крепости"
                            region == "Окрестности города" -> targetRegion in listOf("Окрестности города", "Ворота крепости", "Охотничьи угодья")
                            region == "Охотничьи угодья" -> targetRegion in listOf("Охотничьи угодья", "Ворота крепости", "Окрестности города")
                            else -> targetRegion == region
                        }
                        val travel = travelTime(name,targetRegion)
                        Column(horizontalAlignment=Alignment.End) {
                            Text("Время: +${formatTravelTime(travel)}",color=muted,fontSize=9.sp)
                            Button(onClick={onMove(name,targetRegion,travel)},enabled=canMove,contentPadding=PaddingValues(horizontal=7.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black,disabledContainerColor=panel,disabledContentColor=muted)){Text("Переместиться",fontSize=9.sp)}
                        }
                    }
                }
            }
        }
    }
}

private fun canCrossGateNow(minutes:Int):Boolean = minutes >= 8*60 && minutes < 18*60

@Composable
private fun GateLocationScreen(agility:Int,luck:Int,region:String,canCrossTime:Boolean,onExitCity:()->Unit,onEnterCity:()->Unit,onSneak:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Стражник ворот",color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
        Text("Текущая локация: Ворота крепости",color=goldColor,fontWeight=FontWeight.SemiBold)
        Text("Суровые сторожа, которые не спят днём и ночью.",color=muted)
        Text("Проход открыт с 8:00 до 18:00. Оплата — 50 G. При неудачной попытке проскользнуть: −20 G и −10 репутации. Вы пришли со стороны: $region. После оплаты откроется карта следующей зоны; до оплаты она скрыта.",color=cream,fontSize=14.sp)
        Spacer(Modifier.weight(1f))
        if(region=="Город Белмонт") Button(onClick=onExitCity,enabled=canCrossTime,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)) { Text("Оплатить проход в окрестности · 50 G · 20 мин.") }
        else Button(onClick=onEnterCity,enabled=canCrossTime,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)) { Text(if(region=="Охотничьи угодья")"Пройти в окрестности · 50 G · 20 мин." else "Оплатить проход в город · 50 G · 10 мин.") }
        Button(onClick=onSneak,enabled=true,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF493522),contentColor=cream)) { Text("Попытаться проскользнуть · Шанс: ${(agility+2*luck).coerceIn(0,100)}%") }
    }
}

@Composable
private fun FieldLocationScreen(progress:Int,autoExplore:Boolean,onAutoExplore:(Boolean)->Unit,onRest:()->Unit,onExplore:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Поля",color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
        Text("Колосистая пшеница и мелкие вредители.",color=muted)
        Text("Исследование: $progress / 100",color=goldColor,fontWeight=FontWeight.Bold)
        Box(Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(9.dp)).background(panel)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(progress/100f).background(Color(0xFF4DAD70)))
            Row(Modifier.fillMaxSize(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) { listOf(25,50,75,100).forEach { Box(Modifier.width(2.dp).fillMaxHeight().background(cream)) } }
        }
        Text("Контрольные точки: 25% · 50% · 75% · 100%",color=muted,fontSize=11.sp)
        Spacer(Modifier.weight(1f))
        Button(onClick=onRest,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=panel,contentColor=cream)){Text("Отдохнуть · +30 минут · +5 ОВ")}
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Button(onClick=onExplore,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Исследовать")}
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Text("Авто", color=cream, fontSize=9.sp)
                Switch(checked=autoExplore,onCheckedChange=onAutoExplore)
            }
        }
    }
}


private val forestGrid = listOf(
"########################################",
"########################################",
"########################################",
"#################.....##################",
"#################.....##################",
"###........######..B..#######.......####",
"###...................#######.......####",
"###.....T..######.....#######..T....####",
"###..C......###############.......M.####",
"###........################.#.....T.####",
"###...T......##############.#.......####",
"###........################.####.#######",
"#####.#####################.####...#####",
"#####.########...........##.#####....####",
"#####.########...........##.#####..C.####",
"###....#######..............#####....####",
"###.!..########..T....T..########....####",
"###....######...............#############",
"###....######.#..........##.#############",
"###.#########.#############.#############",
"###.#########.#############.#############",
"###.##........#############.##.......####",
"###.##.############.#######.##..T....####",
"###......#....#####.#######.##.......####",
"###........!..#####.#######......M...####",
"###.T.......T.##.......#######.......####",
"###...C..#..####.......#######.....T.####",
"###......#####.......T.#######.......####",
"###......#####.#..M......########.########",
"##########.....#..T....#......###.########",
"##..#####......#.......#..........########",
"###..####..!..#####.####...C..###########",
"####.####.....#####.####......####..!####",
"####......#########.####......####.#######",
"####......#######.............####.#######",
"####.T.M..##...##.......#####.......######",
"####......##.!..........#####....T..######",
"####......##...##...E...######..C...######",
"#################.......######......######",
"########################################"
).map { it.padEnd(42, '#') }

private fun forestLineOfSight(fromX:Int, fromY:Int, toX:Int, toY:Int):Boolean {
    var x=fromX; var y=fromY
    val dx=kotlin.math.abs(toX-fromX); val sx=if(fromX<toX) 1 else -1
    val dy=-kotlin.math.abs(toY-fromY); val sy=if(fromY<toY) 1 else -1
    var error=dx+dy
    while(true) {
        if(x==toX && y==toY) return true
        val twice=2*error
        if(twice>=dy) { error+=dy; x+=sx }
        if(twice<=dx) { error+=dx; y+=sy }
        if(x !in 0 until 42 || y !in forestGrid.indices) return false
        if((forestGrid[y][x]=='#' || forestGrid[y][x]=='T') && !(x==toX && y==toY)) return false
    }
}

@Composable
private fun ForestAdventureScreen(resetKey:Int,onEncounter:(String)->Unit,onGold:()->Unit,onBoss:()->Unit) {
    var px by remember(resetKey) { mutableIntStateOf(forestGrid[37].indexOf('E').coerceAtLeast(0)) }
    var py by remember(resetKey) { mutableIntStateOf(37) }
    val explored = remember(resetKey) { mutableStateMapOf<String,Boolean>() }
    val claimed = remember(resetKey) { mutableStateMapOf<String,Boolean>() }
    val defeated = remember(resetKey) { mutableStateMapOf<String,Boolean>() }
    val enemies = remember(resetKey) { mutableStateListOf(
        Triple(29,8,"Кабан"), Triple(33,25,"Малый волк"), Triple(18,28,"Волк"),
        Triple(12,35,"Лесной паук"), Triple(8,14,"Кабан"), Triple(34,36,"Малый волк")
    ) }
    fun canSee(fromX:Int,fromY:Int,x:Int,y:Int):Boolean =
        kotlin.math.abs(x-fromX)+kotlin.math.abs(y-fromY)<=3 && forestLineOfSight(fromX,fromY,x,y)
    fun revealAround(cx:Int,cy:Int) {
        for(y in (cy-3).coerceAtLeast(0)..(cy+3).coerceAtMost(39))
            for(x in (cx-3).coerceAtLeast(0)..(cx+3).coerceAtMost(41))
                if(canSee(cx,cy,x,y)) explored["$x,$y"]=true
    }
    LaunchedEffect(px,py) { revealAround(px,py) }
    fun walk(dx:Int,dy:Int) {
        val nx=px+dx; val ny=py+dy
        if(ny !in forestGrid.indices || nx !in 0 until 42) return
        val cell=forestGrid[ny][nx]
        if(cell=='#' || cell=='T') return
        px=nx;py=ny
        revealAround(px,py)
        if(cell=='!') { val key="$nx,$ny"; if(claimed[key]!=true){claimed[key]=true;onGold()} }
        if(cell=='B' && defeated["boss"]!=true) { defeated["boss"]=true; onBoss() }
        val enemy=enemies.firstOrNull { it.first==px && it.second==py && defeated["${it.first},${it.second}"]!=true }
        if(enemy!=null) { defeated["${enemy.first},${enemy.second}"]=true; onEncounter(enemy.third) }
        // Два патрульных перемещаются по свободным клеткам после шага героя.
        enemies.indices.forEach { i ->
            if(i%2==0) {
                val e=enemies[i]; val options=listOf(1 to 0,0 to 1,-1 to 0,0 to -1).map{(ex,ey)->(e.first+ex) to (e.second+ey)}
                val next=options.firstOrNull{(ex,ey)->ey in forestGrid.indices && ex in 0 until 42 && forestGrid[ey][ex]!='#' && forestGrid[ey][ex]!='T' && !(ex==px&&ey==py)}
                if(next!=null) enemies[i]=Triple(next.first,next.second,e.third)
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal=8.dp, vertical=6.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)) {
        Text("Лесной лабиринт",color=goldColor,fontWeight=FontWeight.Bold,fontSize=18.sp)
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF080B08))) {
            Canvas(Modifier.fillMaxSize()) {
                val cell=28.dp.toPx()
                val columns=kotlin.math.ceil(size.width/cell).toInt()+2
                val rows=kotlin.math.ceil(size.height/cell).toInt()+2
                val startX=px-columns/2
                val startY=py-rows/2
                val offsetX=(size.width-columns*cell)/2f
                val offsetY=(size.height-rows*cell)/2f
                for(screenY in 0 until rows) for(screenX in 0 until columns) {
                    val x=startX+screenX; val y=startY+screenY
                    if(x !in 0 until 42 || y !in 0 until 40) continue
                    val c=forestGrid[y][x]
                    val seen=explored["$x,$y"]==true || canSee(px,py,x,y)
                    if(!seen) continue
                    val color=when(c){'#'->Color(0xFF17251A);'T'->Color(0xFF244B2A);'.'->Color(0xFF65734B);'E'->Color(0xFFB58A45);'B'->Color(0xFF68433C);else->Color(0xFF65734B)}
                    val left=offsetX+screenX*cell; val top=offsetY+screenY*cell
                    drawRect(color,Offset(left,top),androidx.compose.ui.geometry.Size(cell-1f,cell-1f))
                    if(c=='!' && claimed["$x,$y"]!=true) drawCircle(Color.Yellow,cell*.22f,Offset(left+cell/2,top+cell/2))
                    if(c=='C') drawCircle(Color(0xFFFFC247),cell*.22f,Offset(left+cell/2,top+cell/2))
                }
                enemies.forEach { e ->
                    val sx=e.first-startX; val sy=e.second-startY
                    if(sx in 0 until columns && sy in 0 until rows && (explored["${e.first},${e.second}"]==true || canSee(px,py,e.first,e.second)) && defeated["${e.first},${e.second}"]!=true)
                        drawCircle(Color.Red,cell*.3f,Offset(offsetX+(sx+.5f)*cell,offsetY+(sy+.5f)*cell))
                }
                val playerX=offsetX+(px-startX+.5f)*cell
                val playerY=offsetY+(py-startY+.5f)*cell
                drawCircle(Color(0xFF56B7FF),cell*.36f,Offset(playerX,playerY))
            }
        }
        Text("Позиция: ${px+1}, ${py+1} · Обзор: 3 клетки",color=muted,fontSize=10.sp)
        Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(3.dp)) {
            HoldDirectionButton("▲"){walk(0,-1)}
            Row(horizontalArrangement=Arrangement.spacedBy(26.dp),verticalAlignment=Alignment.CenterVertically) {
                HoldDirectionButton("◀"){walk(-1,0)}
                Box(Modifier.size(46.dp).clip(CircleShape).background(panel).border(1.dp,goldColor,CircleShape),contentAlignment=Alignment.Center){Text("●",color=goldColor)}
                HoldDirectionButton("▶"){walk(1,0)}
            }
            HoldDirectionButton("▼"){walk(0,1)}
        }
    }
}

@Composable
private fun HoldDirectionButton(label:String,onStep:()->Unit) {
    val latest by rememberUpdatedState(onStep)
    Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF493522)).border(1.dp,goldColor,RoundedCornerShape(12.dp)).pointerInput(label) {
        detectTapGestures(onPress={
            // Первый шаг выполняется сразу. Повторение живёт только пока палец
            // действительно удерживает кнопку; отпускание или отмена жеста
            // гарантированно отменяет задачу повторного движения.
            latest()
            kotlinx.coroutines.coroutineScope {
                val repeatJob = launch {
                    while (isActive) {
                        delay(220)
                        latest()
                    }
                }
                try {
                    tryAwaitRelease()
                } finally {
                    repeatJob.cancel()
                }
            }
        })
    },contentAlignment=Alignment.Center){Text(label,color=cream,fontSize=22.sp,fontWeight=FontWeight.Bold)}
}

@Composable
private fun ForestLocationScreen(progress:Int,autoExplore:Boolean,onAutoExplore:(Boolean)->Unit,onLog:()->Unit,onRest:(Int)->Unit,onExplore:()->Unit,onFind:(String)->Unit) {
    var actionIcon by remember { mutableStateOf("🪓") }
    var iconMenu by remember { mutableStateOf(false) }
    var restMinutes by remember { mutableIntStateOf(30) }
    var restMenu by remember { mutableStateOf(false) }
    var selectedMonster by remember { mutableStateOf("Кабан") }
    var monsterMenu by remember { mutableStateOf(false) }
    val complete = progress >= 500
    val available = if(progress < 125) listOf("Кабан","Малый волк") else listOf("Кабан","Малый волк","Волк","Лесной паук")
    Column(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("Лес",color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
            Text("Исследование: $progress / 500",color=goldColor,fontWeight=FontWeight.Bold)
            LinearProgressIndicator(progress={ (progress/500f).coerceIn(0f,1f) },modifier=Modifier.fillMaxWidth().height(8.dp),color=Color(0xFF4DAD70),trackColor=panel)
            Text("Рубка леса расходует 5 ОВ. Отдых восстанавливает 5 ОВ.",color=muted,fontSize=11.sp)
        }
        Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp),verticalAlignment=Alignment.CenterVertically) {
                Button(onClick=onLog,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Рубка леса",fontSize=12.sp)}
                Box {
                    OutlinedButton(onClick={iconMenu=true},contentPadding=PaddingValues(horizontal=12.dp,vertical=7.dp)){Text("$actionIcon ▾",fontSize=18.sp)}
                    DropdownMenu(expanded=iconMenu,onDismissRequest={iconMenu=false}) {
                        listOf("🪓" to "Топор","🪚" to "Пила","🧺" to "Корзина").forEach { (icon,label)->DropdownMenuItem(text={Text("$icon  $label")},onClick={actionIcon=icon;iconMenu=false}) }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp),verticalAlignment=Alignment.CenterVertically) {
                Button(onClick={onRest(restMinutes)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp),colors=ButtonDefaults.buttonColors(containerColor=panel,contentColor=cream)){Text("Отдых",fontSize=12.sp)}
                Box {
                    OutlinedButton(onClick={restMenu=true},contentPadding=PaddingValues(horizontal=10.dp,vertical=7.dp)){Text(if(restMinutes==30)"30 мин. ▾" else if(restMinutes==60)"1 час ▾" else "2 часа ▾",fontSize=11.sp)}
                    DropdownMenu(expanded=restMenu,onDismissRequest={restMenu=false}) {
                        listOf(30 to "30 минут",60 to "1 час",120 to "2 часа").forEach { (mins,label)->DropdownMenuItem(text={Text(label)},onClick={restMinutes=mins;restMenu=false}) }
                    }
                }
            }
            if(!complete) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
                    Button(onClick=onExplore,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Исследовать",fontSize=12.sp)}
                    Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("Авто",color=cream,fontSize=9.sp);Switch(checked=autoExplore,onCheckedChange=onAutoExplore) }
                }
            } else {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
                    Button(onClick={onFind(selectedMonster)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Охота",fontSize=12.sp)}
                    Box {
                        OutlinedButton(onClick={monsterMenu=true},contentPadding=PaddingValues(horizontal=10.dp,vertical=7.dp)){Text("🐾 ▾",fontSize=16.sp)}
                        DropdownMenu(expanded=monsterMenu,onDismissRequest={monsterMenu=false}) {
                            available.forEach { name->DropdownMenuItem(text={Text(name)},onClick={selectedMonster=name;monsterMenu=false}) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FieldRegionScreen(location:String,actionLabel:String,progress:Int,autoExplore:Boolean,onAutoExplore:(Boolean)->Unit,onAction:()->Unit,onRest:(Int)->Unit,onExplore:()->Unit,onHunt:(String)->Unit) {
    var selectedIcon by remember(location) { mutableStateOf("🧭") }
    var iconMenu by remember(location) { mutableStateOf(false) }
    var restMinutes by remember(location) { mutableIntStateOf(30) }
    var restMenu by remember(location) { mutableStateOf(false) }
    var selectedMonster by remember(location) { mutableStateOf("") }
    var monsterMenu by remember(location) { mutableStateOf(false) }
    val iconOptions = when(location) {
        "Заброшенная шахта" -> listOf("⛏️" to "Кирка","🪨" to "Молоток","🧭" to "Компас")
        "Небольшое поселение" -> listOf("🪓" to "Топор","🧺" to "Корзина","🌿" to "Сбор трав")
        "Болото" -> listOf("🌿" to "Серп","🧺" to "Корзина","🪓" to "Топор")
        "Подземелье" -> listOf("🕯️" to "Факел","🧭" to "Компас","🗝️" to "Ключ")
        "Город мёртвых" -> listOf("🪦" to "Лопата","🕯️" to "Фонарь","📿" to "Амулет")
        else -> listOf("🗡️" to "Клинок","🛡️" to "Щит","🧿" to "Оберег")
    }
    val enemyOptions = when(location) {
        "Заброшенная шахта" -> listOf("Пещерная крыса","Шахтный паук","Каменный голем")
        "Небольшое поселение" -> listOf("Бандит","Бандит-разведчик","Главарь бандитов")
        "Болото" -> listOf("Болотный слизень","Топяной волк","Болотный паук")
        "Подземелье" -> listOf("Скелет","Зомби","Рыцарь-нежить")
        "Город мёртвых" -> listOf("Скелет-воин","Зомби","Упырь")
        else -> listOf("Теневой зверь","Демон бездны","Страж бездны")
    }
    LaunchedEffect(location) { selectedIcon=iconOptions.first().first;selectedMonster=enemyOptions.first() }
    Column(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text(location,color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
            Text("Опасная локация охотничьих угодий. Действия расходуют время и могут привлечь монстров.",color=muted,fontSize=12.sp)
            Text("Исследование: $progress / 100",color=goldColor,fontWeight=FontWeight.Bold)
            LinearProgressIndicator(progress={ (progress/100f).coerceIn(0f,1f) },modifier=Modifier.fillMaxWidth().height(8.dp),color=Color(0xFF4DAD70),trackColor=panel)
        }
        Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp),verticalAlignment=Alignment.CenterVertically) {
                Button(onClick=onAction,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text(actionLabel,fontSize=12.sp)}
                Box {
                    OutlinedButton(onClick={iconMenu=true},contentPadding=PaddingValues(horizontal=12.dp,vertical=7.dp)){Text("$selectedIcon ▾",fontSize=18.sp)}
                    DropdownMenu(expanded=iconMenu,onDismissRequest={iconMenu=false}) {
                        iconOptions.forEach { (icon,label)->DropdownMenuItem(text={Text("$icon  $label")},onClick={selectedIcon=icon;iconMenu=false}) }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp),verticalAlignment=Alignment.CenterVertically) {
                Button(onClick={onRest(restMinutes)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp),colors=ButtonDefaults.buttonColors(containerColor=panel,contentColor=cream)){Text("Отдых",fontSize=12.sp)}
                Box {
                    OutlinedButton(onClick={restMenu=true},contentPadding=PaddingValues(horizontal=10.dp,vertical=7.dp)){Text(if(restMinutes==30)"30 мин. ▾" else if(restMinutes==60)"1 час ▾" else "2 часа ▾",fontSize=11.sp)}
                    DropdownMenu(expanded=restMenu,onDismissRequest={restMenu=false}) {
                        listOf(30 to "30 минут",60 to "1 час",120 to "2 часа").forEach { (mins,label)->DropdownMenuItem(text={Text(label)},onClick={restMinutes=mins;restMenu=false}) }
                    }
                }
            }
            if(progress < 100) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
                    Button(onClick=onExplore,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Исследовать",fontSize=12.sp)}
                    Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("Авто",color=cream,fontSize=9.sp);Switch(checked=autoExplore,onCheckedChange=onAutoExplore) }
                }
            } else {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
                    Button(onClick={onHunt(selectedMonster)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Охота",fontSize=12.sp)}
                    Box {
                        OutlinedButton(onClick={monsterMenu=true},contentPadding=PaddingValues(horizontal=10.dp,vertical=7.dp)){Text("🐾 ▾",fontSize=16.sp)}
                        DropdownMenu(expanded=monsterMenu,onDismissRequest={monsterMenu=false}) {
                            enemyOptions.forEach { name->DropdownMenuItem(text={Text(name)},onClick={selectedMonster=name;monsterMenu=false}) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BattleScreen(monster:FieldMonster,monsterHp:Int,monsterOv:Int,hp:Int,mp:Int,ov:Int,hpMax:Int,mpMax:Int,ovMax:Int,phase2:Boolean=false,damageNumbers:List<DamageNumber> = emptyList(),onDamageNumberExpired:(Long)->Unit,hpPotion:Item?,ovPotion:Item?,fireballLearned:Boolean,fireballCooldown:Boolean,onHpPotion:()->Unit,onOvPotion:()->Unit,onFireball:()->Unit,onEscape:()->Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.SpaceBetween) {
        Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(12.dp)).padding(10.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Text("${monster.name} • ${monster.rank} • Ур. ${monster.level}",color=cream,fontWeight=FontWeight.Bold)
                if(phase2) Text("ФАЗА II",color=Color(0xFFFF7770),fontWeight=FontWeight.Bold,fontSize=10.sp)
            }
            listOf(Triple("HP",monsterHp,monster.hp),Triple("MP",0,0),Triple("ОВ",monsterOv,monster.ov)).forEach { (n,v,mx) ->
                Text(if(mx>0)"$n $v/$mx" else "$n —",color=muted,fontSize=10.sp)
                LinearProgressIndicator(progress={if(mx>0)(v.toFloat()/mx).coerceIn(0f,1f) else 0f},modifier=Modifier.fillMaxWidth().height(5.dp),color=if(n=="HP")red else goldColor,trackColor=bg)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                val monsterRes=monsterIconRes(monster.name)
                if(monsterRes!=null) Image(painterResource(monsterRes),contentDescription=monster.name,modifier=Modifier.size(150.dp))
                Text(monster.name,color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
            }
            damageNumbers.forEach { number ->
                key(number.id) {
                    LaunchedEffect(number.id) { delay(850); onDamageNumberExpired(number.id) }
                    Text(number.value,color=Color(0xFFFF3434),fontSize=23.sp,fontWeight=FontWeight.Black,
                        modifier=Modifier.align(Alignment.Center).offset(x=((number.x-0.5f)*170f).dp,y=((number.y-0.5f)*170f).dp))
                }
            }
        }
        Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(12.dp)).padding(10.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick=onHpPotion,modifier=Modifier.weight(1f),enabled=hpPotion!=null,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF375B45))){Text(if(hpPotion!=null) "${hpPotion.name} ×${hpPotion.amount.toInt()}" else "Пусто",fontSize=9.sp,color=Color(0xFFFF7770))}
                Button(onClick=onOvPotion,modifier=Modifier.weight(1f),enabled=ovPotion!=null,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF375B45))){Text(if(ovPotion!=null) "${ovPotion.name} ×${ovPotion.amount.toInt()}" else "Пусто",fontSize=9.sp,color=Color(0xFFFFB347))}
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                repeat(5) { i ->
                    Button(onClick=onFireball,modifier=Modifier.weight(1f).height(48.dp),enabled=fireballLearned && i==0,contentPadding=PaddingValues(2.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF55432D),disabledContainerColor=Color(0xFF302920))){Text(if(i==0 && fireballLearned) if(fireballCooldown)"3с" else "🔥" else "—",fontSize=10.sp)}
                }
            }
            Button(onClick=onEscape,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=red)){Text("Сдаться")}
        }
    }
}

@Composable
private fun LocationScreen(location:String) {
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(Icons.Default.Place,null,tint=goldColor,modifier=Modifier.size(45.dp))
        Text(location,color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        Text(when(location){"Ворота"->"Выход из города.";"Замок"->"Здесь живёт король.";else->"Текущая локация."},color=muted)
    }
}
@Composable
private fun QuantitySlider(value: Double, maximum: Double, unit: String, onValueChange: (Double) -> Unit) {
    if (maximum <= 0.0) return
    val discrete = unit != "кг"
    val maxInt = if (discrete) kotlin.math.floor(maximum).toInt().coerceAtLeast(1) else 0
    val maxLabel = if (discrete) "$maxInt $unit" else "${format2(maximum)} $unit"
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text("Максимум: $maxLabel", color = muted, fontSize = 10.sp)
        }
        Slider(
            value = value.toFloat().coerceIn(0f, maximum.toFloat()),
            onValueChange = { raw -> onValueChange(if (discrete) raw.roundToInt().toDouble().coerceIn(0.0, maxInt.toDouble()) else round2(raw.toDouble())) },
            valueRange = 0f..maximum.toFloat().coerceAtLeast(0.01f),
            steps = if (discrete) (maxInt - 1).coerceIn(0, 999) else 0,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp)
        )
        val marks = if (discrete) {
            (0..4).map { (maxInt * it / 4.0).roundToInt() }.distinct()
        } else {
            (0..4).map { format2(maximum * it / 4.0) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            marks.forEach { mark -> Text(if (discrete) mark.toString() else mark.toString(), color = muted, fontSize = 9.sp) }
        }
    }
}

@Composable
private fun CharacterScreen(level:Int,xp:Int,free:Int,stats:Map<String,Int>,inventoryRefreshToken:Int,skillLevels:Map<String,Int>,skillXp:Map<String,Int>,inventory:List<Item>,equipment:Map<String,Item>,hp:Int,mp:Int,ov:Int,hpMax:Int,mpMax:Int,ovMax:Int,sub:Int,onSub:(Int)->Unit,onItem:(Item)->Unit,fireballLearned:Boolean,onFireball:()->Unit,onEquip:(String,Item)->Unit,onUnequip:(String)->Unit,expanded:String,onExpand:(String)->Unit,onImprove:(String)->Unit) {
    val descriptions=mapOf(
        "Сила" to "Влияет на общий переносимый вес и на количество обрабатываемого материала за раз. Отвечает за навык кузнечного дела и за урон ближним оружием.",
        "Ловкость" to "Влияет на скорость выполнения действий и точность движений. Отвечает за эффективность ремесленного дела и владение одноручным оружием и оружием дальнего боя.",
        "Выносливость" to "Увеличивает запас здоровья и количество ОВ. ОВ тратится во время работы или боя. Влияет на эффективность блокирования.",
        "Интеллект" to "Влияет на запас маны и эффективность работы с рунами. Отвечает за навык рунической гравировки и определяет количество доступных ячеек активных навыков.",
        "Удача" to "Я в такое не верю."
    )
    var draggedEquipmentItem by remember { mutableStateOf<Item?>(null) }
    var equipmentDragPosition by remember { mutableStateOf(Offset.Zero) }
    var inventoryDragOrigin by remember { mutableStateOf(Offset.Zero) }
    val equipmentSlotBounds = remember { mutableStateMapOf<String, Rect>() }
    val inventoryCellBounds = remember { mutableStateListOf<Rect?>().apply { repeat(30) { add(null) } } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start=13.dp,end=13.dp,top=13.dp,bottom=90.dp)) {
        Text("Персонаж",color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        Text("Уровень $level • Опыт $xp/${level*100} • Свободные очки: $free",color=goldColor,fontSize=11.sp)
        var characterDetail by remember { mutableStateOf("") }
        listOf(Triple("Здоровье",hp to hpMax,Color(0xFFC84D45)),Triple("Мана",mp to mpMax,Color(0xFF438BD4)),Triple("ОВ",ov to ovMax,Color(0xFFE2AD35))).forEach { (label,values,color) ->
            Row(Modifier.fillMaxWidth().then(if(label=="Здоровье") Modifier.clickable { characterDetail="Здоровье" } else Modifier),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Text(label,color=cream,fontSize=10.sp,modifier=Modifier.width(65.dp))
                Text("${values.first}/${values.second}",color=cream,fontSize=10.sp,modifier=Modifier.width(52.dp))
                LinearProgressIndicator(progress={(values.first.toFloat()/values.second.coerceAtLeast(1)).coerceIn(0f,1f)},modifier=Modifier.weight(1f).height(5.dp),color=color,trackColor=panel)
            }
        }
        Spacer(Modifier.height(8.dp));Text("ЭКИПИРОВКА",color=goldColor,fontWeight=FontWeight.Bold,fontSize=11.sp)
        val slotRows=listOf(listOf("","Голова",""),listOf("Кольцо 1","Ожерелье","Кольцо 2"),listOf("Наплечники","Тело","Оружие 1"),listOf("Перчатки","Поножи","Оружие 2"),listOf("Зелье 1","Ступни","Зелье 2"))
        slotRows.forEach { row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){row.forEach{slot->val item=equipment[slot] ?: when(slot){"Наплечники 2"->equipment["Наплечники"];else->null};val itemColor=when { item?.name?.contains("здоровья",true)==true -> Color(0xFFE05252); item?.name?.contains("маны",true)==true || item?.name?.contains("мана",true)==true -> Color(0xFF438BD4); item?.name?.contains("выносливости",true)==true -> Color(0xFFE2AD35); else -> if(item!=null)goldColor else muted };Box(Modifier.weight(1f).height(48.dp).padding(vertical=2.dp).onGloballyPositioned { if(slot.isNotBlank()) equipmentSlotBounds[slot]=Rect(it.positionInRoot(),it.positionInRoot()+Offset(it.size.width.toFloat(),it.size.height.toFloat())) }.then(if(item!=null) Modifier.pointerInput(slot,item.id){var origin=Offset.Zero;detectDragGestures(onDragStart={origin=equipmentSlotBounds[slot]?.topLeft?:Offset.Zero;equipmentDragPosition=origin+it},onDrag={change,delta->change.consume();equipmentDragPosition+=delta},onDragEnd={val target=inventoryCellBounds.mapIndexedNotNull{idx,r->r?.let{idx to kotlin.math.hypot((it.center.x-equipmentDragPosition.x).toDouble(),(it.center.y-equipmentDragPosition.y).toDouble())}}.minByOrNull{it.second};if(target!=null && target.second<180.0)onUnequip(slot)})} else Modifier).background(panel,RoundedCornerShape(7.dp)).clickable{if(item!=null)onItem(item)},contentAlignment=Alignment.Center){
            val secondShoulder=if(slot=="Наплечники") equipment["Наплечники 2"] else null
            if(slot=="Наплечники" && secondShoulder!=null) {
                Row(horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically) {
                    listOfNotNull(item,secondShoulder).distinctBy { it.id }.forEach { shoulderItem ->
                        Column(Modifier.weight(1f).clickable{onItem(shoulderItem)},horizontalAlignment=Alignment.CenterHorizontally) {
                            ItemIcon(shoulderItem,Modifier.size(18.dp))
                            Text(shoulderItem.name.take(8),color=goldColor,fontSize=7.sp,textAlign=TextAlign.Center,maxLines=1)
                        }
                    }
                }
            } else Column(horizontalAlignment=Alignment.CenterHorizontally){if(item!=null)ItemIcon(item,Modifier.size(22.dp));Text(item?.name?.take(12)?:slot,color=itemColor.copy(alpha=if(slot=="Наплечники 2")0.42f else 1f),fontSize=9.sp,textAlign=TextAlign.Center);if(item!=null && (slot.startsWith("Зелье") || slot=="Стрелы"))Text("×${item.amount.toInt()}",color=itemColor,fontSize=9.sp,fontWeight=FontWeight.Bold)}
        }}}}
        val attackRange=displayedAttackRange(equipment,stats,skillLevels)
        val characterWeapon=equipment["Оружие 1"]?:equipment["Оружие 2"]
        val shownEquipment=equipment.values.distinctBy{it.id}
        val shownWeaponSpeedMultiplier=(1.0+shownEquipment.sumOf{it.speedBonus}/100.0).coerceAtLeast(0.05)
        val shownSpeed=if(characterWeapon?.damageType?.contains("маг",true)==true) 0.0 else Math.pow(10.0,((stats["Ловкость"]?:5).toDouble()+shownEquipment.sumOf{it.agilityBonus})/50.0)*shownWeaponSpeedMultiplier
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Атака: ${attackRange.first}–${attackRange.second}",color=cream,fontSize=11.sp,modifier=Modifier.clickable { characterDetail="Атака" })
            Text("Защита: ${equipment.values.distinctBy{it.id}.sumOf{effectiveDefense(it)}.toInt()}",color=cream,fontSize=11.sp)
            Text("Скорость: ${format2(shownSpeed)}",color=cream,fontSize=11.sp,modifier=Modifier.clickable { characterDetail="Скорость" })
        }
        if(characterDetail.isNotEmpty()) {
            val baseAttackRange=displayedAttackRange(emptyMap(),stats,skillLevels)
            val baseSpeedValue=Math.pow(10.0,(stats["Ловкость"]?:5).toDouble()/50.0)
            val baseHpValue=100+20*(stats["Выносливость"]?:5)+5*level
            AlertDialog(onDismissRequest={characterDetail=""},title={Text(characterDetail,color=goldColor)},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
                when(characterDetail) {
                    "Атака" -> { Text("Без экипировки: ${baseAttackRange.first}–${baseAttackRange.second}",color=cream);Text("Влияние экипировки: ${attackRange.first-baseAttackRange.first} / ${attackRange.second-baseAttackRange.second}",color=muted);Text("После экипировки: ${attackRange.first}–${attackRange.second}",color=goldColor) }
                    "Здоровье" -> { Text("Без экипировки: $baseHpValue",color=cream);Text("Влияние экипировки: ${hpMax-baseHpValue}",color=muted);Text("После экипировки: $hpMax",color=goldColor) }
                    else -> { Text("Без экипировки: ${format2(baseSpeedValue)} атак/с",color=cream);Text("Влияние экипировки: ${format2(shownSpeed-baseSpeedValue)} атак/с",color=muted);Text("После экипировки: ${format2(shownSpeed)} атак/с",color=goldColor) }
                }
            }},confirmButton={TextButton(onClick={characterDetail=""}){Text("Закрыть",color=goldColor)}},containerColor=panel)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
            listOf("Инвентарь","Навыки","Характеристики").forEachIndexed{i,s->Button(onClick={onSub(i)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(3.dp),colors=ButtonDefaults.buttonColors(containerColor=if(sub==i)goldColor else panel,contentColor=if(sub==i)Color.Black else cream)){Text(s,fontSize=9.sp)}}
        }
        Spacer(Modifier.height(8.dp))
        when(sub) {
            0 -> {
                Text("ИНВЕНТАРЬ",color=goldColor,fontWeight=FontWeight.Bold)
                key(inventoryRefreshToken) {
                LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.height(260.dp),userScrollEnabled=false,verticalArrangement=Arrangement.spacedBy(5.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    items(30){i->val item=inventory.getOrNull(i);Box(Modifier.aspectRatio(1f).background(panel,RoundedCornerShape(7.dp)).onGloballyPositioned{inventoryDragOrigin=it.positionInRoot();inventoryCellBounds[i]=Rect(it.positionInRoot(),it.positionInRoot()+Offset(it.size.width.toFloat(),it.size.height.toFloat()))}.then(if(item!=null) Modifier.pointerInput(item.id){detectDragGestures(onDragStart={start->draggedEquipmentItem=item;equipmentDragPosition=inventoryDragOrigin+start},onDrag={change,delta->change.consume();equipmentDragPosition+=delta},onDragEnd={val target=equipmentSlotBounds.entries.minByOrNull{(_,r)->kotlin.math.hypot((r.center.x-equipmentDragPosition.x).toDouble(),(r.center.y-equipmentDragPosition.y).toDouble())}?.let{it.key to it.value};if(target!=null && kotlin.math.hypot((target.second.center.x-equipmentDragPosition.x).toDouble(),(target.second.center.y-equipmentDragPosition.y).toDouble())<180.0){onEquip(target.first,item!!)};draggedEquipmentItem=null})} else Modifier).clickable{item?.let(onItem)},contentAlignment=Alignment.Center){if(item!=null)Column(horizontalAlignment=Alignment.CenterHorizontally){ItemIcon(item,Modifier.size(27.dp));Text("${if(item.unit=="кг")format2(item.amount) else item.amount.toInt()} ${item.unit}",color=muted,fontSize=7.sp,textAlign=TextAlign.Center)}else Text("·",color=muted)}}
                }
                }
            }
            1 -> {
                Text("ПАССИВНЫЕ НАВЫКИ",color=goldColor,fontWeight=FontWeight.Bold)
                listOf("Кузнечное дело","Ремесленное дело","Руническая гравировка","Двуручное оружие","Одноручное оружие","Дальний бой","Блокирование").forEach{s->
                    val currentSkillLevel = (skillLevels[s] ?: 1).coerceAtLeast(1)
                    val currentSkillXp = (skillXp[s] ?: 0).coerceAtLeast(0)
                    val nextSkillXp = skillXpThreshold(s, currentSkillLevel)
                    val skillProgress = if(nextSkillXp == Long.MAX_VALUE) 0f else (currentSkillXp.toDouble() / nextSkillXp.toDouble()).toFloat().coerceIn(0f,1f)
                    Column(Modifier.fillMaxWidth().padding(vertical=5.dp)){Row{Text(s,color=cream,modifier=Modifier.weight(1f));Text("$currentSkillLevel",color=goldColor)};LinearProgressIndicator(progress={skillProgress},modifier=Modifier.fillMaxWidth(),color=goldColor);Text("$currentSkillXp/${if(nextSkillXp==Long.MAX_VALUE)"∞" else nextSkillXp.toString()}",color=muted,fontSize=9.sp)}
                }
                Text("АКТИВНЫЕ НАВЫКИ",color=goldColor,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
                val unlocked=5+(((stats["Интеллект"]?:5)+equipment.values.distinctBy{it.id}.sumOf{it.intelligenceBonus}.toInt())-5).coerceAtLeast(0)/5
                LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.height(150.dp),userScrollEnabled=false,horizontalArrangement=Arrangement.spacedBy(5.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    items(unlocked+1){i->
                        val hasFireball=fireballLearned && i==0
                        Box(Modifier.aspectRatio(1f).background(panel,RoundedCornerShape(7.dp)).clickable(enabled=hasFireball){onFireball()},contentAlignment=Alignment.Center){
                            Text(if(i>=unlocked)"🔒" else if(hasFireball)"🔥" else "+",color=if(i>=unlocked)muted else goldColor)
                        }
                    }
                }
            }
            else -> {
                Text("ХАРАКТЕРИСТИКИ",color=goldColor,fontWeight=FontWeight.Bold)
                listOf("Сила","Ловкость","Выносливость","Интеллект","Удача").forEach{s->
                    Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(9.dp)).clickable{onExpand(if(expanded==s)"" else s)}.padding(10.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically){Text(s,color=cream,modifier=Modifier.weight(1f));Text("${(stats[s]?:5)+equipment.values.distinctBy{it.id}.sumOf { item -> when(s) { "Сила" -> item.strengthBonus; "Ловкость" -> item.agilityBonus; "Выносливость" -> item.enduranceBonus; "Интеллект" -> item.intelligenceBonus; "Удача" -> item.luckBonus; else -> 0.0 } }.toInt()}",color=goldColor,fontWeight=FontWeight.Bold);TextButton(onClick={onImprove(s)},contentPadding=PaddingValues(horizontal=8.dp)){Text("+",color=if(free>0)goldColor else red,fontSize=19.sp)}}
                        if(expanded==s)Text(descriptions[s]?: "",color=muted,fontSize=11.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }
        }
    }
}
private data class ForgeLoad(val itemId: Int, val itemName: String, val source: String, val unit: String, val amount: Double, val sourceAmounts: Map<String, Double> = mapOf(source to amount), val template: Item? = null)
private data class ForgeNeed(val aliases: List<String>, val amount: Double, val unit: String = "кг")
private data class ForgeBlueprint(val name: String, val needs: List<ForgeNeed>, val minTemp: Int, val maxTemp: Int, val energyPerKg: Double, val outputName: String, val outputAmount: Double, val outputUnit: String = "кг", val description: String = "", val isWorkshop: Boolean = false, val rankedOutput: Boolean = false)

@Composable
private fun CreateScreen(inventory: MutableList<Item>, storage: MutableList<Item>, equipment: Map<String, Item>, skillLevels: Map<String, Int>, remainingCarry: Double, furnaceRank: Int, chestCapacity: Int, currentOv: Int, onConsumeOv: (Int) -> Unit, onAdvanceTime: (Int) -> Unit, onGainSkillXp: (String, Int) -> Unit, onInventoryChanged: () -> Unit) {
    val materialRankNames = listOf("F", "E", "D", "C", "B", "A", "S", "SS", "SSS")
    val coalNames = listOf("Бурый уголь", "Каменный уголь", "Крепкий уголь", "Чистый уголь", "Сердце вулкана")
    val coalEnergy = listOf(15.0, 30.0, 50.0, 100.0, 500.0)
    val coalColors = listOf(Color(0xFF72543B), Color(0xFF373737), Color(0xFF252525), Color(0xFFB8B8B8), Color(0xFFB64A27))
    val furnaceCapacities = listOf(5.0, 7.0, 10.0, 13.0, 17.0, 22.0, 28.0)
    val furnaceTemperatures = listOf(300, 500, 700, 1000, 1500, 2000, 3000)
    val furnaceCapacity = furnaceCapacities.getOrElse(furnaceRank.coerceIn(0,6)) { 5.0 }
    val furnaceMaxTemp = furnaceTemperatures.getOrElse(furnaceRank.coerceIn(0,6)) { 300 }
    val metalMaterials = listOf("Железо ", "Сталь", "Металл", "Титан", "Кобальт", "Чёрное железо", "Адамант", "Адамантий", "Орихалк", "Платина", "Серебро", "Золото", "Мифрил", "Драконья сталь")
    val woodMaterials = listOf("Древесина", "Дерево", "Древо", "Дуб", "Брус", "Бамбук", "Болотная древесина", "Железное дерево", "Магическое дерево", "Дерево жизни", "Дерево маны", "Древо стихий", "Древо пустоты", "Мировое древо")
    val leatherMaterials = listOf("Кожа", "Мягкая кожа", "Грубая кожа")
    val categories = linkedMapOf(
        "Оружие" to listOf("Кинжал", "Топор", "Секира", "Копьё", "Длинный меч", "Двуручный меч", "Кузнечный молот", "Боевой молот", "Кирка", "Сковорода", "Вилы"),
        "Экипировка" to listOf("Латный шлем", "Кольчужный шлем", "Кольчужная рубаха", "Латная кираса", "Кольчужные наручи", "Латные рукавицы", "Латные поножи", "Кольчужные поножи", "Латные сапоги", "Деревянный щит", "Металлический щит", "Тяжёлый металлический щит")
    )
    val workshopCategories = linkedMapOf(
        "Оружие" to listOf("Лук", "Дубинка", "Боевой посох", "Рогатка", "Бумеранг", "Скалка", "Метла"),
        "Вычинка" to listOf("Вычинка"),
        "Рукояти" to listOf("Короткая прямая", "Профилированная", "Удлинённая профилированная", "Длинная прямая", "Симметричная", "Удлинённая симметричная", "Короткая массивная", "Длинная массивная", "Изогнутая"),
        "Экипировка" to listOf("Полумаска кузнеца", "Кожаный шлем", "Кожаный нагрудник", "Фартук кузнеца", "Кожаный плащ", "Кожаные перчатки", "Кожаные штаны", "Кожаные сапоги"),
        "Разное" to listOf("Ведро", "Бочка", "Мешок", "Деревянные башмаки", "Рукавицы", "Коромысло", "Стремянка")
    )
    val catalogSpecs = mapOf(
        "Вычинка" to "Любая шкура. Выход кожи — 90% массы шкуры; ранг сохраняется.",
        "Сковорода" to "Металл — 0,85 кг; короткая прямая рукоять — 1 шт. (0,20 кг).",
        "Вилы" to "Металл — 0,80 кг; длинная прямая рукоять — 1 шт. (2,00 кг). Вес готового изделия — 2,80 кг.",
        "Деревянный щит" to "Древесина — 1,50 кг; кожа — 0,20 кг.",
        "Лук" to "Древесина — 1,50 кг; сухожилия — 2 шт.",
        "Дубинка" to "Древесина — 1,20 кг.",
        "Боевой посох" to "Древесина — 2,50 кг.",
        "Рогатка" to "Древесина — 0,30 кг; кожа — 0,05 кг.",
        "Бумеранг" to "Древесина — 0,80 кг.",
        "Скалка" to "Древесина — 1,00 кг.",
        "Метла" to "Древесина — 1,70 кг; кожа — 0,05 кг.",
        "Кожаный шлем" to "Необходимо: 0,50 кг кожи.",
        "Кожаный плащ" to "Необходимо: 0,70 кг кожи.",
        "Кожаный нагрудник" to "Необходимо: 1,20 кг кожи.",
        "Кожаные перчатки" to "Необходимо: 0,35 кг кожи.",
        "Кожаные штаны" to "Необходимо: 0,80 кг кожи.",
        "Кожаные сапоги" to "Необходимо: 0,60 кг кожи.",
        "Полумаска кузнеца" to "Необходимо: 0,25 кг кожи. Защищает лицо от пыли и искр.",
        "Фартук кузнеца" to "Необходимо: 1,00 кг кожи. Рабочий фартук для кузнечного и ремесленного дела.",
        "Ведро" to "Необходимо: 0,90 кг древесины.",
        "Бочка" to "Необходимо: 2,50 кг древесины и 0,40 кг металла для обручей.",
        "Мешок" to "Необходимо: 0,70 кг кожи.",
        "Деревянные башмаки" to "Необходимо: 1,20 кг древесины.",
        "Рукавицы" to "Необходимо: 0,30 кг кожи.",
        "Коромысло" to "Необходимо: 1,40 кг древесины.",
        "Стремянка" to "Необходимо: 2,80 кг древесины.",
        "Короткая прямая" to "1 шт. (0,20 кг; кожа — 0,02 кг)",
        "Профилированная" to "1 шт. (0,75 кг)",
        "Удлинённая профилированная" to "1 шт. (1,40 кг; кожа — 0,12 кг)",
        "Длинная прямая" to "1 шт. (2,00 кг)",
        "Симметричная" to "1 шт. (0,50 кг; кожа — 0,08 кг)",
        "Удлинённая симметричная" to "1 шт. (0,80 кг; кожа — 0,15 кг)",
        "Короткая массивная" to "1 шт. (0,60 кг)",
        "Длинная массивная" to "1 шт. (1,30 кг; кожа — 0,12 кг)",
        "Изогнутая" to "1 шт. (1,00 кг)",
        "Кинжал" to "Металл — 0,50 кг; короткая прямая рукоять — 1 шт. (0,20 кг).",
        "Топор" to "Металл — 2,00 кг; профилированная рукоять — 1 шт. (0,75 кг).",
        "Секира" to "Металл — 3,00 кг; удлинённая профилированная рукоять — 1 шт. (1,40 кг).",
        "Копьё" to "Металл — 1,00 кг; длинная прямая рукоять — 1 шт. (2,00 кг).",
        "Длинный меч" to "Металл — 2,40 кг; симметричная рукоять — 1 шт. (0,50 кг).",
        "Двуручный меч" to "Металл — 5,00 кг; удлинённая симметричная рукоять — 1 шт. (0,80 кг).",
        "Кузнечный молот" to "Металл — 1,60 кг; короткая массивная рукоять — 1 шт. (0,60 кг).",
        "Боевой молот" to "Металл — 3,60 кг; длинная массивная рукоять — 1 шт. (1,30 кг).",
        "Кирка" to "Металл — 2,40 кг; изогнутая рукоять — 1 шт. (1,00 кг).",
        "Латный шлем" to "2,00 кг металла",
        "Латные рукавицы" to "0,80 кг металла",
        "Латные поножи" to "1,50 кг металла",
        "Латные сапоги" to "1,00 кг металла",
        "Кольчужный шлем" to "0,50 кг металла и 0,15 кг кожи",
        "Кольчужная рубаха" to "2,00 кг металла и 0,60 кг кожи",
        "Кольчужные наручи" to "1,00 кг металла и 0,30 кг кожи",
        "Кольчужные поножи" to "1,20 кг металла и 0,40 кг кожи",
        "Металлический щит" to "4,00 кг металла",
        "Тяжёлый металлический щит" to "7,00 кг металла"
    )
    val catalogRequirements = mapOf(
        "Вычинка" to "Необходимо: 1,00 кг шкуры. Выход кожи — 90% массы шкуры, ранг сохраняется.",
        "Деревянный щит" to "Необходимо: 1,50 кг древесины и 0,20 кг кожи.",
        "Лук" to "Необходимо: 1,50 кг древесины и 2 сухожилия.",
        "Дубинка" to "Необходимо: 1,20 кг древесины.",
        "Боевой посох" to "Необходимо: 2,50 кг древесины.",
        "Рогатка" to "Необходимо: 0,30 кг древесины и 0,05 кг кожи.",
        "Бумеранг" to "Необходимо: 0,80 кг древесины.",
        "Скалка" to "Необходимо: 1,00 кг древесины.",
        "Метла" to "Необходимо: 1,70 кг древесины и 0,05 кг кожи.",
        "Короткая прямая" to "Необходимо: 0,18 кг древесины и 0,02 кг кожи.",
        "Профилированная" to "Необходимо: 0,75 кг древесины.",
        "Удлинённая профилированная" to "Необходимо: 1,28 кг древесины и 0,12 кг кожи.",
        "Длинная прямая" to "Необходимо: 2,00 кг древесины.",
        "Симметричная" to "Необходимо: 0,42 кг древесины и 0,08 кг кожи.",
        "Удлинённая симметричная" to "Необходимо: 0,65 кг древесины и 0,15 кг кожи.",
        "Короткая массивная" to "Необходимо: 0,60 кг древесины.",
        "Длинная массивная" to "Необходимо: 1,18 кг древесины и 0,12 кг кожи.",
        "Изогнутая" to "Необходимо: 1,00 кг древесины.",
        "Кожаный шлем" to "Необходимо: 0,50 кг кожи.",
        "Кожаный плащ" to "Необходимо: 0,70 кг кожи.",
        "Кожаный нагрудник" to "Необходимо: 1,20 кг кожи.",
        "Кожаные перчатки" to "Необходимо: 0,35 кг кожи.",
        "Кожаные штаны" to "Необходимо: 0,80 кг кожи.",
        "Кожаные сапоги" to "Необходимо: 0,60 кг кожи.",
        "Полумаска кузнеца" to "Необходимо: 0,25 кг кожи.",
        "Фартук кузнеца" to "Необходимо: 1,00 кг кожи.",
        "Кинжал" to "Необходимо: 0,50 кг металла и 0,20 кг готовой короткой прямой рукояти.",
        "Топор" to "Необходимо: 2,00 кг металла и 0,75 кг готовой профилированной рукояти.",
        "Секира" to "Необходимо: 3,00 кг металла и 1,40 кг готовой удлинённой профилированной рукояти.",
        "Копьё" to "Необходимо: 1,00 кг металла и 2,00 кг готовой длинной прямой рукояти.",
        "Длинный меч" to "Необходимо: 2,40 кг металла и 0,50 кг готовой симметричной рукояти.",
        "Двуручный меч" to "Необходимо: 5,00 кг металла и 0,80 кг готовой удлинённой симметричной рукояти.",
        "Кузнечный молот" to "Необходимо: 1,60 кг металла и 0,60 кг готовой короткой массивной рукояти.",
        "Боевой молот" to "Необходимо: 3,60 кг металла и 1,30 кг готовой длинной массивной рукояти.",
        "Кирка" to "Необходимо: 2,40 кг металла и 1,00 кг готовой изогнутой рукояти.",
        "Латный шлем" to "Необходимо: 2,00 кг металла.",
        "Латная кираса" to "Необходимо: 6,50 кг металла.",
        "Латные рукавицы" to "Необходимо: 0,80 кг металла.",
        "Латные поножи" to "Необходимо: 1,50 кг металла.",
        "Латные сапоги" to "Необходимо: 1,00 кг металла.",
        "Кольчужный шлем" to "Необходимо: 0,50 кг металла и 0,15 кг кожи.",
        "Кольчужная рубаха" to "Необходимо: 2,00 кг металла и 0,60 кг кожи.",
        "Кольчужные наручи" to "Необходимо: 1,00 кг металла и 0,30 кг кожи.",
        "Кольчужные поножи" to "Необходимо: 1,20 кг металла и 0,40 кг кожи.",
        "Металлический щит" to "Необходимо: 4,00 кг металла.",
        "Тяжёлый металлический щит" to "Необходимо: 7,00 кг металла."
    )
    val blueprints = listOf(
        ForgeBlueprint("Слитки", emptyList(),300,3000,0.0,"",0.0,description="Универсальная плавка одного типа руды в соответствующий металл."),
        ForgeBlueprint("Кузнечный молот", listOf(ForgeNeed(metalMaterials,1.60),ForgeNeed(listOf("Короткая массивная рукоять"),1.0,"шт.")),300,1000,5.0,"Кузнечный молот",1.0,"шт.","Одноручный кузнечный молот.",rankedOutput=true),
        ForgeBlueprint("Сковорода", listOf(ForgeNeed(metalMaterials,0.85),ForgeNeed(listOf("Короткая прямая рукоять"),1.0,"шт.")),300,1000,5.0,"Сковорода",1.0,"шт.","Одноручное дробящее оружие. Металл 0,85 кг и короткая прямая рукоять 1 шт. (0,20 кг).",rankedOutput=true),
        ForgeBlueprint("Вилы", listOf(ForgeNeed(metalMaterials,0.80),ForgeNeed(listOf("Длинная прямая рукоять"),1.0,"шт.")),300,1000,5.0,"Вилы",1.0,"шт.","Двуручное колющее оружие. Металл 0,80 кг и длинная прямая рукоять 1 шт. (2,00 кг). Вес готового изделия 2,80 кг.",rankedOutput=true),
        ForgeBlueprint("Боевой молот", listOf(ForgeNeed(metalMaterials,3.60),ForgeNeed(listOf("Длинная массивная рукоять"),1.0,"шт.")),300,1000,5.0,"Боевой молот",1.0,"шт.","Тяжёлое двуручное дробящее оружие.",rankedOutput=true),
        ForgeBlueprint("Двуручный меч", listOf(ForgeNeed(metalMaterials,5.00),ForgeNeed(listOf("Удлинённая симметричная рукоять"),1.0,"шт.")),300,1000,5.0,"Двуручный меч",1.0,"шт.","Двуручный меч с рубящим уроном.",rankedOutput=true),
        ForgeBlueprint("Копьё", listOf(ForgeNeed(metalMaterials,1.00),ForgeNeed(listOf("Длинная прямая рукоять"),1.0,"шт.")),300,1000,5.0,"Копьё",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Длинный меч", listOf(ForgeNeed(metalMaterials,2.40),ForgeNeed(listOf("Симметричная рукоять"),1.0,"шт.")),300,1000,5.0,"Длинный меч",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Кинжал", listOf(ForgeNeed(metalMaterials,0.50),ForgeNeed(listOf("Короткая прямая рукоять"),1.0,"шт.")),300,1000,5.0,"Кинжал",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Топор", listOf(ForgeNeed(metalMaterials,2.00),ForgeNeed(listOf("Профилированная рукоять"),1.0,"шт.")),300,1000,5.0,"Топор",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Секира", listOf(ForgeNeed(metalMaterials,3.00),ForgeNeed(listOf("Удлинённая профилированная рукоять"),1.0,"шт.")),300,1000,5.0,"Секира",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Кирка", listOf(ForgeNeed(metalMaterials,2.40),ForgeNeed(listOf("Изогнутая рукоять"),1.0,"шт.")),300,1000,5.0,"Кирка",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Латный шлем", listOf(ForgeNeed(metalMaterials,2.0)),300,1000,5.0,"Латный шлем",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Кольчужный шлем", listOf(ForgeNeed(metalMaterials,0.5),ForgeNeed(leatherMaterials,0.15)),300,1000,5.0,"Кольчужный шлем",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Кольчужная рубаха", listOf(ForgeNeed(metalMaterials,2.0),ForgeNeed(leatherMaterials,0.60)),300,1000,5.0,"Кольчужная рубаха",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Латная кираса", listOf(ForgeNeed(metalMaterials,6.5)),300,1000,5.0,"Латная кираса",1.0,"шт.","Единая латная защита корпуса и обоих плеч.",rankedOutput=true),
        ForgeBlueprint("Кольчужные наручи", listOf(ForgeNeed(metalMaterials,1.0),ForgeNeed(leatherMaterials,0.30)),300,1000,5.0,"Кольчужные наручи",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Латные рукавицы", listOf(ForgeNeed(metalMaterials,0.8)),300,1000,5.0,"Латные рукавицы",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Латные поножи", listOf(ForgeNeed(metalMaterials,1.5)),300,1000,5.0,"Латные поножи",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Кольчужные поножи", listOf(ForgeNeed(metalMaterials,1.2),ForgeNeed(leatherMaterials,0.40)),300,1000,5.0,"Кольчужные поножи",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Латные сапоги", listOf(ForgeNeed(metalMaterials,1.0)),300,1000,5.0,"Латные сапоги",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Деревянный щит", listOf(ForgeNeed(woodMaterials,1.5),ForgeNeed(leatherMaterials,0.2)),300,1000,5.0,"Деревянный щит",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Металлический щит", listOf(ForgeNeed(metalMaterials,4.0)),300,1000,5.0,"Металлический щит",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Тяжёлый металлический щит", listOf(ForgeNeed(metalMaterials,7.0)),300,1000,5.0,"Тяжёлый металлический щит",1.0,"шт.",rankedOutput=true),
        ForgeBlueprint("Наконечники", listOf(ForgeNeed(metalMaterials,0.2)),300,1000,5.0,"Наконечники",1.0),
        ForgeBlueprint("Ожерелье", listOf(ForgeNeed(metalMaterials,0.2)),300,1000,5.0,"Ожерелье",1.0,"шт."),
        ForgeBlueprint("Кольца", listOf(ForgeNeed(metalMaterials,0.1)),300,1000,5.0,"Кольца",1.0,"шт."),
        ForgeBlueprint("Сельскохозяйственный инструмент", listOf(ForgeNeed(metalMaterials,0.8),ForgeNeed(woodMaterials,0.4)),300,1000,5.0,"Сельскохозяйственный инструмент",1.0,"шт."),
        ForgeBlueprint("Лук",listOf(ForgeNeed(woodMaterials,1.50,"кг"),ForgeNeed(listOf("Сухожилие"),2.0,"шт.")),0,0,0.0,"Лук",1.0,"шт.","Простое дальнобойное оружие, позволяющее атаковать противников на расстоянии. Дальность: высокая.",true,rankedOutput=true),
        ForgeBlueprint("Дубинка",listOf(ForgeNeed(woodMaterials,1.20,"кг")),0,0,0.0,"Дубинка",1.0,"шт.","Тяжёлая деревянная палка, подходящая для простых и сильных ударов.",true,rankedOutput=true),
        ForgeBlueprint("Боевой посох",listOf(ForgeNeed(woodMaterials,2.50,"кг")),0,0,0.0,"Боевой посох",1.0,"шт.","Длинная деревянная палка, позволяющая держать противника на расстоянии и отражать удары.",true,rankedOutput=true),
        ForgeBlueprint("Рогатка",listOf(ForgeNeed(woodMaterials,0.30,"кг"),ForgeNeed(listOf("Кожа"),0.05,"кг")),0,0,0.0,"Рогатка",1.0,"шт.","Лёгкое метательное оружие для атак на расстоянии.",true,rankedOutput=true),
        ForgeBlueprint("Бумеранг",listOf(ForgeNeed(woodMaterials,0.80,"кг")),0,0,0.0,"Бумеранг",1.0,"шт.","Лёгкое метательное оружие, которое возвращается после броска.",true,rankedOutput=true),
        ForgeBlueprint("Скалка",listOf(ForgeNeed(woodMaterials,1.00,"кг")),0,0,0.0,"Скалка",1.0,"шт.","Проверенное поколениями оружие домашнего воспитания.",true,rankedOutput=true),
        ForgeBlueprint("Метла",listOf(ForgeNeed(woodMaterials,1.70,"кг"),ForgeNeed(listOf("Кожа"),0.05,"кг")),0,0,0.0,"Метла",1.0,"шт.","Оружие уборщиков и гроза пыльных подземелий.",true,rankedOutput=true),
        ForgeBlueprint("Вычинка",listOf(ForgeNeed(listOf("Шкура"),1.0,"кг")),0,0,0.0,"Кожа",1.0,"кг","Выделка шкуры в кожу того же ранга. Выход — 90% исходной массы.",true,rankedOutput=true),
        ForgeBlueprint("Короткая прямая",listOf(ForgeNeed(woodMaterials,0.18,"кг"),ForgeNeed(leatherMaterials,0.02,"кг")),0,0,0.0,"Короткая прямая рукоять",1.0,"шт.","Короткая прямая рукоять.",true,rankedOutput=true),
        ForgeBlueprint("Профилированная",listOf(ForgeNeed(woodMaterials,0.75,"кг")),0,0,0.0,"Профилированная рукоять",1.0,"шт.","Профилированная рукоять.",true,rankedOutput=true),
        ForgeBlueprint("Удлинённая профилированная",listOf(ForgeNeed(woodMaterials,1.28,"кг"),ForgeNeed(leatherMaterials,0.12,"кг")),0,0,0.0,"Удлинённая профилированная рукоять",1.0,"шт.","Удлинённая профилированная рукоять.",true,rankedOutput=true),
        ForgeBlueprint("Длинная прямая",listOf(ForgeNeed(woodMaterials,2.00,"кг")),0,0,0.0,"Длинная прямая рукоять",1.0,"шт.","Длинная прямая рукоять.",true,rankedOutput=true),
        ForgeBlueprint("Симметричная",listOf(ForgeNeed(woodMaterials,0.42,"кг"),ForgeNeed(leatherMaterials,0.08,"кг")),0,0,0.0,"Симметричная рукоять",1.0,"шт.","Симметричная рукоять.",true,rankedOutput=true),
        ForgeBlueprint("Удлинённая симметричная",listOf(ForgeNeed(woodMaterials,0.65,"кг"),ForgeNeed(leatherMaterials,0.15,"кг")),0,0,0.0,"Удлинённая симметричная рукоять",1.0,"шт.","Удлинённая симметричная рукоять.",true,rankedOutput=true),
        ForgeBlueprint("Короткая массивная",listOf(ForgeNeed(woodMaterials,0.60,"кг")),0,0,0.0,"Короткая массивная рукоять",1.0,"шт.","Короткая массивная рукоять.",true,rankedOutput=true),
        ForgeBlueprint("Длинная массивная",listOf(ForgeNeed(woodMaterials,1.18,"кг"),ForgeNeed(leatherMaterials,0.12,"кг")),0,0,0.0,"Длинная массивная рукоять",1.0,"шт.","Длинная массивная рукоять.",true,rankedOutput=true),
        ForgeBlueprint("Изогнутая",listOf(ForgeNeed(woodMaterials,1.00,"кг")),0,0,0.0,"Изогнутая рукоять",1.0,"шт.","Изогнутая рукоять.",true,rankedOutput=true),
        ForgeBlueprint("Кожаный шлем",listOf(ForgeNeed(leatherMaterials,0.5,"кг")),0,0,0.0,"Кожаный шлем",1.0,"шт.","Кожаный шлем.",true,rankedOutput=true),
        ForgeBlueprint("Кожаный нагрудник",listOf(ForgeNeed(leatherMaterials,1.2,"кг")),0,0,0.0,"Кожаный нагрудник",1.0,"шт.","Кожаный нагрудник.",true,rankedOutput=true),
        ForgeBlueprint("Кожаный плащ",listOf(ForgeNeed(leatherMaterials,0.7,"кг")),0,0,0.0,"Кожаный плащ",1.0,"шт.","Лёгкий кожаный плащ, защищающий плечи.",true,rankedOutput=true),
        ForgeBlueprint("Кожаные перчатки",listOf(ForgeNeed(leatherMaterials,0.35,"кг")),0,0,0.0,"Кожаные перчатки",1.0,"шт.","Кожаные перчатки.",true,rankedOutput=true),
        ForgeBlueprint("Кожаные штаны",listOf(ForgeNeed(leatherMaterials,0.8,"кг")),0,0,0.0,"Кожаные штаны",1.0,"шт.","Кожаные штаны.",true,rankedOutput=true),
        ForgeBlueprint("Кожаные сапоги",listOf(ForgeNeed(leatherMaterials,0.6,"кг")),0,0,0.0,"Кожаные сапоги",1.0,"шт.","Кожаные сапоги.",true,rankedOutput=true),
        ForgeBlueprint("Полумаска кузнеца",listOf(ForgeNeed(leatherMaterials,0.25,"кг")),0,0,0.0,"Полумаска кузнеца",1.0,"шт.","Кожаная полумаска для защиты лица от пыли и искр. Бонус скорости изготовления предметов того же ранга: 5%.",true,rankedOutput=true),
        ForgeBlueprint("Фартук кузнеца",listOf(ForgeNeed(leatherMaterials,1.00,"кг")),0,0,0.0,"Фартук кузнеца",1.0,"шт.","Прочный рабочий фартук. Бонус скорости изготовления предметов того же ранга: 5%.",true,rankedOutput=true),
        ForgeBlueprint("Ведро",listOf(ForgeNeed(woodMaterials,0.90,"кг")),0,0,0.0,"Ведро",1.0,"шт.","Главное — не перепутать шлем с ёмкостью для воды.",true,rankedOutput=true),
        ForgeBlueprint("Бочка",listOf(ForgeNeed(woodMaterials,2.50,"кг"),ForgeNeed(metalMaterials,0.40,"кг")),0,0,0.0,"Бочка",1.0,"шт.","Надёжная защита. Правда, пролезать в двери неудобно.",true,rankedOutput=true),
        ForgeBlueprint("Мешок",listOf(ForgeNeed(leatherMaterials,0.70,"кг")),0,0,0.0,"Мешок",1.0,"шт.","Делает каждый шаг похожим на прыжок в мешке.",true,rankedOutput=true),
        ForgeBlueprint("Деревянные башмаки",listOf(ForgeNeed(woodMaterials,1.20,"кг")),0,0,0.0,"Деревянные башмаки",1.0,"шт.","Слышно издалека. Зато пальцы ног целы.",true,rankedOutput=true),
        ForgeBlueprint("Рукавицы",listOf(ForgeNeed(leatherMaterials,0.30,"кг")),0,0,0.0,"Рукавицы",1.0,"шт.","Теперь даже кулаками можно забивать гвозди.",true,rankedOutput=true),
        ForgeBlueprint("Коромысло",listOf(ForgeNeed(woodMaterials,1.40,"кг")),0,0,0.0,"Коромысло",1.0,"шт.","Можно носить вёдра. А можно просто носить коромысло.",true,rankedOutput=true),
        ForgeBlueprint("Стремянка",listOf(ForgeNeed(woodMaterials,2.80,"кг")),0,0,0.0,"Стремянка",1.0,"шт.","Теперь ты выше остальных. Буквально.",true,rankedOutput=true)
    )
    val rooms = listOf("Мастерская", "Кузница", "Ручная гравировка")
    var room by remember { mutableStateOf(rooms[0]) }
    var expandedGroup by remember { mutableStateOf("") }
    var expandedSubcategory by remember { mutableStateOf("") }
    var furnaceOn by remember { mutableStateOf(false) }
    var workshopMode by remember { mutableStateOf(false) }
    var selectedBlueprint by remember { mutableStateOf<ForgeBlueprint?>(null) }
    var selectedCatalogItem by remember { mutableStateOf<String?>(null) }
    var loaded by remember { mutableStateOf(listOf<ForgeLoad?>(null,null,null,null,null)) }
    var fuelName by remember { mutableStateOf("") }
    var coalMenuExpanded by remember { mutableStateOf(false) }
    var temperature by remember { mutableFloatStateOf(0f) }
    var temperatureSelected by remember { mutableStateOf(false) }
    var activeSlot by remember { mutableIntStateOf(-1) }
    var drawerTab by remember { mutableStateOf("Инвентарь") }
    var drawerItem by remember { mutableStateOf<Item?>(null) }
    var drawerSource by remember { mutableStateOf("Инвентарь") }
    var transferAmount by remember { mutableStateOf("0") }
    var craftMessage by remember { mutableStateOf("") }
    var dragPayload by remember { mutableStateOf<Pair<Item, String>?>(null) }
    var dragPosition by remember { mutableStateOf(Offset.Zero) }
    // Свободный переносимый вес расходуется при каждом возврате материалов или выдаче изделия.
    var carryBudget = remainingCarry.coerceAtLeast(0.0)
    fun addByCarry(item: Item, amount: Double = item.amount) {
        val safeAmount = round2(amount)
        val totalWeight = round2(safeAmount * item.weightEach)
        if (totalWeight <= carryBudget + 0.0001) {
            addToStack(inventory, item, safeAmount)
            carryBudget = (carryBudget - totalWeight).coerceAtLeast(0.0)
            onInventoryChanged()
        } else if (storage.any { sameStack(it, item) } || storage.size < chestCapacity) {
            addToStack(storage, item, safeAmount)
            onInventoryChanged()
        } else {
            addToStack(inventory, item, safeAmount)
            craftMessage = "Сундук заполнен: предмет оставлен в инвентаре."
            onInventoryChanged()
        }
    }
    var slotBounds by remember { mutableStateOf(List<Rect?>(5) { null }) }
    val allItems = inventory + storage
    fun fuelAvailable(name: String) = allItems.filter { it.name == name }.sumOf { it.amount }
    fun fuelTotal(name: String) = fuelAvailable(name)
    val cheapestAvailableCoal = coalNames.firstOrNull { fuelAvailable(it) > 0.0001 } ?: ""
    LaunchedEffect(furnaceOn, allItems.map { it.name to it.amount }) {
        if (furnaceOn && (fuelName.isBlank() || fuelAvailable(fuelName) <= 0.0001)) fuelName = cheapestAvailableCoal
    }
    fun isOreName(name: String) = name.contains("руда", ignoreCase = true)
    data class OreSmeltingInfo(val outputName: String, val rank: String, val requiredTemp: Int, val energyPerKg: Double)
    fun oreInfo(name: String): OreSmeltingInfo? = when {
        name.contains("Железная руда F", true) -> OreSmeltingInfo("Железо F", "F", 300, 5.0)
        name.contains("Серебряная руда E", true) -> OreSmeltingInfo("Серебро E", "E", 500, 10.0)
        name.contains("Золотая руда D", true) -> OreSmeltingInfo("Золото D", "D", 700, 25.0)
        name.contains("Титановая руда D", true) -> OreSmeltingInfo("Титан D", "D", 700, 25.0)
        name.contains("Платиновая руда C", true) -> OreSmeltingInfo("Платина C", "C", 1000, 40.0)
        name.contains("Орихалковая руда B", true) -> OreSmeltingInfo("Орихалк B", "B", 1500, 65.0)
        name.contains("Адамантовая руда A", true) -> OreSmeltingInfo("Адамантий A", "A", 2000, 100.0)
        name.contains("Мифриловая руда S", true) -> OreSmeltingInfo("Мифрил S", "S", 2500, 160.0)
        name.contains("Драконья руда SS", true) -> OreSmeltingInfo("Драконья сталь SS", "SS", 2800, 250.0)
        name.contains("Руда бездны SSS", true) -> OreSmeltingInfo("Металл бездны SSS", "SSS", 3000, 400.0)
        else -> null
    }
    fun loadedKg() = loaded.filterNotNull().sumOf { it.amount * (it.template?.weightEach ?: 1.0) }
    fun freeFurnaceKg() = (furnaceCapacity - loadedKg()).coerceAtLeast(0.0)
    fun matching(need: ForgeNeed): List<Pair<Item,String>> {
        val result = mutableListOf<Pair<Item,String>>()
        inventory.filter { it.unit == need.unit && need.aliases.any { a -> it.name.contains(a,true) } }.forEach { result.add(it to "Инвентарь") }
        storage.filter { it.unit == need.unit && need.aliases.any { a -> it.name.contains(a,true) } }.forEach { result.add(it to "Сундук") }
        return result
    }
    fun loadedAmount(need: ForgeNeed) = loaded.filterNotNull().filter { it.unit == need.unit && need.aliases.any { a -> it.itemName.contains(a,true) } }.sumOf { it.amount }
    fun energyRequired(bp: ForgeBlueprint): Double {
        if (bp.name == "Слитки") {
            val ore = loaded.filterNotNull().firstOrNull() ?: return 0.0
            val info = oreInfo(ore.itemName) ?: return 0.0
            return ore.amount * info.energyPerKg
        }
        return loaded.filterNotNull().filter { it.unit == "кг" && metalMaterials.any { metal -> it.itemName.contains(metal,true) } }.sumOf { it.amount } * bp.energyPerKg
    }
    fun fuelNeed(bp: ForgeBlueprint) = energyRequired(bp) / (coalEnergy.getOrElse(coalNames.indexOf(fuelName)) { 1.0 })
    fun consumeFromSources(name: String, amount: Double) {
        var left = round2(amount)
        var consumedAny = false
        listOf(inventory,storage).forEach { source ->
            source.filter { it.name == name }.toList().forEach { item ->
                if (left > 0.000001) {
                    val used = round2(minOf(item.amount,left))
                    if (item.amount <= used + 0.000001) source.remove(item)
                    else { val idx=source.indexOf(item); if(idx>=0) source[idx]=item.copy(amount=round2(item.amount-used)) }
                    left = round2(left-used)
                    if(source === inventory) carryBudget += used * item.weightEach
                    consumedAny = consumedAny || used > 0.0
                }
            }
        }
        if(consumedAny) onInventoryChanged()
    }
    fun clearLoadedMaterials() {
        loaded = listOf(null,null,null,null,null)
    }
    fun returnLoadedMaterials() {
        loaded.filterNotNull().forEach { l ->
            val origins = l.sourceAmounts.ifEmpty { mapOf(l.source to l.amount) }
            origins.forEach { (sourceName, amount) ->
                val template = (l.template ?: Item(l.itemId,l.itemName,"Материал из печи",amount,l.unit,1.0)).copy(amount=amount)
                addByCarry(template,amount)
            }
        }
        clearLoadedMaterials()
    }
    fun consumeFuel(name: String, amount: Double) = consumeFromSources(name,amount)
    val coalEnergyAvailable = coalNames.indices.sumOf { idx -> fuelTotal(coalNames[idx]) * coalEnergy[idx] }
    Column(Modifier.fillMaxSize().pointerInput(room) {
        var horizontalDrag = 0f
        detectHorizontalDragGestures(onHorizontalDrag={ change, amount -> horizontalDrag += amount; change.consume() }, onDragEnd={
            if(horizontalDrag < -70f) { room=rooms[(rooms.indexOf(room)+1).coerceAtMost(rooms.lastIndex)];expandedGroup="";expandedSubcategory="" }
            else if(horizontalDrag > 70f) { room=rooms[(rooms.indexOf(room)-1).coerceAtLeast(0)];expandedGroup="";expandedSubcategory="" }
            horizontalDrag=0f
        }, onDragCancel={horizontalDrag=0f})
    }.verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text(if(room=="Мастерская")"Посмотри чертёж перед началом изготовления" else if(room=="Кузница")"Чертежи кузницы" else "Чертежи ручной гравировки",color=cream,fontSize=19.sp,fontWeight=FontWeight.Bold)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            rooms.forEach { r -> Button(onClick={room=r;expandedGroup=""},modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp),colors=ButtonDefaults.buttonColors(containerColor=if(room==r)goldColor else panel,contentColor=if(room==r)Color.Black else cream)){Text(r,fontSize=10.sp)} }
        }
        if(room=="Кузница") {
        Text("Уголь в сундуке и в инвентаре",color=goldColor,fontWeight=FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            coalNames.forEachIndexed { idx,name ->
                Column(Modifier.weight(1f).background(panel,RoundedCornerShape(8.dp)).padding(vertical=6.dp,horizontal=2.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                    val coalRes=listOf(R.drawable.icon_coal_brown,R.drawable.icon_coal_stone,R.drawable.icon_coal_strong,R.drawable.icon_coal_clean,R.drawable.icon_coal_volcano_heart)[idx]
                        Image(painterResource(coalRes),contentDescription=name,modifier=Modifier.size(28.dp,22.dp))
                    Text("${"%.2f".format(fuelTotal(name))} кг",color=cream,fontSize=8.sp)
                    Text("${coalEnergy[idx].toInt()} МДж/кг",color=muted,fontSize=7.sp,textAlign=TextAlign.Center)
                }
            }
        }
        }
        if(room=="Кузница" || room=="Мастерская") {
            val visibleCategories = if(room=="Кузница") categories else workshopCategories
            visibleCategories.forEach { (group,items) ->
                Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(9.dp)).padding(10.dp)) {
                    Row(Modifier.fillMaxWidth().clickable{expandedGroup=if(expandedGroup==group)"" else group},verticalAlignment=Alignment.CenterVertically) {
                        Text(group,color=goldColor,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                        Icon(if(expandedGroup==group)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null,tint=goldColor)
                    }
                    if(expandedGroup==group) items.forEach { itemName ->
                        Text(
                            "• $itemName",
                            color=cream,
                            fontSize=13.sp,
                            modifier=Modifier.fillMaxWidth().clickable { selectedCatalogItem=itemName }.padding(start=8.dp,top=8.dp,bottom=8.dp)
                        )
                    }
                }
            }
        } else {
            val list = if(room=="Мастерская") listOf("Обработка кожи","Обработка древесины","Ремесленные изделия") else listOf("Рунические схемы","Рунические материалы","Гравировка предметов")
            list.forEach { group ->
                Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(9.dp)).padding(12.dp)) {
                    Row(Modifier.fillMaxWidth().clickable{expandedGroup=if(expandedGroup==group)"" else group}) {
                        Text(group,color=goldColor,modifier=Modifier.weight(1f));Icon(Icons.Default.ExpandMore,null,tint=goldColor)
                    }
                    if(expandedGroup==group) Text(if(room=="Мастерская")"Чертежи обработки кожи и древесины." else "Чертежи рун и гравировки.",color=cream,fontSize=12.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick={
            if(room=="Мастерская") {
                workshopMode=true;furnaceOn=true;loaded=listOf(null,null,null,null,null);selectedBlueprint=null;fuelName="";temperature=0f;temperatureSelected=false
            } else if(room=="Кузница" && coalEnergyAvailable+0.0001 >= 5.0) {
                var left=5.0
                coalNames.forEachIndexed { idx,n ->
                    if(left>0.000001) { val have=fuelTotal(n);val take=minOf(have,left/coalEnergy[idx]);if(take>0) { consumeFuel(n,take);left-=take*coalEnergy[idx] } }
                }
                workshopMode=false;furnaceOn=true;loaded=listOf(null,null,null,null,null);selectedBlueprint=null;fuelName="";temperature=0f;temperatureSelected=false
                craftMessage="Печь растоплена. Потрачено 5 МДж."
            }
        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black),enabled=room=="Мастерская" || (room=="Кузница" && coalEnergyAvailable+0.0001>=5.0)) { Text(when(room){"Мастерская"->"Создать";"Кузница"->"Растопить печь · 5 МДж";else->"Раздел в разработке"}) }
        if(craftMessage.isNotBlank()) Text(craftMessage,color=goldColor,fontSize=12.sp)
    }
    selectedCatalogItem?.let { catalogItem ->
        AlertDialog(
            onDismissRequest={selectedCatalogItem=null},
            containerColor=panel,
            title={Text(catalogItem,color=goldColor,fontWeight=FontWeight.Bold)},
            text={
                Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("Необходимые материалы",color=goldColor,fontWeight=FontWeight.Bold)
                    Text(catalogRequirements[catalogItem] ?: "Требования к изготовлению не указаны.",color=cream)
                    Text("Используемые материалы",color=goldColor,fontWeight=FontWeight.Bold)
                    Text(catalogSpecs[catalogItem] ?: "Состав используемых материалов не указан.",color=cream)
                }
            },
            confirmButton={TextButton(onClick={selectedCatalogItem=null}){Text("Закрыть",color=goldColor)}}
        )
    }
    if(furnaceOn) Dialog(onDismissRequest={},properties=DialogProperties(usePlatformDefaultWidth=false)) {
        val availableBlueprints = blueprints.filter { it.isWorkshop==workshopMode }
        val bp=selectedBlueprint
        val isSmelting = !workshopMode && bp?.name == "Слитки"
        val oreLoad = loaded.filterNotNull().firstOrNull()
        val oreInfoSelected = if(isSmelting) oreLoad?.let { oreInfo(it.itemName) } else null
        val singleOreOnly = !isSmelting || (loaded.filterNotNull().size == 1 && oreLoad != null && oreInfoSelected != null && oreLoad.unit == "кг")
        val enoughMaterials = bp!=null && if(isSmelting) singleOreOnly && (oreLoad?.amount ?: 0.0) > 0.0 else bp.needs.all { loadedAmount(it)+0.0001>=it.amount }
        fun rankOf(text:String):Int { val token=materialRankNames.firstOrNull { text.trim().endsWith(" $it", true) };return materialRankNames.indexOf(token).takeIf{it>=0}?:0 }
        val baseCraftMinutes = mapOf(
            "Кинжал" to 20, "Топор" to 35, "Секира" to 50, "Копьё" to 30, "Длинный меч" to 40, "Двуручный меч" to 60,
            "Кузнечный молот" to 35, "Боевой молот" to 55, "Кирка" to 40, "Сковорода" to 20, "Вилы" to 25,
            "Латный шлем" to 35, "Кольчужный шлем" to 25, "Кольчужная рубаха" to 60, "Латная кираса" to 95, "Кольчужные наручи" to 40, "Латные рукавицы" to 25, "Латные поножи" to 40,
            "Кольчужные поножи" to 45, "Латные сапоги" to 30, "Деревянный щит" to 25, "Металлический щит" to 50,
            "Тяжёлый металлический щит" to 75, "Наконечники" to 10, "Ожерелье" to 15, "Кольца" to 10,
            "Сельскохозяйственный инструмент" to 20, "Лук" to 30, "Дубинка" to 15, "Боевой посох" to 30,
            "Рогатка" to 15, "Бумеранг" to 20, "Скалка" to 15, "Метла" to 15,
            "Короткая прямая" to 8, "Профилированная" to 12, "Удлинённая профилированная" to 20, "Длинная прямая" to 15,
            "Симметричная" to 12, "Удлинённая симметричная" to 18, "Короткая массивная" to 12, "Длинная массивная" to 20,
            "Изогнутая" to 15, "Вычинка" to 30, "Кожаный шлем" to 15, "Кожаный нагрудник" to 30, "Кожаный плащ" to 20,
            "Кожаные перчатки" to 15, "Кожаные штаны" to 25, "Кожаные сапоги" to 20,
            "Полумаска кузнеца" to 12, "Фартук кузнеца" to 25,
            "Ведро" to 15, "Бочка" to 35, "Мешок" to 15, "Деревянные башмаки" to 20,
            "Рукавицы" to 10, "Коромысло" to 20, "Стремянка" to 35
        )
        fun rankTimeFactor(rank:Int) = 1.2.pow(rank.coerceIn(0,8))
        val coreRankNames=listOf("F","E","D","C","B","A","S","SS","SSS")
        fun coreAttribute(name:String):String {
            val hasKnownRank=coreRankNames.any { name.endsWith(" $it",true) }
            if(!hasKnownRank) return ""
            return when {
                name.startsWith("Ядро силы ",true) -> "strength"
                name.startsWith("Ядро ловкости ",true) -> "agility"
                name.startsWith("Ядро интеллекта ",true) -> "intelligence"
                name.startsWith("Ядро выносливости ",true) -> "endurance"
                name.startsWith("Ядро удачи ",true) -> "luck"
                else -> ""
            }
        }
        fun isNewCore(name:String) = coreAttribute(name).isNotBlank()
        fun coreValue(name:String):Double = (coreRankNames.indexOfFirst { name.endsWith(" $it",true) } + 1).coerceAtLeast(0).toDouble()
        val cores=loaded.filterNotNull().filter { isNewCore(it.itemName) }
        val invalidExtras=loaded.filterNotNull().filter { item ->
            !isNewCore(item.itemName) && !bp?.needs.orEmpty().any { need ->
                need.unit==item.unit && need.aliases.any { alias -> item.itemName.contains(alias,true) }
            }
        }
        val isIntermediateBlueprint = bp?.outputName?.contains("рукоять", ignoreCase = true) == true
        val enhancementValid = if(isSmelting) singleOreOnly else invalidExtras.isEmpty() && !(isIntermediateBlueprint && cores.isNotEmpty())
        val baseMaterials=loaded.filterNotNull().filter { item -> bp?.needs.orEmpty().any { need -> need.unit==item.unit && need.aliases.any { a -> item.itemName.contains(a,true) } } }
        val resultRank=if(isSmelting) oreInfoSelected?.let { materialRankNames.indexOf(it.rank).coerceAtLeast(0) } ?: 0 else baseMaterials.minOfOrNull { rankOf(it.itemName) } ?: 0
        val activeWorkBonusPercent = (equipment.values.distinctBy { it.id to it.name }.count { item ->
            workCraftBonusPercent(item.name) > 0.0 && rankOf(item.name) == resultRank
        } * 5.0).coerceAtMost(15.0)
        val craftingSkillName = if(workshopMode) "Ремесленное дело" else "Кузнечное дело"
        val craftingSkillLevel = (skillLevels[craftingSkillName] ?: 1).coerceAtLeast(1)
        // Each level after the first reduces time by 5%; cap at 95% so crafting never takes zero minutes.
        val skillTimeReductionPercent = ((craftingSkillLevel - 1) * 5).coerceAtMost(95)
        val craftQuantity = if(isSmelting) (oreLoad?.amount ?: 0.0) else if(bp?.name=="Вычинка") loaded.filterNotNull().sumOf { if(it.itemName.contains("Шкура",true)) it.amount else 0.0 } else 1.0
        val baseCraftDuration = if(bp!=null && (isSmelting || bp.name=="Вычинка")) 30.0 * craftQuantity else (bp?.let { baseCraftMinutes[it.name] } ?: 0).toDouble()
        val rankAdjustedBaseMinutes = if(baseCraftDuration>0.0) baseCraftDuration * rankTimeFactor(resultRank) else 0.0
        val totalTimeReductionPercent = (activeWorkBonusPercent + skillTimeReductionPercent).coerceAtMost(95.0)
        val craftMinutes = if(bp==null || !enoughMaterials || rankAdjustedBaseMinutes<=0.0) 0 else {
            kotlin.math.ceil(rankAdjustedBaseMinutes * (1.0 - totalTimeReductionPercent / 100.0)).toInt().coerceAtLeast(1)
        }
        // Experience is based on rank-adjusted base work, before equipment and skill speed bonuses.
        val craftSkillXp = if(bp!=null && enoughMaterials && rankAdjustedBaseMinutes>0.0) kotlin.math.ceil(rankAdjustedBaseMinutes / 10.0).toInt().coerceAtLeast(1) else 0
        val effectiveBlueprint = if(enoughMaterials) bp else null
        val requiredTemperature = if(isSmelting) (oreInfoSelected?.requiredTemp ?: Int.MAX_VALUE) else (effectiveBlueprint?.minTemp ?: 0)
        val allowedMaxTemperature = minOf(furnaceMaxTemp, effectiveBlueprint?.maxTemp ?: furnaceMaxTemp)
        val temperatureOk = workshopMode || (effectiveBlueprint!=null && temperatureSelected && temperature.toInt() in requiredTemperature..allowedMaxTemperature)
        val fuelCost = if(!workshopMode && effectiveBlueprint!=null && fuelName.isNotBlank() && coalNames.indexOf(fuelName)>=0) energyRequired(effectiveBlueprint) / coalEnergy[coalNames.indexOf(fuelName)] else 0.0
        val enoughFuel = workshopMode || (fuelName.isNotBlank() && fuelAvailable(fuelName)+0.0001>=fuelCost)
        val capacityOk = workshopMode || loadedKg() <= furnaceCapacity + 0.0001
        // 1 ОВ за каждые начатые 5 минут фактической работы.
        val requiredOv = if(craftMinutes>0) kotlin.math.ceil(craftMinutes / 5.0).toInt() else 0
        val enoughOv = currentOv >= requiredOv
        val canCreate = effectiveBlueprint!=null && temperatureOk && enoughFuel && enhancementValid && capacityOk && singleOreOnly && enoughOv
        fun craftNow() {
            if(!enoughOv) return
            onConsumeOv(requiredOv)
            val target=effectiveBlueprint!!
            val actualFuel=if(workshopMode)0.0 else energyRequired(target)/coalEnergy[coalNames.indexOf(fuelName)]
            val smeltedOre = if(target.name=="Слитки") loaded.filterNotNull().first() else null
            val smeltInfo = smeltedOre?.let { oreInfo(it.itemName) }
            val outputName = smeltInfo?.outputName ?: target.outputName
            val finalName=if(smeltInfo!=null) outputName else if(target.rankedOutput) target.outputName+" "+materialRankNames[resultRank] else target.outputName
            val usedCores=if(enhancementValid) cores else emptyList()
            val tannedHideAmount=if(target.name=="Вычинка") loaded.filterNotNull().filter { it.itemName.contains("Шкура",true) && it.unit=="кг" }.sumOf { it.amount } else 0.0
            val loadedSnapshot=loaded.filterNotNull().toList()
            val rankMultiplier=2.0.pow(resultRank)
            val componentEntries=target.needs.mapNotNull { need ->
                val componentBlueprint=blueprints.firstOrNull { component -> need.aliases.any { alias -> component.outputName.equals(alias,true) } }
                componentBlueprint?.let { need to it }
            }
            val componentMinutes=componentEntries.filterNot { (need,component) ->
                loadedSnapshot.any { loadedItem -> loadedItem.unit==need.unit && need.aliases.any { alias -> loadedItem.itemName.contains(alias,true) } }
            }.sumOf { (need,component) ->
                (baseCraftMinutes[component.name] ?: 0).toDouble() * need.amount * rankTimeFactor(resultRank)
            }
            val mainWorkCost=craftMinutes / 10.0 * rankMultiplier
            val componentWorkCost=componentMinutes / 10.0 * rankMultiplier
            fun materialUnitPrice(loadedItem:ForgeLoad):Double {
                val storedPrice=loadedItem.template?.price ?: (inventory+storage).firstOrNull { source -> source.id==loadedItem.itemId }?.price ?: 0
                if(storedPrice>0) return storedPrice.toDouble()
                val itemName=loadedItem.itemName
                val rank=rankOf(itemName)
                val rankFactor=2.0.pow(rank)
                return when {
                    isNewCore(itemName) -> 10.0*rankFactor
                    itemName.contains("кож",true) -> 8.0*rankFactor
                    itemName.contains("древ",true) || itemName.contains("дерев",true) || itemName.contains("дуб",true) || itemName.contains("брус",true) -> 4.0*rankFactor
                    itemName.contains("руда",true) -> 10.0*rankFactor
                    itemName.contains("желез",true) || itemName.contains("металл",true) || itemName.contains("сталь",true) || itemName.contains("титан",true) || itemName.contains("сереб",true) || itemName.contains("золот",true) || itemName.contains("адамант",true) || itemName.contains("мифрил",true) || itemName.contains("орихалк",true) || itemName.contains("платин",true) -> 25.0*rankFactor
                    else -> 0.0
                }
            }
            val materialCost=loadedSnapshot.sumOf { loadedItem ->
                loadedItem.amount * materialUnitPrice(loadedItem)
            }
            // Дополнительные материалы и топливо не входят в минимальную стоимость.
            // Ядра входят в материальную себестоимость; работа над изготовленной сейчас деталью учитывается.
            val baseCost = materialCost + mainWorkCost + componentWorkCost
            clearLoadedMaterials()
            if(!workshopMode) consumeFuel(fuelName,actualFuel)
            val resultAmount=round2(when {
                smeltedOre!=null -> smeltedOre.amount * 0.8
                target.name=="Вычинка" -> tannedHideAmount * 0.9
                else -> target.outputAmount
            })
            val weight=when(target.outputName){"Кожаный шлем"->0.5;"Кожаный нагрудник"->1.2;"Кожаный плащ"->0.7;"Кожаные перчатки"->0.35;"Кожаные штаны"->0.8;"Кожаные сапоги"->0.6;"Полумаска кузнеца"->0.25;"Фартук кузнеца"->1.0;"Ведро"->0.9;"Бочка"->2.9;"Мешок"->0.7;"Деревянные башмаки"->1.2;"Рукавицы"->0.3;"Коромысло"->1.4;"Стремянка"->2.8;"Кольчужный шлем"->0.65;"Кольчужная рубаха"->2.6;"Кольчужные наручи"->1.3;"Кольчужные поножи"->1.6;"Латный шлем"->2.0;"Латная кираса"->6.5;"Латные рукавицы"->0.8;"Латные поножи"->1.5;"Латные сапоги"->1.0;"Деревянный щит"->2.0;"Боевой молот"->2.5;"Двуручный меч"->2.0;"Длинный меч"->1.2;"Копьё"->1.6;"Кинжал"->0.5;"Топор"->0.95;"Секира"->1.4;"Кузнечный молот"->1.0;"Лук"->0.8;"Дубинка"->0.65;"Боевой посох"->1.4;"Рогатка"->0.15;"Бумеранг"->0.35;"Скалка"->0.45;"Метла"->1.0;"Сковорода"->1.05;"Вилы"->2.8;"Короткая прямая рукоять"->0.20;"Профилированная рукоять"->0.75;"Удлинённая профилированная рукоять"->1.40;"Длинная прямая рукоять"->2.00;"Симметричная рукоять"->0.50;"Удлинённая симметричная рукоять"->0.80;"Короткая массивная рукоять"->0.60;"Длинная массивная рукоять"->1.30;"Изогнутая рукоять"->1.00;"Металлический щит"->4.0;"Тяжёлый металлический щит"->7.0;else->1.0}
            val resultDescription = when {
                smeltedOre!=null -> "Слитки $finalName. Выплавлено из ${smeltedOre.itemName}; выход составляет 80% массы руды."
                target.name=="Вычинка" -> "Выделанная кожа ${materialRankNames[resultRank]}. Получена вычинкой шкуры; выход составляет 90% исходной массы."
                else -> target.description.ifBlank{target.name}
            }
            var result=if(target.outputUnit=="шт.") itemWithEquipmentStats((inventory+storage).maxOfOrNull{it.id}?.plus(1)?:2000,target.outputName,resultDescription,weight,0).copy(name=finalName,price=0,minPrice=0) else Item((inventory+storage).maxOfOrNull{it.id}?.plus(1)?:2000,finalName,resultDescription,resultAmount,target.outputUnit,1.0,0,minPrice=0)
            if(result.damageType.isNotBlank() && resultRank>0) {
                val (rankedMin,rankedMax)=rankedDamage(result.minDamage,result.maxDamage,resultRank)
                result=result.copy(minDamage=rankedMin,maxDamage=rankedMax)
            }
            if(result.maxDurability>0.0 && resultRank>0) {
                val rankedDurability = kotlin.math.ceil(result.maxDurability * 1.5.pow(resultRank))
                result = result.copy(durability=rankedDurability,maxDurability=rankedDurability)
            }
            if(result.defenseValue>0.0 && resultRank>0) {
                result=result.copy(defenseValue=rankedDefense(result.defenseValue,resultRank))
            }
            val coreBonuses=usedCores.groupBy { coreAttribute(it.itemName) }.mapValues { (_,items) -> items.sumOf { it.amount * coreValue(it.itemName) } }
            result=result.copy(
                strengthBonus=coreBonuses["strength"] ?: 0.0,
                agilityBonus=coreBonuses["agility"] ?: 0.0,
                intelligenceBonus=coreBonuses["intelligence"] ?: 0.0,
                enduranceBonus=coreBonuses["endurance"] ?: 0.0,
                luckBonus=coreBonuses["luck"] ?: 0.0,
                description=result.description + if(usedCores.isNotEmpty()) " Бонусы ядер: " + usedCores.joinToString(", ") { "${it.itemName} +${coreValue(it.itemName).toInt()}" } + "." else ""
            )
            // Эталон строится для того же типа предмета и того же ранга, но без его усилений.
            val referenceItem = itemWithEquipmentStats(-1,target.outputName,"Эталон",weight,0).let { base ->
                var ranked = base
                if(ranked.damageType.isNotBlank() && resultRank>0) {
                    val (lo,hi)=rankedDamage(ranked.minDamage,ranked.maxDamage,resultRank)
                    ranked=ranked.copy(minDamage=lo,maxDamage=hi)
                }
                if(ranked.defenseValue>0.0 && resultRank>0) ranked=ranked.copy(defenseValue=rankedDefense(ranked.defenseValue,resultRank))
                ranked
            }
            val characteristicCoefficient = when {
                result.damageType.isNotBlank() && referenceItem.damageType.isNotBlank() -> {
                    val actualAverage=(result.minDamage+result.maxDamage)/2.0
                    val referenceAverage=(referenceItem.minDamage+referenceItem.maxDamage)/2.0
                    val damageRatio=if(referenceAverage>0.0) actualAverage/referenceAverage else 1.0
                    val speedRatio=(100.0+result.speedBonus)/(100.0+referenceItem.speedBonus).coerceAtLeast(0.0001)
                    0.7*damageRatio+0.3*speedRatio
                }
                result.defenseValue>0.0 && referenceItem.defenseValue>0.0 -> {
                    val defenseRatio=result.defenseValue/referenceItem.defenseValue
                    val speedRatio=(100.0+result.speedBonus)/(100.0+referenceItem.speedBonus).coerceAtLeast(0.0001)
                    0.7*defenseRatio+0.3*speedRatio
                }
                else -> 1.0
            }.coerceAtLeast(0.0)
            val durabilityCoefficient=if(result.maxDurability>0.0) {
                0.5+0.5*(result.durability/result.maxDurability).coerceIn(0.0,1.0)
            } else 1.0
            val totalMinimumCost=kotlin.math.ceil(baseCost*1.1*characteristicCoefficient*durabilityCoefficient).toInt().coerceAtLeast(0)
            val minimumItemPrice=if(target.outputUnit=="кг" && resultAmount>0.0) kotlin.math.ceil(totalMinimumCost/resultAmount).toInt() else totalMinimumCost
            result=result.copy(price=minimumItemPrice,minPrice=minimumItemPrice)
            addByCarry(result)
            if(craftMinutes>0) onAdvanceTime(craftMinutes)
            if(craftSkillXp>0) onGainSkillXp(craftingSkillName, craftSkillXp)
            craftMessage="Создано: ${result.name} — ${"%.2f".format(result.amount)} ${result.unit}. Время работы: $craftMinutes мин. Минимальная стоимость изготовления: $minimumItemPrice G." + if(usedCores.isNotEmpty()) " Бонусы характеристик: " + listOf("Сила" to result.strengthBonus,"Ловкость" to result.agilityBonus,"Интеллект" to result.intelligenceBonus,"Выносливость" to result.enduranceBonus,"Удача" to result.luckBonus).filter{it.second>0}.joinToString(", "){"${it.first} +${it.second.toInt()}"} + "." else ""
            if(!workshopMode) craftMessage += " Потрачено топлива: $fuelName ${"%.2f".format(actualFuel)} кг."
            // Сохраняем выбранный чертёж после создания следующего изделия.
        }
        fun compatibleWithBlueprint(load: ForgeLoad, recipe: ForgeBlueprint): Boolean {
            if (recipe.name == "Слитки") return load.unit == "кг" && isOreName(load.itemName) && oreInfo(load.itemName) != null
            val required = recipe.needs.any { need -> need.unit == load.unit && need.aliases.any { alias -> load.itemName.contains(alias, true) } }
            val isIntermediate = recipe.outputName.contains("рукоять", ignoreCase = true)
            return required || (isNewCore(load.itemName) && !isIntermediate)
        }
        fun selectBlueprint(recipe: ForgeBlueprint) {
            val kept = loaded.map { load ->
                if (load != null && !compatibleWithBlueprint(load, recipe)) {
                    val template = (load.template ?: Item(load.itemId, load.itemName, "Материал из печи", load.amount, load.unit, 1.0)).copy(amount=load.amount)
                    addByCarry(template, load.amount)
                    null
                } else load
            }
            loaded = kept
            selectedBlueprint = recipe
            temperature = 0f
            temperatureSelected = false
            activeSlot = -1
            drawerItem = null
            fuelName = cheapestAvailableCoal.ifBlank { fuelName }
        }
        Box(Modifier.fillMaxSize().background(bg)) {
        Column(Modifier.fillMaxSize().padding(14.dp).padding(bottom=132.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text(if(workshopMode)"Мастерская" else "Работающая печь",color=goldColor,fontSize=22.sp,fontWeight=FontWeight.Bold)
            var recipeMenu by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick={recipeMenu=true},modifier=Modifier.fillMaxWidth()) { Text(bp?.name ?: "Выберите предмет",color=cream) }
                DropdownMenu(expanded=recipeMenu,onDismissRequest={recipeMenu=false}) {
                    availableBlueprints.forEach { recipe -> DropdownMenuItem(text={Text(recipe.name,color=cream)},onClick={selectBlueprint(recipe);recipeMenu=false}) }
                }
            }
            Text("Добавьте материалы для создания",color=goldColor,fontWeight=FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                repeat(5) { idx ->
                    val l=loaded.getOrNull(idx)
                    val iconItem=l?.let { (it.template ?: Item(it.itemId,it.itemName,"Материал из печи",it.amount,it.unit,1.0)).copy(amount=it.amount) }
                    val oreSlotBlocked = isSmelting && idx != 0
                    Column(Modifier.weight(1f).height(74.dp).onGloballyPositioned { coords ->
                        slotBounds = slotBounds.toMutableList().also { it[idx] = Rect(coords.positionInRoot(), coords.positionInRoot() + Offset(coords.size.width.toFloat(), coords.size.height.toFloat())) }
                    }.border(1.dp,if(activeSlot==idx || (dragPayload!=null && slotBounds.getOrNull(idx)?.contains(dragPosition)==true))goldColor else muted,RoundedCornerShape(7.dp)).background(if(oreSlotBlocked) panel.copy(alpha=.35f) else panel,RoundedCornerShape(7.dp)).clickable(enabled=!oreSlotBlocked){
                        activeSlot=idx
                        if(l!=null) { drawerItem=(l.template ?: Item(l.itemId,l.itemName,"Загружено в печь",l.amount,l.unit,1.0)).copy(amount=l.amount);drawerSource="Печь";transferAmount=l.amount.toString() }
                        else drawerTab="Инвентарь"
                    },horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                        ItemIcon(iconItem,Modifier.size(25.dp))
                        Text(l?.itemName ?: "Пусто",color=cream,fontSize=7.sp,maxLines=2,textAlign=TextAlign.Center)
                        if(l!=null) Text("${"%.2f".format(l.amount)} ${l.unit}",color=goldColor,fontSize=7.sp)
                    }
                }
            }
            Text("Загрузка печи: ${format2(loadedKg())} / ${format2(furnaceCapacity)} кг",color=if(capacityOk)goldColor else red,fontSize=14.sp,fontWeight=FontWeight.Bold)
            if(activeSlot>=0) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    listOf("Инвентарь","Сундук").forEach { t -> TextButton(onClick={drawerTab=t}) { Text(t,color=if(drawerTab==t)goldColor else muted) } }
                    TextButton(onClick={activeSlot=-1}) { Text("Свернуть",color=muted) }
                }
                val source=if(drawerTab=="Инвентарь") inventory else storage
                if(source.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(72.dp).background(panel,RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center) {
                        Text("Пусто",color=muted,fontSize=11.sp)
                    }
                } else LazyVerticalGrid(
                    columns=GridCells.Fixed(5),
                    modifier=Modifier.fillMaxWidth().heightIn(max=240.dp).background(panel,RoundedCornerShape(8.dp)).padding(5.dp),
                    verticalArrangement=Arrangement.spacedBy(5.dp),
                    horizontalArrangement=Arrangement.spacedBy(5.dp)
                ) {
                    items(source.size, key={ index -> "${source[index].id}_${source[index].name}_${drawerTab}" }) { index ->
                        val item=source[index]
                        val allowed = bp != null && compatibleWithBlueprint(ForgeLoad(item.id,item.name,drawerTab,item.unit,item.amount,template=item),bp) && (activeSlot<0 || loaded.getOrNull(activeSlot)==null || loaded.getOrNull(activeSlot)?.itemName==item.name) && (!isSmelting || (isOreName(item.name) && oreInfo(item.name)!=null && (loaded[0]==null || loaded[0]?.itemName==item.name) && (activeSlot==0 || activeSlot==-1)))
                        var rowOrigin by remember(item.id, item.name, drawerTab) { mutableStateOf(Offset.Zero) }
                        Column(Modifier.fillMaxWidth().height(82.dp).onGloballyPositioned { rowOrigin=it.positionInRoot() }
                            .then(if(allowed) Modifier.pointerInput(item.id,item.name,drawerTab) {
                                detectDragGesturesAfterLongPress(onDragStart={start->dragPayload=item to drawerTab;dragPosition=rowOrigin+start},onDrag={change,delta->change.consume();dragPosition+=delta},onDragEnd={
                                    val density=this.density
                                    val target=slotBounds.mapIndexedNotNull{slotIndex,rect->rect?.let{slotIndex to kotlin.math.hypot((it.center.x-dragPosition.x).toDouble(),(it.center.y-dragPosition.y).toDouble())}}.minByOrNull{it.second}?.takeIf{it.second<=110.0*density}?.first
                                    if(target!=null && !(isSmelting && target!=0)){activeSlot=target;drawerItem=item;drawerSource=drawerTab;transferAmount="0"}
                                    dragPayload=null
                                },onDragCancel={dragPayload=null})
                            } else Modifier)
                            .clickable(enabled=allowed){drawerItem=item;drawerSource=drawerTab;transferAmount="0"},
                            horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center
                        ) {
                            ItemIcon(item,Modifier.size(29.dp).then(if(allowed)Modifier else Modifier.alpha(.35f)))
                            Text(item.name,color=if(allowed)cream else muted,fontSize=8.sp,maxLines=2,textAlign=TextAlign.Center,lineHeight=9.sp)
                            Text("${format2(item.amount)} ${item.unit}",color=if(allowed)goldColor else muted,fontSize=8.sp)
                        }
                    }
                }
            }
            if(!workshopMode) {
                Text(
                    if(isSmelting && oreInfoSelected!=null) "Температура: ${temperature.toInt()} °C · требуется ${oreInfoSelected.requiredTemp} °C"
                    else "Выберите температуру: ${temperature.toInt()} °C",
                    color=cream,fontWeight=FontWeight.SemiBold
                )
                Slider(
                    value=temperature.coerceIn(0f,furnaceMaxTemp.toFloat()),
                    onValueChange={temperature=it;temperatureSelected=true},
                    valueRange=0f..furnaceMaxTemp.toFloat(),
                    steps=(furnaceMaxTemp/50-1).coerceAtLeast(0)
                )
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text("0 °C",color=muted,fontSize=10.sp)
                    Text("Макс. ${furnaceMaxTemp} °C",color=muted,fontSize=10.sp)
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                    listOf(Triple(bp!=null,"Рецепт",0),Triple(isSmelting && singleOreOnly || (!isSmelting && enoughMaterials),"Материал",1),Triple(temperatureOk,"Температура",2),Triple(fuelName.isNotBlank() && enoughFuel,"Уголь",3)).forEach { step ->
                        Box(Modifier.weight(1f)) {
                            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                                Box(Modifier.size(11.dp).background(if(step.first)goldColor else muted.copy(alpha=.35f),CircleShape))
                                Text(step.second,color=if(step.first)goldColor else muted,fontSize=9.sp,maxLines=2)
                            }
                        }
                    }
                }
                if(isSmelting && !singleOreOnly) Text("Можно загрузить только один тип руды в первую ячейку.",color=red,fontSize=10.sp)
                if(!enoughFuel && fuelName.isNotBlank()) Text("Недостаточно выбранного топлива.",color=red,fontSize=10.sp)
            }
        }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal=14.dp, vertical=8.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Box(Modifier.align(Alignment.CenterHorizontally).size(9.dp).background(
                if(bp==null || !enoughMaterials) muted.copy(alpha=.45f) else if(enoughOv) Color(0xFF55B86A) else red,
                CircleShape
            ))
            if(bp!=null && enoughMaterials && activeWorkBonusPercent>0.0) Text("Бонус рабочей экипировки этого ранга: −${format2(activeWorkBonusPercent)}% времени",color=goldColor,fontSize=11.sp)
            Button(onClick={craftNow()},enabled=canCreate,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=if(canCreate)goldColor else muted,contentColor=Color.Black)){Text(if(craftMinutes>0) "Создать · $craftMinutes мин" else "Создать")}
            Button(onClick={returnLoadedMaterials();furnaceOn=false;activeSlot=-1;drawerItem=null;selectedBlueprint=null},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=red)){Text(if(workshopMode)"Закрыть" else "Потушить")}
        }
        if(dragPayload!=null) {
            Box(Modifier.offset { IntOffset(dragPosition.x.toInt(), dragPosition.y.toInt()) }.background(goldColor.copy(alpha=.92f),RoundedCornerShape(8.dp)).padding(horizontal=10.dp,vertical=7.dp)) {
                Text(dragPayload!!.first.name,color=Color.Black,fontSize=11.sp,fontWeight=FontWeight.Bold)
            }
        }
        }
        if(drawerItem!=null) {
            val item=drawerItem!!
            val returning = drawerSource=="Печь"
            val maxTransfer = if(returning) item.amount else if(item.unit=="шт.") minOf(item.amount, (freeFurnaceKg() / item.weightEach.coerceAtLeast(0.0001)).toInt().toDouble()) else minOf(item.amount, freeFurnaceKg() / item.weightEach.coerceAtLeast(0.0001))
            val parsed = round2(transferAmount.replace(',','.').toDoubleOrNull()?.coerceIn(0.0,maxTransfer) ?: 0.0)
            val selectedAmount = if(item.unit=="шт.") parsed.toInt().toDouble() else minOf(maxTransfer, round2(parsed))
            AlertDialog(onDismissRequest={drawerItem=null},containerColor=panel,title={Text(item.name,color=goldColor)},text={
                Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("Доступно: ${format2(item.amount)} ${item.unit} · ${if(returning)"Печь" else drawerSource}",color=cream)
                    if(maxTransfer>0.0) {
                        Text("Максимум: ${if(item.unit=="шт.")maxTransfer.toInt().toString() else format2(maxTransfer)} ${item.unit}",color=muted,fontSize=11.sp)
                        Slider(modifier=Modifier.padding(end=14.dp),value=selectedAmount.toFloat().coerceIn(0f,maxTransfer.toFloat()),onValueChange={v->transferAmount=(if(item.unit=="шт.")v.toInt().toString() else format2(v.toDouble())).replace(',','.')},valueRange=0f..maxTransfer.toFloat(),steps=if(item.unit=="шт.") (maxTransfer.toInt()-1).coerceAtLeast(0) else ((maxTransfer*100).toInt()-1).coerceAtLeast(0))
                        val wholeMarks = maxTransfer.toInt().coerceAtMost(10)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                            (0..wholeMarks).forEach { mark -> Text(mark.toString(),color=muted,fontSize=9.sp) }
                            if(wholeMarks==0) Text("${format2(maxTransfer)}",color=muted,fontSize=9.sp)
                        }
                    }
                    OutlinedTextField(value=transferAmount,onValueChange={raw->transferAmount=if(item.unit=="кг") limitTwoDecimals(raw) else raw.filter{it.isDigit()}},label={Text("Количество")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
                    Text("Выбрано: ${if(item.unit=="шт.")selectedAmount.toInt().toString() else format2(selectedAmount)} ${item.unit}",color=goldColor,fontWeight=FontWeight.SemiBold)
                    Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                        listOf("1","5","Всё").forEach { q -> TextButton(onClick={transferAmount=if(q=="Всё")maxTransfer.toString() else minOf(q.toDouble(),maxTransfer).toString()}){Text(q,color=goldColor)} }
                    }
                    if(!returning && item.unit=="кг") Text("Свободно в печи: ${format2(freeFurnaceKg())} кг",color=muted,fontSize=10.sp)
                }
            },confirmButton={TextButton(enabled=selectedAmount>0.0 && selectedAmount<=maxTransfer+0.0001,onClick={
                val amount=round2(selectedAmount)
                if(amount>0) {
                    if(returning) {
                        val old=loaded.getOrNull(activeSlot)
                        if(old!=null) {
                            var leftToReturn=amount
                            val origins=old.sourceAmounts.toMutableMap()
                            origins.toMap().forEach { (sourceName, availableAmount) ->
                                if(leftToReturn>0.000001) {
                                    val returned=minOf(leftToReturn,availableAmount)
                                    if(returned>0.0) {
                                        addByCarry((old.template ?: Item(old.itemId,old.itemName,"Материал из печи",returned,old.unit,1.0)).copy(amount=returned),returned)
                                        val remaining=round2(availableAmount-returned)
                                        if(remaining<=0.000001) origins.remove(sourceName) else origins[sourceName]=remaining
                                        leftToReturn=round2(leftToReturn-returned)
                                    }
                                }
                            }
                            loaded=loaded.toMutableList().also{if(old.amount<=amount+0.0001)it[activeSlot]=null else {val primary=if(origins.size==1)origins.keys.first() else "Смешанный";it[activeSlot]=old.copy(source=primary,amount=round2(old.amount-amount),sourceAmounts=origins)}}
                        }
                    } else {
                        val isOreTransfer = isSmelting
                        val targetSlot = if(isOreTransfer) 0 else activeSlot
                        val source=if(drawerSource=="Инвентарь")inventory else storage
                        val current=source.firstOrNull{it.id==item.id && it.name==item.name}
                        val old=loaded.getOrNull(targetSlot)
                        val recipeAllowed = bp != null && compatibleWithBlueprint(ForgeLoad(item.id,item.name,drawerSource,item.unit,amount,template=item),bp)
                        val slotAllowed = targetSlot in 0..4 && (old==null || old.itemName==item.name)
                        val oreAllowed = !isOreTransfer || (targetSlot==0 && isOreName(item.name) && oreInfo(item.name)!=null && (old==null || old.itemName==item.name) && loaded.filterNotNull().all{it.itemName==item.name})
                        val capacityAllowed = amount * item.weightEach <= freeFurnaceKg() + 0.0001
                        val sourceAllowed = current!=null && current.amount+0.0001>=amount
                        if(sourceAllowed && recipeAllowed && slotAllowed && oreAllowed && capacityAllowed) {
                            // All checks pass: only now remove the material from its source.
                            if(current!!.amount<=amount+0.0001) source.remove(current) else {val ix=source.indexOf(current);source[ix]=current.copy(amount=round2(current.amount-amount))}
                            if(source === inventory) carryBudget += amount * item.weightEach
                            onInventoryChanged()
                            if(old!=null) {
                                val origins=old.sourceAmounts.toMutableMap()
                                origins[drawerSource]=round2((origins[drawerSource]?:0.0)+amount)
                                val primarySource=if(origins.size==1) origins.keys.first() else "Смешанный"
                                loaded=loaded.toMutableList().also{it[targetSlot]=old.copy(source=primarySource,amount=round2(old.amount+amount),sourceAmounts=origins)}
                            } else loaded=loaded.toMutableList().also{it[targetSlot]=ForgeLoad(item.id,item.name,drawerSource,item.unit,amount,template=item)}
                        } else craftMessage=when {
                            !recipeAllowed -> if(isOreTransfer) "Для слитков разрешена только подходящая руда." else "Этот предмет не подходит для выбранного чертежа."
                            !slotAllowed -> "Ячейка уже занята другим материалом."
                            !oreAllowed -> "Для плавки разрешён только один тип руды в первой ячейке."
                            !capacityAllowed -> "Превышена вместимость печи."
                            !sourceAllowed -> "Недостаточно материала в источнике."
                            else -> "Не удалось переместить предмет."
                        }
                    }
                }
                drawerItem=null
            }){Text(if(returning)"Вернуть" else "Переложить",color=goldColor)}},dismissButton={TextButton(onClick={drawerItem=null}){Text("Закрыть",color=cream)}})
        }
    }
    if(craftMessage.isNotBlank()) AlertDialog(onDismissRequest={craftMessage=""},title={Text("Печь",color=goldColor)},text={Text(craftMessage,color=cream)},confirmButton={TextButton(onClick={craftMessage=""}){Text("ОК",color=goldColor)}})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(multiplier:String,onMultiplier:(String)->Unit,onXp:()->Unit,onGold:()->Unit,onReset:()->Unit) {
    var expanded by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Настройки",color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        Text("Множитель опыта",color=goldColor)
        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}) {
            OutlinedTextField(value="×$multiplier",onValueChange={},readOnly=true,modifier=Modifier.menuAnchor().fillMaxWidth(),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=cream,unfocusedTextColor=cream))
            ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){listOf("0.5","1","2","5","10").forEach{v->DropdownMenuItem(text={Text("×$v")},onClick={onMultiplier(v);expanded=false})}}
        }
        Button(onClick=onXp,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Получить опыт (+${(80*multiplier.toDouble()).toInt()} XP)")}
        Button(onClick=onGold,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Получить золото (+55 G)")}
        Spacer(Modifier.height(18.dp))
        Button(onClick=onReset,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=red,contentColor=Color.White)){Text("Начать заново")}
    }
}
@Composable
private fun Placeholder(text:String) { Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(text,color=muted)} }
