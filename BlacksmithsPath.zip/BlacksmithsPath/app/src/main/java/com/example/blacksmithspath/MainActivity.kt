@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.blacksmithspath

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlin.math.ceil
import kotlin.math.floor

private val bg = Color(0xFF171411)
private val panel = Color(0xFF28221C)
private val goldColor = Color(0xFFC58A43)
private val cream = Color(0xFFF0E4D0)
private val muted = Color(0xFFB8A995)
private val red = Color(0xFFC84D45)

private data class Tool(val name: String, val image: String, val description: String, val requirements: List<String>)
private val blacksmithTools = listOf(
    Tool("Печь с подачей воздуха", "https://images.pexels.com/photos/12841912/pexels-photo-12841912.jpeg?auto=compress&cs=tinysrgb&w=900", "Печь для нагрева и плавки металла.", listOf("Навык: кузнечное дело 1 уровня", "Материалы: пока не требуются")),
    Tool("Наковальня", "https://images.pexels.com/photos/5846089/pexels-photo-5846089.jpeg?auto=compress&cs=tinysrgb&w=900", "Рабочее место для ковки заготовок.", listOf("Навык: кузнечное дело 1 уровня")),
    Tool("Кузнечный молот", "https://images.pexels.com/photos/19460423/pexels-photo-19460423.jpeg?auto=compress&cs=tinysrgb&w=900", "Инструмент для придания формы металлу.", listOf("Сила: 5")),
    Tool("Рабочий верстак", "https://images.pexels.com/photos/32979598/pexels-photo-32979598.jpeg?auto=compress&cs=tinysrgb&w=900", "Подготовка и сборка металлических деталей.", listOf("Навык: кузнечное дело 1 уровня")),
    Tool("Точильный камень", "https://images.pexels.com/photos/5845914/pexels-photo-5845914.jpeg?auto=compress&cs=tinysrgb&w=900", "Заточка и доводка кромки.", listOf("Ловкость: 5"))
)
private val leatherTools = listOf(
    Tool("Доска для подготовки кожи", "https://images.pexels.com/photos/6068960/pexels-photo-6068960.jpeg?auto=compress&cs=tinysrgb&w=900", "Подготовка и сушка шкур.", listOf("Комната закрыта")),
    Tool("Нож для раскроя", "https://images.pexels.com/photos/4226876/pexels-photo-4226876.jpeg?auto=compress&cs=tinysrgb&w=900", "Раскрой кожи и заготовок.", listOf("Комната закрыта")),
    Tool("Набор для шитья", "https://images.pexels.com/photos/4210860/pexels-photo-4210860.jpeg?auto=compress&cs=tinysrgb&w=900", "Сшивание кожаных деталей.", listOf("Комната закрыта")),
    Tool("Седельный зажим", "https://images.pexels.com/photos/6068965/pexels-photo-6068965.jpeg?auto=compress&cs=tinysrgb&w=900", "Фиксация деталей во время работы.", listOf("Комната закрыта")),
    Tool("Полировщик кожи", "https://images.pexels.com/photos/6068962/pexels-photo-6068962.jpeg?auto=compress&cs=tinysrgb&w=900", "Финишная обработка поверхности.", listOf("Комната закрыта"))
)
private val runeTools = listOf(
    Tool("Рукоять для гравировки", "https://images.pexels.com/photos/5974300/pexels-photo-5974300.jpeg?auto=compress&cs=tinysrgb&w=900", "Ручной инструмент для нанесения рун.", listOf("Комната закрыта")),
    Tool("Набор гравировальных резцов", "https://images.pexels.com/photos/5974301/pexels-photo-5974301.jpeg?auto=compress&cs=tinysrgb&w=900", "Резцы для рун разных форм.", listOf("Комната закрыта")),
    Tool("Гравировальные тиски", "https://images.pexels.com/photos/5974302/pexels-photo-5974302.jpeg?auto=compress&cs=tinysrgb&w=900", "Фиксация предмета при гравировке.", listOf("Комната закрыта")),
    Tool("Полировальные камни", "https://images.pexels.com/photos/5974303/pexels-photo-5974303.jpeg?auto=compress&cs=tinysrgb&w=900", "Полировка рунических линий.", listOf("Комната закрыта")),
    Tool("Глубиномер гравировки", "https://images.pexels.com/photos/5974304/pexels-photo-5974304.jpeg?auto=compress&cs=tinysrgb&w=900", "Контроль глубины нанесения рун.", listOf("Комната закрыта"))
)
private val rankNames = listOf("F", "E", "D", "C", "B", "A", "S", "SS", "SSS", "EX")
private data class Item(
    val id: Int, val name: String, val description: String, val amount: Double,
    val unit: String, val weightEach: Double, val price: Int = 0,
    val equipmentSlot: String? = null, val equipped: Boolean = false
)
private data class Merchant(val name: String, val job: String, val race: String, val stock: List<Item>)
private val merchants = listOf(
    Merchant("Борк", "Шахтёр", "Дварф", listOf(
        Item(101,"Железная руда F","Железная руда низкого F-ранга.",100.0,"кг",1.0,5),
        Item(102,"Уголь","Топливо для плавки.",100.0,"кг",1.0,3),
        Item(103,"Железо","Готовый металл.",100.0,"кг",1.0,10))),
    Merchant("Милош", "Фермер", "Человек", listOf(
        Item(104,"Грубая кожа F","Необработанная кожа.",100.0,"кг",1.0,6),
        Item(105,"Мягкая кожа F","Подготовленная мягкая кожа.",100.0,"кг",1.0,11),
        Item(106,"Кости F","Кости монстров.",100.0,"кг",1.0,2),
        Item(107,"Рога","Материал для изготовления.",100.0,"шт.",0.2,3))),
    Merchant("Финн", "Лесоруб", "Зверолюд", listOf(
        Item(108,"Древесина F","Древесина для производства.",100.0,"кг",1.0,4),
        Item(109,"Ветки F","Подходят для простых заготовок.",100.0,"шт.",0.1,2))),
    Merchant("Ларс", "Авантюрист", "Человек", listOf(
        Item(110,"Ядро монстра F","Сгусток энергии монстра.",100.0,"шт.",0.1,10),
        Item(111,"Шкура волка F","Шкура обычного волка.",100.0,"кг",1.0,12),
        Item(112,"Клыки волка F","Острые волчьи клыки.",100.0,"шт.",0.05,5)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setContent { BlacksmithApp() }
    }
}

@Composable
private fun BlacksmithApp() {
    var tab by remember { mutableIntStateOf(0) }
    var room by remember { mutableIntStateOf(0) }
    var location by remember { mutableStateOf("Дом") }
    var level by remember { mutableIntStateOf(1) }
    var xp by remember { mutableIntStateOf(0) }
    var freePoints by remember { mutableIntStateOf(0) }
    var goldBalance by remember { mutableIntStateOf(0) }
    var reputation by remember { mutableIntStateOf(0) }
    var multiplier by remember { mutableStateOf("1") }
    val stats = remember { mutableStateMapOf("Сила" to 5, "Ловкость" to 5, "Выносливость" to 5, "Интеллект" to 5, "Удача" to 5) }
    val skills = listOf("Кузнечное дело","Кожевенное дело","Руническая гравировка","Двуручное оружие","Одноручное оружие","Дальний бой","Блокирование")
    val skillXp = remember { mutableStateMapOf<String, Int>().apply { skills.forEach { put(it,0) } } }
    val skillLevels = remember { mutableStateMapOf<String, Int>().apply { skills.forEach { put(it,1) } } }
    val toolRanks = remember { mutableStateMapOf<String, Int>().apply { (blacksmithTools+leatherTools+runeTools).forEach { put(it.name,0) } } }
    val inventory = remember { mutableStateListOf<Item>().apply { add(Item(1,"Начальный молот кузнеца","При экипировке повышает силу на 1.",1.0,"шт.",2.0,equipmentSlot="Оружие 1")) } }
    val storage = remember { mutableStateListOf<Item>() }
    val equipment = remember { mutableStateMapOf<String, Item>() }
    var drawerItem by remember { mutableStateOf<Item?>(null) }
    var drawerStorage by remember { mutableStateOf(false) }
    var quantityText by remember { mutableStateOf("1") }
    var confirmDelete by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    var merchant by remember { mutableStateOf<Merchant?>(null) }
    var buyItem by remember { mutableStateOf<Item?>(null) }
    var buyQty by remember { mutableStateOf("1") }
    var expandedStat by remember { mutableStateOf("") }
    var subTab by remember { mutableIntStateOf(0) }
    var productionMessage by remember { mutableStateOf("Выбери доступную мастерскую и инструмент.") }

    val strength = (stats["Сила"] ?: 5) + if (equipment.containsKey("Оружие 1") || equipment.containsKey("Оружие 2")) 1 else 0
    val endurance = stats["Выносливость"] ?: 5
    val intelligence = stats["Интеллект"] ?: 5
    val hpMax = 100 + 20 * endurance + 5 * level
    val mpMax = 50 + 15 * intelligence + 3 * level
    val ovMax = 50 + 10 * endurance + 2 * level
    val carryMax = 30.0 + strength * 4.0
    val carryNow = inventory.sumOf { it.amount * it.weightEach }
    val reputationRank = listOf(250,500,1000,2000,4000,8000).indexOfFirst { reputation < it }.let { if (it < 0) 6 else it }
    val reputationName = listOf("F","E","D","C","B","A","S")[reputationRank]
    val reputationBase = listOf(0,250,500,1000,2000,4000,8000)[reputationRank]
    val reputationNext = listOf(250,500,1000,2000,4000,8000,16000)[reputationRank]
    val reputationInRank = reputation - reputationBase

    fun addXp(amount: Int) {
        xp += amount
        while (xp >= level * 100) { xp -= level * 100; level += 1; freePoints += 2 }
    }
    fun moveItem(item: Item, fromStorage: Boolean, count: Double, destinationStorage: Boolean) {
        val source = if (fromStorage) storage else inventory
        val destination = if (destinationStorage) storage else inventory
        val found = source.firstOrNull { it.id == item.id } ?: return
        if (fromStorage && !destinationStorage && carryNow + count * item.weightEach > carryMax) { toast = "Вы столько не унесёте."; return }
        if (!fromStorage && destinationStorage && location != "Дом") { toast = "Выложить можно только дома."; return }
        val safeCount = count.coerceIn(0.0, found.amount)
        source.remove(found)
        if (found.amount > safeCount + 0.0001) source.add(found.copy(amount = found.amount - safeCount))
        val existing = destination.firstOrNull { it.id == found.id }
        if (existing != null) { destination.remove(existing); destination.add(existing.copy(amount = existing.amount + safeCount)) }
        else destination.add(found.copy(amount = safeCount, equipped = false))
        drawerItem = null
    }

    MaterialTheme(colorScheme = darkColorScheme(background=bg, surface=panel, primary=goldColor, onPrimary=Color.Black, onBackground=cream, onSurface=cream)) {
        Box(Modifier.fillMaxSize().background(bg)) {
            Column(Modifier.fillMaxSize()) {
                if (tab == 0) {
                    StatusHeader(hpMax,mpMax,ovMax,reputationName,reputationInRank,reputationNext-reputationBase,goldBalance)
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        0 -> {
                            if (location == "Дом") {
                                Column(Modifier.fillMaxSize()) {
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=8.dp, vertical=7.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                                        listOf("Кузница","Обработка кожи","Руническая гравировка","Склад").forEachIndexed { i, title ->
                                            FilterChip(selected=room==i,onClick={room=i},label={Text(title,fontSize=11.sp)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=goldColor,selectedLabelColor=Color.Black,labelColor=cream))
                                        }
                                    }
                                    when(room) {
                                        0 -> WorkshopRoom("Кузница",blacksmithTools,toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(9)}}, onMessage={productionMessage=it}, message=productionMessage)
                                        1 -> WorkshopRoom("Обработка кожи",leatherTools,toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(9)}}, onMessage={productionMessage=it}, message=productionMessage, locked=true)
                                        2 -> WorkshopRoom("Руническая гравировка",runeTools,toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(9)}}, onMessage={productionMessage=it}, message=productionMessage, locked=true)
                                        else -> StorageScreen(storage) { item -> drawerItem=item; drawerStorage=true; quantityText="1" }
                                    }
                                }
                            } else if (location == "Рынок") {
                                if (merchant == null) MarketScreen(merchants) { merchant=it }
                                else MerchantScreen(merchant!!,goldBalance,{item->buyItem=item;buyQty="1"},{merchant=null})
                            } else LocationScreen(location)
                        }
                        1 -> Placeholder("Вкладка пока не назначена")
                        2 -> CharacterScreen(level, xp, freePoints, stats, skillLevels, skillXp, inventory, equipment, hpMax, mpMax, ovMax, subTab, {subTab=it}, {item->drawerItem=item;drawerStorage=false;quantityText="1"}, {slot,item->equipment[slot]=item; inventory.remove(item)}, {slot->equipment.remove(slot)?.let{inventory.add(it)}} ,expandedStat,{expandedStat=it}, {name-> if(freePoints>0){stats[name]=(stats[name]?:5)+1;freePoints--}else toast="Нет свободных очков характеристик."})
                        3 -> MapScreen(location) { location=it; merchant=null; tab=0 }
                        else -> SettingsScreen(multiplier,{multiplier=it},{addXp((80*multiplier.toDouble()).toInt())},{goldBalance+=55})
                    }
                }
                if(tab==0) CarryBar(carryNow,carryMax)
                NavigationBar(containerColor=Color(0xFF211C17),contentColor=cream) {
                    val labels=listOf("Ты здесь","","Персонаж","Карта","Настройки")
                    val icons=listOf(Icons.Default.Place,Icons.Default.Build,Icons.Default.Person,Icons.Default.Map,Icons.Default.Settings)
                    labels.forEachIndexed { i,label ->
                        NavigationBarItem(selected=tab==i,onClick={tab=i;drawerItem=null;merchant=null},icon={
                            if(i==2) Box(Modifier.size(45.dp).background(if(tab==i)goldColor else Color(0xFF493522),CircleShape),contentAlignment=Alignment.Center){Icon(icons[i],null,tint=if(tab==i)Color.Black else goldColor)}
                            else Icon(icons[i],null)
                        },label={if(label.isNotEmpty())Text(label,fontSize=9.sp,maxLines=1)},colors=NavigationBarItemDefaults.colors(selectedIconColor=goldColor,selectedTextColor=goldColor,indicatorColor=Color(0xFF493522),unselectedIconColor=Color.LightGray,unselectedTextColor=Color.LightGray))
                    }
                }
            }
            if(drawerItem!=null) {
                val item=drawerItem!!
                Row(Modifier.fillMaxSize().background(Color(0x99000000)),horizontalArrangement=Arrangement.End) {
                    Spacer(Modifier.weight(1f).fillMaxHeight().clickable{drawerItem=null})
                    Column(Modifier.fillMaxHeight().fillMaxWidth(.75f).background(panel).padding(15.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(54.dp).background(Color(0xFF44382B),RoundedCornerShape(9.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.Inventory2,null,tint=goldColor,modifier=Modifier.size(29.dp))}
                            Spacer(Modifier.width(9.dp)); Text(item.name,color=cream,fontWeight=FontWeight.Bold,fontSize=17.sp)
                        }
                        Text(item.description,color=muted,fontSize=12.sp)
                        Text("Количество",color=goldColor,fontWeight=FontWeight.Bold)
                        val available=item.amount
                        val selected=quantityText.replace(',','.').toDoubleOrNull()?.coerceIn(0.0,available)?:0.0
                        OutlinedTextField(value=quantityText,onValueChange={quantityText=it.filter{c->c.isDigit()||c=='.'||c==','}},modifier=Modifier.fillMaxWidth(),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=cream,unfocusedTextColor=cream))
                        Slider(value=selected.toFloat(),onValueChange={quantityText=if(item.unit=="кг")"%.2f".format(it).replace(',','.') else it.toInt().toString()},valueRange=0f..available.toFloat().coerceAtLeast(.01f))
                        if(item.unit!="кг") Text("Вес: 1 шт. — ${item.weightEach} кг\nВсего: ${"%.2f".format(selected*item.weightEach)} кг",color=muted,fontSize=12.sp)
                        if(item.equipmentSlot!=null) {
                            if(item.equipped) Button(onClick={equipment.remove(item.equipmentSlot);inventory.add(item.copy(equipped=false));drawerItem=null},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Снять")}
                            else Button(onClick={if(equipment[item.equipmentSlot]==null){equipment[item.equipmentSlot]=item.copy(equipped=true);inventory.remove(item);drawerItem=null}else toast="Слот уже занят."},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Надеть")}
                        }
                        Spacer(Modifier.weight(1f))
                        if(drawerStorage) Button(onClick={
                            val count=if(item.unit=="кг") floor(selected*100)/100 else ceil(selected).coerceAtLeast(1.0)
                            moveItem(item,true,count,false)
                        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Забрать")}
                        else Button(onClick={
                            val count=if(item.unit=="кг") floor(selected*100)/100 else ceil(selected).coerceAtLeast(1.0)
                            moveItem(item,false,count,true)
                        },enabled=location=="Дом"&&!item.equipped,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Выложить")}
                        OutlinedButton(onClick={confirmDelete=true},enabled=!item.equipped,modifier=Modifier.fillMaxWidth()){Text("Выбросить",color=cream)}
                        TextButton(onClick={drawerItem=null},modifier=Modifier.fillMaxWidth()){Text("Закрыть меню",color=goldColor)}
                    }
                }
                if(confirmDelete) AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Удаление предмета")},text={Text("Вы точно хотите удалить предмет?\n${item.name} — $quantityText")},confirmButton={TextButton(onClick={if(drawerStorage)storage.remove(item) else inventory.remove(item);drawerItem=null;confirmDelete=false}){Text("Удалить")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("Отмена")}},containerColor=panel,titleContentColor=cream,textContentColor=cream)
            }
            if(buyItem!=null && merchant!=null) {
                val product=buyItem!!
                AlertDialog(onDismissRequest={buyItem=null},title={Text(product.name)},text={
                    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("Цена: ${product.price} G / ${product.unit}")
                        OutlinedTextField(value=buyQty,onValueChange={buyQty=it.filter{c->c.isDigit()||c=='.'||c==','}},label={Text("Количество")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                        val qty=buyQty.replace(',','.').toDoubleOrNull()?:0.0
                        Text("Золото: ${"%.2f".format(qty*product.price)} G")
                        Text("Добавляемый вес: ${"%.2f".format(qty*product.weightEach)} кг")
                    }
                },confirmButton={TextButton(onClick={
                    val qty=buyQty.replace(',','.').toDoubleOrNull()?:0.0
                    val price=ceil(qty*product.price).toInt()
                    if(qty<=0) toast="Укажи количество."
                    else if(price>goldBalance)toast="Недостаточно золота."
                    else if(carryNow+qty*product.weightEach>carryMax)toast="Вы столько не унесёте."
                    else {goldBalance-=price;inventory.add(product.copy(id=(inventory.maxOfOrNull{it.id}?:200)+1,amount=qty));buyItem=null}
                }){Text("Купить")}},dismissButton={TextButton(onClick={buyItem=null}){Text("Отмена")}},containerColor=panel,titleContentColor=cream,textContentColor=cream)
            }
            if(toast.isNotEmpty()) AlertDialog(onDismissRequest={toast=""},text={Text(toast)},confirmButton={TextButton(onClick={toast=""}){Text("ОК")}},containerColor=panel,textContentColor=cream)
        }
    }
}

@Composable
private fun StatusHeader(hp:Int,mp:Int,ov:Int,rank:String,rep:Int,repMax:Int,goldBalance:Int) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF211C17)).padding(horizontal=13.dp,vertical=8.dp)) {
        Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("HP $hp/$hp",color=cream,fontSize=11.sp,modifier=Modifier.weight(1f));Text("MP $mp/$mp",color=cream,fontSize=11.sp,modifier=Modifier.weight(1f));Text("ОВ $ov/$ov",color=cream,fontSize=11.sp,modifier=Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Text("Репутация: $rank — $rep/$repMax",color=goldColor,fontSize=11.sp,modifier=Modifier.weight(1f))
            Text("Золото: $goldBalance G",color=goldColor,fontSize=12.sp,fontWeight=FontWeight.Bold)
        }
    }
}
@Composable
private fun CarryBar(weight:Double,max:Double) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF211C17)).padding(horizontal=12.dp,vertical=4.dp)) {
        LinearProgressIndicator(progress={(weight/max).toFloat().coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(3.dp),color=goldColor,trackColor=panel)
        Text("${"%.1f".format(weight)} / ${"%.0f".format(max)} кг",color=muted,fontSize=9.sp,modifier=Modifier.align(Alignment.End))
    }
}
@Composable
private fun WorkshopRoom(title:String,tools:List<Tool>,ranks:Map<String,Int>,onRank:(String)->Unit,onMessage:(String)->Unit,message:String,locked:Boolean=false) {
    Column(Modifier.fillMaxSize().padding(horizontal=14.dp)) {
        Text(title,color=cream,fontSize=24.sp,fontWeight=FontWeight.Bold)
        if(locked) {
            Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Lock,null,tint=goldColor,modifier=Modifier.size(42.dp));Text("Комната закрыта",color=cream,fontSize=20.sp);Text("Станет доступна позже",color=muted)}}
        } else {
            Text("Пять инструментов • свайп не влияет на нижнюю навигацию",color=muted,fontSize=10.sp)
            LazyVerticalGrid(columns=GridCells.Fixed(2),modifier=Modifier.weight(1f),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                items(tools) { tool ->
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(panel).clickable{onMessage(tool.name)}.padding(8.dp)) {
                        AsyncImage(model=tool.image,contentDescription=tool.name,modifier=Modifier.fillMaxWidth().aspectRatio(3f/4f).clip(RoundedCornerShape(8.dp)))
                        Text(tool.name,color=cream,fontSize=12.sp,fontWeight=FontWeight.SemiBold,minLines=2)
                        Text("Ранг ${rankNames[ranks[tool.name]?:0]}",color=goldColor,fontSize=10.sp)
                        Button(onClick={
                            val current = ranks[tool.name] ?: 0
                            if (current < 9) {
                                onRank(tool.name)
                                onMessage("${tool.name}: улучшение до ${rankNames[current + 1]} выполнено бесплатно.")
                            }
                        },enabled=(ranks[tool.name] ?: 0) < 9,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(2.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Улучшить",fontSize=11.sp)}
                        tool.requirements.forEach{Text(it,color=muted,fontSize=9.sp)}
                    }
                }
            }
            if(message.isNotBlank()) Text(message,color=goldColor,fontSize=10.sp)
        }
    }
}
@Composable
private fun StorageScreen(items:List<Item>,onItem:(Item)->Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Склад",color=cream,fontSize=24.sp,fontWeight=FontWeight.Bold)
        Text("Предметы на складе не учитываются в переносимом весе.",color=muted,fontSize=11.sp)
        LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.fillMaxSize(),contentPadding=PaddingValues(top=10.dp),verticalArrangement=Arrangement.spacedBy(6.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            items(40) { i -> val item=items.getOrNull(i)
                Box(Modifier.aspectRatio(1f).background(panel,RoundedCornerShape(7.dp)).clickable{item?.let(onItem)},contentAlignment=Alignment.Center) {
                    if(item!=null) Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Inventory2,null,tint=goldColor);Text(item.name.take(10),color=cream,fontSize=7.sp,textAlign=TextAlign.Center);Text("×${item.amount}",color=muted,fontSize=8.sp)}
                    else Text("·",color=muted)
                }
            }
        }
    }
}
@Composable
private fun MarketScreen(merchants:List<Merchant>,onSelect:(Merchant)->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text("Рынок",color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
        merchants.forEach { m ->
            Row(Modifier.fillMaxWidth().padding(vertical=5.dp).background(panel,RoundedCornerShape(12.dp)).clickable{onSelect(m)}.padding(13.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Store,null,tint=goldColor,modifier=Modifier.size(34.dp));Spacer(Modifier.width(10.dp))
                Column { Text(m.name,color=cream,fontWeight=FontWeight.Bold);Text("${m.job} • ${m.race}",color=muted,fontSize=11.sp) }
                Spacer(Modifier.weight(1f));Text("Торговать ›",color=goldColor,fontSize=11.sp)
            }
        }
    }
}
@Composable
private fun MerchantScreen(merchant:Merchant,goldBalance:Int,onBuy:(Item)->Unit,onLeave:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        TextButton(onClick=onLeave){Text("← К торговцам",color=goldColor)}
        Text(merchant.name,color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
        Text("${merchant.job} • ${merchant.race}",color=muted)
        Text("«Что брать будешь?»",color=goldColor,modifier=Modifier.padding(vertical=10.dp))
        merchant.stock.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(vertical=4.dp).background(panel,RoundedCornerShape(10.dp)).padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)){Text(item.name,color=cream,fontWeight=FontWeight.SemiBold);Text("${item.price} G / ${item.unit}",color=muted,fontSize=11.sp)}
                Button(onClick={onBuy(item)},colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Купить")}
            }
        }
        Text("Твоё золото: $goldBalance G",color=goldColor,fontWeight=FontWeight.Bold)
    }
}
@Composable
private fun MapScreen(location:String,onMove:(String)->Unit) {
    val places=listOf("Рынок" to "Здесь можно купить всё, что тебе нужно.","Ворота" to "Выход из города.","Замок" to "Здесь живёт король.","Дом" to "Дряхлый, но свой.")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text("Карта",color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        places.forEach { (name,desc) ->
            Row(Modifier.fillMaxWidth().padding(vertical=5.dp).background(panel,RoundedCornerShape(12.dp)).padding(11.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Place,null,tint=goldColor);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text(name,color=cream,fontWeight=FontWeight.Bold);Text(desc,color=muted,fontSize=10.sp)}
                if(location==name)Text("Вы здесь",color=goldColor,fontSize=10.sp) else Button(onClick={onMove(name)},contentPadding=PaddingValues(horizontal=7.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Переместиться",fontSize=9.sp)}
            }
        }
    }
}
@Composable
private fun LocationScreen(location:String) {
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(Icons.Default.Place,null,tint=goldColor,modifier=Modifier.size(45.dp))
        Text(location,color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        Text(when(location){"Ворота"->"Выход из города.";"Замок"->"Здесь живёт король.";else->"Текущая локация."},color=muted)
    }
}
@Composable
private fun CharacterScreen(level:Int,xp:Int,free:Int,stats:MutableMap<String,Int>,skillLevels:Map<String,Int>,skillXp:Map<String,Int>,inventory:List<Item>,equipment:Map<String,Item>,hp:Int,mp:Int,ov:Int,sub:Int,onSub:(Int)->Unit,onItem:(Item)->Unit,onEquip:(String,Item)->Unit,onUnequip:(String)->Unit,expanded:String,onExpand:(String)->Unit,onImprove:(String)->Unit) {
    val descriptions=mapOf(
        "Сила" to "Влияет на общий переносимый вес и на количество обрабатываемого материала за раз. Отвечает за навык кузнечного дела и за урон ближним оружием.",
        "Ловкость" to "Влияет на скорость выполнения действий и точность движений. Отвечает за эффективность кожевенного дела и владение одноручным оружием и оружием дальнего боя.",
        "Выносливость" to "Увеличивает запас здоровья и количество ОВ. ОВ тратится во время работы или боя. Влияет на эффективность блокирования.",
        "Интеллект" to "Влияет на запас маны и эффективность работы с рунами. Отвечает за навык рунической гравировки и определяет количество доступных ячеек активных навыков.",
        "Удача" to "Я в такое не верю."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(13.dp)) {
        Text("Персонаж",color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        Text("Уровень $level • Опыт $xp/${level*100} • Свободные очки: $free",color=goldColor,fontSize=11.sp)
        Text("HP $hp • MP $mp • ОВ $ov",color=muted,fontSize=11.sp)
        Spacer(Modifier.height(8.dp));Text("ЭКИПИРОВКА",color=goldColor,fontWeight=FontWeight.Bold,fontSize=11.sp)
        val slotRows=listOf(listOf("Кольцо 1","Голова","Кольцо 2"),listOf("Лук","Ожерелье","Стрелы"),listOf("Правая рука","Тело","Левая рука"),listOf("Оружие 1","Ноги","Оружие 2"),listOf("Зелье 1","Ступни","Зелье 2"))
        slotRows.forEach { row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){row.forEach{slot->val item=equipment[slot] ?: equipment[if(slot=="Правая рука")"Правая рука" else slot];Box(Modifier.weight(1f).height(43.dp).padding(vertical=2.dp).background(panel,RoundedCornerShape(7.dp)).clickable{if(item!=null)onUnequip(slot)},contentAlignment=Alignment.Center){Text(item?.name?.take(12)?:slot,color=if(item!=null)goldColor else muted,fontSize=9.sp,textAlign=TextAlign.Center)}}}}
        Text("Атака: ${5+(stats["Сила"]?:5)} • Защита: 0 • Скорость: ${stats["Ловкость"]?:5}",color=cream,fontSize=11.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
            listOf("Инвентарь","Навыки","Характеристики").forEachIndexed{i,s->Button(onClick={onSub(i)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(3.dp),colors=ButtonDefaults.buttonColors(containerColor=if(sub==i)goldColor else panel,contentColor=if(sub==i)Color.Black else cream)){Text(s,fontSize=9.sp)}}
        }
        Spacer(Modifier.height(8.dp))
        when(sub) {
            0 -> {
                Text("ИНВЕНТАРЬ",color=goldColor,fontWeight=FontWeight.Bold)
                LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.height(260.dp),userScrollEnabled=false,verticalArrangement=Arrangement.spacedBy(5.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    items(30){i->val item=inventory.getOrNull(i);Box(Modifier.aspectRatio(1f).background(panel,RoundedCornerShape(7.dp)).clickable{item?.let(onItem)},contentAlignment=Alignment.Center){if(item!=null)Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Inventory2,null,tint=goldColor);Text(item.name.take(9),color=cream,fontSize=7.sp,textAlign=TextAlign.Center);Text("×${item.amount}",color=muted,fontSize=7.sp)}else Text("·",color=muted)}}
                }
            }
            1 -> {
                Text("ПАССИВНЫЕ НАВЫКИ",color=goldColor,fontWeight=FontWeight.Bold)
                listOf("Кузнечное дело","Кожевенное дело","Руническая гравировка","Двуручное оружие","Одноручное оружие","Дальний бой","Блокирование").forEach{s->
                    Column(Modifier.fillMaxWidth().padding(vertical=5.dp)){Row{Text(s,color=cream,modifier=Modifier.weight(1f));Text("${skillLevels[s]?:1}",color=goldColor)};LinearProgressIndicator(progress={((skillXp[s]?:0)/100f).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth(),color=goldColor);Text("${skillXp[s]?:0}/100",color=muted,fontSize=9.sp)}
                }
                Text("АКТИВНЫЕ НАВЫКИ",color=goldColor,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
                val unlocked=5+((stats["Интеллект"]?:5)-5).coerceAtLeast(0)/5
                LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.height(100.dp),userScrollEnabled=false,horizontalArrangement=Arrangement.spacedBy(5.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    items(unlocked+1){i->Box(Modifier.aspectRatio(1f).background(panel,RoundedCornerShape(7.dp)),contentAlignment=Alignment.Center){Text(if(i<unlocked)"+" else "🔒",color=if(i<unlocked)goldColor else muted)}}
                }
            }
            else -> {
                Text("ХАРАКТЕРИСТИКИ",color=goldColor,fontWeight=FontWeight.Bold)
                listOf("Сила","Ловкость","Выносливость","Интеллект","Удача").forEach{s->
                    Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(9.dp)).clickable{onExpand(if(expanded==s)"" else s)}.padding(10.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically){Text(s,color=cream,modifier=Modifier.weight(1f));Text("${stats[s]?:5}",color=goldColor,fontWeight=FontWeight.Bold);TextButton(onClick={onImprove(s)},contentPadding=PaddingValues(horizontal=8.dp)){Text("+",color=if(free>0)goldColor else red,fontSize=19.sp)}}
                        if(expanded==s)Text(descriptions[s]?: "",color=muted,fontSize=11.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(multiplier:String,onMultiplier:(String)->Unit,onXp:()->Unit,onGold:()->Unit) {
    var expanded by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Настройки",color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        Text("Множитель опыта",color=goldColor)
        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}) {
            OutlinedTextField(value="×$multiplier",onValueChange={},readOnly=true,modifier=Modifier.menuAnchor().fillMaxWidth(),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=cream,unfocusedTextColor=cream))
            ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){listOf("0.5","1","2","5","10").forEach{v->DropdownMenuItem(text={Text("×$v")},onClick={onMultiplier(v);expanded=false})}}
        }
        Button(onClick=onXp,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Получить опыт (+${(80*multiplier.toDouble()).toInt()} XP)")}
        Button(onClick=onGold,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Получить золото (+55 G)")}
    }
}
@Composable
private fun Placeholder(text:String) { Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(text,color=muted)} }
