@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.blacksmithspath

import android.os.Bundle
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import kotlin.math.ceil
import kotlin.math.floor
import kotlinx.coroutines.delay

private val bg = Color(0xFF171411)
private val panel = Color(0xFF28221C)
private val goldColor = Color(0xFFC58A43)
private val cream = Color(0xFFF0E4D0)
private val muted = Color(0xFFB8A995)
private val red = Color(0xFFC84D45)

private data class Tool(
    val name: String,
    val image: String,
    val description: String,
    val requirements: List<String>,
    val rankNames: List<String> = List(7) { name },
    val rankDescriptions: List<String> = List(7) { description }
)

private val forgeTool = Tool(
    "Кузница",
    "https://images.pexels.com/photos/12841912/pexels-photo-12841912.jpeg?auto=compress&cs=tinysrgb&w=900",
    "Основное место нагрева и плавки металлов. Не входит в пять основных инструментов кузнеца.",
    listOf("Вместимость зависит от ранга"),
    listOf("Маленькая глиняная печь", "Укреплённая кирпичная печь", "Каменная кузнечная печь", "Большая кузнечная печь", "Профессиональная кузнечная печь", "Совершенная печь кузнечного мастера", "Легендарная руническая кузница"),
    listOf("Простая печь. Вместимость: 5 кг.", "Укреплённая печь. Вместимость: 7 кг.", "Каменная печь. Вместимость: 10 кг.", "Большая печь. Вместимость: 13 кг.", "Профессиональная печь. Вместимость: 17 кг.", "Совершенная печь. Вместимость: 22 кг.", "Легендарная руническая кузница. Вместимость: 28 кг.")
)

private val blacksmithTools = listOf(
    Tool(
        "Печь с подачей воздуха",
        "https://images.pexels.com/photos/12841912/pexels-photo-12841912.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Кузнечная печь для нагрева и плавки металла. Вместимость зависит от ранга.",
        listOf("Навык: кузнечное дело 1 уровня"),
        listOf("Маленькая глиняная печь", "Укреплённая кирпичная печь", "Каменная кузнечная печь", "Большая кузнечная печь", "Профессиональная кузнечная печь", "Совершенная печь кузнечного мастера", "Легендарная руническая кузница"),
        listOf(
            "Небольшая глиняная печь с простыми мехами. Вместимость: 5 кг.",
            "Кирпичная печь с укреплёнными стенками и улучшенной подачей воздуха. Вместимость: 7 кг.",
            "Каменная кузнечная печь с более устойчивой камерой нагрева. Вместимость: 10 кг.",
            "Большая печь с расширенной камерой и равномерным распределением жара. Вместимость: 13 кг.",
            "Профессиональная печь с усиленной подачей воздуха и точным контролем температуры. Вместимость: 17 кг.",
            "Совершенная печь мастера с жаростойкой камерой и тонкой регулировкой нагрева. Вместимость: 22 кг.",
            "Легендарная руническая кузница с автоматическим контролем температуры и сложной системой управления жаром. Вместимость: 28 кг."
        )
    ),
    Tool(
        "Наковальня с кузнечными клещами",
        "https://images.pexels.com/photos/5846089/pexels-photo-5846089.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Единый комплект для ковки и удержания заготовок. Наковальня и клещи улучшаются вместе.",
        listOf("Навык: кузнечное дело 1 уровня"),
        listOf("Ржавая наковальня с клещами", "Железная наковальня с клещами", "Стальная наковальня с клещами", "Кобальтовая наковальня с клещами", "Наковальня из чёрного железа с клещами", "Наковальня из титанового сплава с клещами", "Наковальня из звёздного железа с клещами"),
        listOf(
            "Старая железная наковальня с неровной поверхностью и ржавыми клещами с плохим захватом. Подходит для простейшей ковки.",
            "Железная наковальня с ровной рабочей поверхностью и надёжными клещами. Подходит для изготовления базового оружия и экипировки.",
            "Прочная стальная конструкция, выдерживающая сильные удары. Позволяет точнее обрабатывать металлические заготовки.",
            "Твёрдая рабочая поверхность и прочные клещи. Подходит для обработки тяжёлых и твёрдых заготовок.",
            "Массивный комплект с высокой прочностью и хорошей совместимостью с рунической энергией.",
            "Лёгкая и исключительно прочная конструкция, обеспечивающая точную обработку сложных заготовок.",
            "Редкий комплект из внеземного металла с необычными свойствами. Обеспечивает исключительную точность и стабильность ковки."
        )
    ),
    Tool(
        "Кузнечный молот",
        "https://images.pexels.com/photos/19460423/pexels-photo-19460423.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Основной инструмент кузнеца для придания формы раскалённому металлу.",
        listOf("Сила: 5"),
        listOf("Ржавый кузнечный молот", "Примитивный кузнечный молот", "Усиленный кузнечный молот", "Мастерский кузнечный молот", "Рунический кузнечный молот", "Титановый кузнечный молот", "Молот стихийного мастерства"),
        listOf(
            "Старая железная головка с ржавчиной и грубой рукоятью из обычного дерева. Имеет плохой баланс и неровную ударную поверхность.",
            "Простой железный молот с рукоятью из обычного дерева. Подходит для базовой ковки и изготовления простых изделий.",
            "Стальная головка и дубовая рукоять обеспечивают хорошую прочность и стабильность при ударах.",
            "Кобальтовая головка и рукоять из железного дерева позволяют работать с твёрдыми металлическими заготовками.",
            "Головка из чёрного железа и рукоять из магического дерева обеспечивают хорошую проводимость рунической энергии.",
            "Головка из титанового сплава и титановая рукоять с кожаной намоткой. Отличается высокой прочностью, малым весом и превосходным балансом.",
            "Головка из звёздного железа и рукоять из древа стихий. Обладает высокой прочностью и способностью взаимодействовать с различными элементальными энергиями."
        )
    ),
    Tool(
        "Кузнечный верстак",
        "https://images.pexels.com/photos/32979598/pexels-photo-32979598.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Рабочее место для фиксации, измерения и сборки металлических деталей.",
        listOf("Навык: кузнечное дело 1 уровня"),
        listOf("Старый кузнечный верстак", "Укреплённый кузнечный верстак", "Профессиональный кузнечный верстак", "Усиленный кузнечный верстак", "Мастерский кузнечный верстак", "Совершенный верстак кузнечного мастера", "Верстак великого кузнечного мастера"),
        listOf(
            "Старый деревянный стол с потёртой поверхностью и простыми деревянными упорами. Подходит для размещения небольших заготовок и ручной работы.",
            "Прочная деревянная конструкция с усиленной столешницей и кузнечными тисками. Удобен для фиксации небольших деталей и сборки простых изделий.",
            "Массивная столешница с металлическими креплениями, тисками и набором кузнечных струбцин. Позволяет надёжно фиксировать детали во время сборки.",
            "Стальная рама, толстая рабочая поверхность, тиски, струбцины и поворотный зажим. Позволяет закреплять заготовки под нужным углом.",
            "Прочная конструкция с точной системой фиксации, струбцинами и ручной сверлильной стойкой. Подходит для крупных и сложных заготовок.",
            "Высококачественная рабочая поверхность, усиленная рама, точные механизмы фиксации и механический измерительный калибр. Обеспечивает высокую точность сборки.",
            "Легендарная рабочая станция с идеальной системой фиксации, измерительными приспособлениями, сверлильной оснасткой и универсальным механическим манипулятором. Предназначена для изделий высочайшего качества."
        )
    ),
    Tool(
        "Точильный камень",
        "https://images.pexels.com/photos/5845914/pexels-photo-5845914.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Оборудование для заточки и доводки режущей кромки.",
        listOf("Ловкость: 5"),
        listOf("Простой точильный камень", "Механический точильный круг", "Усиленный точильный станок", "Профессиональный точильный станок", "Мастерская точильная установка", "Рунический точильный станок", "Автоматический рунический точильный комплекс"),
        listOf(
            "Обычный камень на деревянной подставке. Заточка выполняется вручную и требует постоянного контроля угла и давления.",
            "Каменный круг с ножным приводом. Поддерживает равномерное вращение и ускоряет заточку, освобождая руки мастера.",
            "Прочная металлическая конструкция с улучшенным приводом и двумя точильными кругами разной зернистости. Позволяет выполнять грубую обработку и чистовую заточку.",
            "Оснащён регулируемыми упорами и механизмом фиксации изделия. Помогает выдерживать одинаковый угол и получать ровную режущую кромку.",
            "Установка со сменными абразивными кругами, системой подачи охлаждающей жидкости и регулируемой скоростью вращения. Подходит для высокопрочных металлов.",
            "Высокоточная установка с руническим приводом. Руны стабилизируют вращение, регулируют скорость и помогают поддерживать постоянное давление.",
            "Легендарная установка с автоматической фиксацией изделия, определением угла, регулировкой давления и скорости, сменой абразивных кругов и системой охлаждения. Мастеру остаётся установить изделие и задать параметры."
        )
    )
)

private val craftTools = listOf(
    Tool(
        "Примитивная деревянная рама",
        "https://images.pexels.com/photos/6068960/pexels-photo-6068960.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Рама из необработанной сосны с простой верёвочной системой. Подходит для первичной растяжки и сушки кожи, но прогибается под натяжением.",
        listOf("Комната закрыта"),
        listOf("Примитивная деревянная рама", "Укреплённая рама кожевника", "Прочная дубовая рама", "Усиленная кожевенная конструкция", "Мастерская рама кожевника", "Совершенная рама мастера", "Легендарная рама великого ремесленника"),
        listOf(
            "Рама из необработанной сосны с простой верёвочной системой. Подходит для первичной растяжки и сушки кожи, но прогибается под натяжением.",
            "Рама из обработанной сосны с укреплёнными соединениями. Подходит для равномерной растяжки и сушки кожи.",
            "Прочная дубовая рама с железными креплениями. Подходит для надёжной фиксации кожи и равномерного натяжения.",
            "Конструкция из выдержанного ясеня со стальными креплениями. Подходит для точной растяжки и стабильной сушки кожи.",
            "Верстачная рама из клеёной твёрдой древесины с коваными стальными деталями. Подходит для обработки крупных шкур и точного контроля натяжения.",
            "Рама из отборной клеёной древесины и высококачественной стали. Подходит для равномерной обработки кожи без перекосов.",
            "Легендарная рама из редкой чёрной древесины и легендарного сплава с исключительной жёсткостью и системой натяжения. Подходит для обработки кожи высочайшего качества."
        )
    ),
    Tool(
        "Грубое шило",
        "https://images.pexels.com/photos/4210860/pexels-photo-4210860.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Шило с деревянной рукоятью и грубым железным остриём. Подходит для прокалывания кожи и выполнения простых неровных швов.",
        listOf("Комната закрыта"),
        listOf("Грубое шило", "Шило с иглами для шитья", "Улучшенное шило с набором игл", "Кожевенное шило с иглами мастера", "Мастерский набор шила и игл", "Совершенный набор для шитья", "Легендарный набор великого кожевника"),
        listOf(
            "Шило с деревянной рукоятью и грубым железным остриём. Подходит для прокалывания кожи и выполнения простых неровных швов.",
            "Шило с обработанной рукоятью, стальным остриём и простыми иглами. Подходит для более ровных отверстий и аккуратных швов.",
            "Шило из твёрдой древесины с закалённым стальным остриём и набором игл. Подходит для равномерных отверстий и плотных швов.",
            "Кожевенное шило с прочной полированной рукоятью и качественными стальными иглами. Подходит для аккуратных проколов и плотных ровных швов.",
            "Набор из отборной древесины и инструментальной стали. Подходит для мелких равномерных стежков и стабильного натяжения нити.",
            "Набор из редкой твёрдой древесины и высококачественной легированной стали. Подходит для почти незаметных швов и двойной строчки.",
            "Полный набор из легендарного сплава, качественной древесины и специальных игл. Подходит для тончайших ровных швов и прочной двойной строчки."
        )
    ),
    Tool(
        "Простой нож для отделки кожи",
        "https://images.pexels.com/photos/4226876/pexels-photo-4226876.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Нож из обычной стали с деревянной рукоятью. Подходит для обрезки неровностей и грубой отделки кожаных краёв.",
        listOf("Комната закрыта"),
        listOf("Простой нож для отделки кожи", "Нож с инструментом для обработки кромок", "Набор для раскроя и обработки кромок", "Кожевенный набор с полировщиком", "Профессиональный набор отделочника", "Совершенный набор кожевенного мастера", "Легендарный набор мастера отделки"),
        listOf(
            "Нож из обычной стали с деревянной рукоятью. Подходит для обрезки неровностей и грубой отделки кожаных краёв.",
            "Нож из улучшенной стали с рукоятью из твёрдой древесины и простым инструментом для снятия фаски. Подходит для аккуратной обрезки и начальной обработки кромок.",
            "Набор из закалённого ножа, инструмента для снятия фаски и канавкореза. Подходит для раскроя кожи, формирования кромок и декоративных канавок.",
            "Набор из инструментальной стали и полированной древесины с полировщиком кромок и шлифовальными принадлежностями. Подходит для сглаживания и полировки кожаных краёв.",
            "Профессиональный набор с ножом для утончения кожи, инструментами для кромок и полировки. Подходит для тонкой подгонки толщины и качественной отделки.",
            "Совершенный набор из легированной стали и отборной древесины с аппликатором краски для кромок, тонкой шлифовкой и финишной полировкой. Подходит для безупречной отделки.",
            "Полный легендарный комплект для раскроя, утончения, обработки кромок, шлифовки, окрашивания и полировки кожи. Подходит для отделки высочайшего качества."
        )
    ),
    Tool(
        "Грубый скобель",
        "https://images.pexels.com/photos/5845914/pexels-photo-5845914.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Скобель с деревянными рукоятями и грубым железным лезвием. Подходит для снятия коры и первичной грубой обработки древесины.",
        listOf("Комната закрыта"),
        listOf("Грубый скобель", "Простой рубанок", "Рубанок и рашпиль", "Набор деревообработчика", "Профессиональный набор деревообработчика", "Совершенный набор мастера", "Легендарный набор великого мастера"),
        listOf(
            "Скобель с деревянными рукоятями и грубым железным лезвием. Подходит для снятия коры и первичной грубой обработки древесины.",
            "Рубанок с деревянным корпусом и железным лезвием. Подходит для выравнивания поверхности древесины и придания заготовкам простой формы.",
            "Рубанок и металлический рашпиль с деревянной рукоятью. Подходят для выравнивания поверхностей, снятия неровностей и обработки закруглённых участков.",
            "Рубанок, рашпиль и набор стамесок разных размеров. Подходят для точной обработки древесины, создания пазов, углублений и сложных форм.",
            "Инструменты из качественной стали с прочными рукоятями. Подходят для точной подгонки деталей и получения гладкой поверхности.",
            "Высококачественные рубанок, рашпиль и стамески с точной заточкой. Подходят для тонкой обработки, сложной резьбы и идеальной подгонки деталей.",
            "Инструменты из редких материалов с безупречной обработкой и заточкой. Подходят для создания сложнейших деревянных изделий с исключительной точностью и качеством поверхности."
        )
    ),
    Tool(
        "Простой деревянный верстак",
        "https://images.pexels.com/photos/32979598/pexels-photo-32979598.jpeg?auto=compress&cs=tinysrgb&w=900",
        "Грубый деревянный стол с простыми деревянными тисками. Подходит для закрепления небольших заготовок и выполнения простых работ.",
        listOf("Комната закрыта"),
        listOf("Простой деревянный верстак", "Укреплённый столярный верстак", "Столярный верстак с оснасткой", "Крепкий столярный верстак", "Профессиональный верстак", "Совершенный верстак столярного мастера", "Легендарный верстак великого ремесленника"),
        listOf(
            "Грубый деревянный стол с простыми деревянными тисками. Подходит для закрепления небольших заготовок и выполнения простых работ.",
            "Прочная столешница, улучшенные тиски и набор ручных струбцин. Подходит для надёжной фиксации деталей и сборки деревянных изделий.",
            "Усиленные тиски, упоры, струбцины, угольник и разметочный рейсмус. Подходит для точной разметки, подгонки и обработки заготовок.",
            "Массивная столешница, металлические тиски, упоры, струбцины, ручная дрель и набор свёрл. Подходит для сверления отверстий и точной сборки конструкций.",
            "Усиленная конструкция, две системы тисков, набор струбцин, ручная дрель со свёрлами, разметочные инструменты и приспособления для соединения деталей. Подходит для изготовления сложных изделий.",
            "Столешница из отборной древесины, точные металлические тиски, направляющие, набор свёрл, ручные зажимы, измерительные инструменты и приспособления для сложных соединений. Подходит для ювелирно точной сборки.",
            "Легендарная столешница, совершенная система тисков и фиксаторов, полный комплект измерительных и сверлильных инструментов, специальные приспособления для сложных соединений. Подходит для создания изделий высочайшего качества."
        )
    )
)

private val runeTools = listOf(
    Tool("Рукоять для гравировки", "https://images.pexels.com/photos/5974300/pexels-photo-5974300.jpeg?auto=compress&cs=tinysrgb&w=900", "Ручной инструмент для нанесения рун.", listOf("Комната закрыта")),
    Tool("Набор гравировальных резцов", "https://images.pexels.com/photos/5974301/pexels-photo-5974301.jpeg?auto=compress&cs=tinysrgb&w=900", "Резцы для рун разных форм.", listOf("Комната закрыта")),
    Tool("Гравировальные тиски", "https://images.pexels.com/photos/5974302/pexels-photo-5974302.jpeg?auto=compress&cs=tinysrgb&w=900", "Фиксация предмета при гравировке.", listOf("Комната закрыта")),
    Tool("Полировальные камни", "https://images.pexels.com/photos/5974303/pexels-photo-5974303.jpeg?auto=compress&cs=tinysrgb&w=900", "Полировка рунических линий.", listOf("Комната закрыта")),
    Tool("Глубиномер гравировки", "https://images.pexels.com/photos/5974304/pexels-photo-5974304.jpeg?auto=compress&cs=tinysrgb&w=900", "Контроль глубины нанесения рун.", listOf("Комната закрыта"))
)
private val rankNames = listOf("F", "E", "D", "C", "B", "A", "S")
private data class FieldMonster(
    val name: String, val rank: String, val level: Int, val hp: Int, val minAttack: Int, val maxAttack: Int,
    val defense: Double, val speed: Int, val goldMin: Int, val goldMax: Int, val xp: Int, val loot: List<String>, val ov: Int = 20
)

private data class Item(
    val id: Int, val name: String, val description: String, val amount: Double,
    val unit: String, val weightEach: Double, val price: Int = 0,
    val equipmentSlot: String? = null, val equipped: Boolean = false, val stackTag: String = ""
)

private data class MaterialNeed(val label: String, val amount: Double, val unit: String, val aliases: List<String>)
private data class CraftRecipe(val name: String, val description: String, val needs: List<MaterialNeed>, val resultWeight: Double = 1.0)

private fun craftRecipe(name: String): CraftRecipe {
    fun metal(v: Double) = MaterialNeed("Металл", v, "кг", listOf("Железо", "Сталь", "Кобальт", "Чёрное железо", "Адамант", "Орихалк", "Титановый сплав", "Звёздное железо", "Проводящий металл", "Драконья сталь", "Мифрил", "Металл бездны", "Серебро", "Золото"))
    fun coal(v: Double) = MaterialNeed("Уголь", v, "кг", listOf("Уголь", "Бурый уголь", "Каменный уголь", "Крепкий уголь", "Чистый уголь", "Сердце вулкана"))
    fun wood(v: Double) = MaterialNeed("Рукоять (древесина)", v, "кг", listOf("Древесина", "Обычное дерево", "Дуб", "Железное дерево", "Магическое дерево", "Дерево жизни", "Дерево маны", "Древо стихий", "Древо пустоты", "Мировое древо"))
    fun leather(v: Double) = MaterialNeed("Кожа", v, "кг", listOf("Кожа", "Шкура"))
    fun thread(v: Double) = MaterialNeed("Нить", v, "кг", listOf("Нить", "Волокно"))
    val pair = when(name) {
        "Кувалда" -> "Тяжёлое двуручное оружие для мощных ударов." to listOf(metal(1.2),coal(.2),wood(.5))
        "Секира" -> "Двуручное рубящее оружие с тяжёлым лезвием." to listOf(metal(1.0),coal(.2),wood(.4))
        "Копьё" -> "Длинное оружие для колющих атак и удержания противника на расстоянии." to listOf(metal(.8),coal(.2),wood(.8))
        "Меч" -> "Сбалансированное двуручное оружие для рубящих и колющих ударов." to listOf(metal(1.0),coal(.2),wood(.3))
        "Булава" -> "Одноручное ударное оружие с металлической головкой." to listOf(metal(.7),coal(.15),wood(.3))
        "Длинный меч" -> "Одноручный меч с удлинённым клинком и удобной рукоятью." to listOf(metal(.9),coal(.2),wood(.25))
        "Короткий меч" -> "Компактный меч для быстрых атак и ближнего боя." to listOf(metal(.6),coal(.15),wood(.2))
        "Кинжал" -> "Небольшое лёгкое оружие для быстрых точных ударов." to listOf(metal(.35),coal(.1),wood(.15))
        "Топор" -> "Одноручное рубящее оружие для боя и хозяйственных работ." to listOf(metal(.65),coal(.15),wood(.3))
        "Шлем" -> "Металлическая защита головы от ударов и осколков." to listOf(metal(1.1),coal(.2))
        "Нагрудник" -> "Защитная металлическая пластина для корпуса." to listOf(metal(2.5),coal(.4))
        "Перчатки" -> "Защитные перчатки с металлическими накладками." to listOf(metal(.8),coal(.15),leather(.2))
        "Поножи" -> "Защита голеней и коленей от повреждений." to listOf(metal(1.5),coal(.25),leather(.2))
        "Сапоги" -> "Прочные сапоги с усиленной подошвой и кожаным верхом." to listOf(leather(.8),thread(.1),metal(.15))
        "Наконечники" -> "Металлические наконечники для стрел и метательного оружия." to listOf(metal(.2),coal(.1))
        "Ожерелье" -> "Украшение на прочной основе для ношения на шее." to listOf(metal(.2),coal(.1),leather(.1))
        "Кольца" -> "Небольшие металлические кольца для украшения или рун." to listOf(metal(.1),coal(.05))
        "Производственные инструменты" -> "Набор простых рабочих инструментов для ремесла." to listOf(metal(.8),coal(.2),wood(.4))
        "Декор" -> "Декоративная деталь из обработанного дерева и металла." to listOf(wood(.5),metal(.1),coal(.05))
        "Выделанная кожа" -> "Подготовленная кожа для дальнейшего изготовления изделий." to listOf(leather(1.0),MaterialNeed("Крепёж и реагенты",.1,"кг",listOf("Кости","Рога")))
        "Деревянная заготовка" -> "Ровная деревянная заготовка для будущих изделий." to listOf(wood(1.0))
        "Кожаный ремень" -> "Прочный ремень из обработанной кожи." to listOf(leather(.4),thread(.05))
        "Ножны" -> "Кожаные ножны для безопасного ношения клинка." to listOf(leather(.5),thread(.08))
        "Деревянный щит" -> "Лёгкий щит из соединённых деревянных деталей." to listOf(wood(1.5),leather(.2))
        "Рукоять оружия" -> "Подогнанная рукоять для металлического оружия." to listOf(wood(.3),leather(.05))
        "Руническая пластина" -> "Металлическая пластина, подготовленная для нанесения рунической схемы." to listOf(metal(.3),coal(.05))
        "Рунический камень" -> "Каменная основа для хранения простой руны." to listOf(MaterialNeed("Камень",.5,"кг",listOf("Камень")),coal(.05))
        "Гравировка предмета" -> "Нанесение рунической схемы на подготовленную поверхность." to listOf(MaterialNeed("Ядро монстра",1.0,"шт.",listOf("Ядро монстра")))
        else -> "Изделие из доступных материалов." to listOf(metal(.5),coal(.1))
    }
    return CraftRecipe(name,pair.first,pair.second)
}

private fun sameStack(a: Item, b: Item): Boolean =
    a.name == b.name && a.description == b.description && a.unit == b.unit &&
    a.weightEach == b.weightEach && a.equipmentSlot == b.equipmentSlot &&
    a.stackTag == b.stackTag && !a.equipped && !b.equipped

private fun addToStack(target: MutableList<Item>, item: Item, amount: Double = item.amount) {
    var remaining = amount
    if (item.unit == "шт.") {
        while (remaining > 0.0001) {
            val existing = target.firstOrNull { sameStack(it, item) && it.amount < 9999.0 }
            if (existing != null) {
                val placed = minOf(9999.0 - existing.amount, remaining)
                val index = target.indexOf(existing)
                target[index] = existing.copy(amount = existing.amount + placed)
                remaining -= placed
            } else {
                val newId = if (target.any { it.id == item.id }) (target.maxOfOrNull { it.id } ?: item.id) + 1 else item.id
                val placed = minOf(9999.0, remaining)
                target.add(item.copy(id = newId, amount = placed, equipped = false))
                remaining -= placed
            }
        }
    } else {
        val existing = target.firstOrNull { sameStack(it, item) }
        if (existing != null) {
            val index = target.indexOf(existing)
            target[index] = existing.copy(amount = existing.amount + amount)
        } else {
            val newId = if (target.any { it.id == item.id }) (target.maxOfOrNull { it.id } ?: item.id) + 1 else item.id
            target.add(item.copy(id = newId, amount = amount, equipped = false))
        }
    }
}
private data class Merchant(val name: String, val job: String, val race: String, val stock: List<Item>)
private val merchants = listOf(
    Merchant("Борк", "Шахтёр", "Дварф", listOf(
        Item(101,"Железная руда F","Железная руда низкого F-ранга.",100.0,"кг",1.0,5),
        Item(113,"Бурожелезная руда F","Отдельная руда низкого F-ранга для выплавки бурожелеза.",100.0,"кг",1.0,4),
        Item(102,"Уголь","Топливо для плавки.",100.0,"кг",1.0,3),
        Item(103,"Железо F","Базовый металл для оружия и сельского хозяйства.",100.0,"кг",1.0,10),
        Item(114,"Бурожелезо F","Металл F-ранга из бурожелезной руды.",100.0,"кг",1.0,8),
        Item(115,"Сталь E","Крепкий металл, хорошо подходит для экипировки.",100.0,"кг",1.0,18),
        Item(119,"Серебро E","Ценный материал, слабо повышает эффекты рун.",100.0,"кг",1.0,22),
        Item(120,"Золото D","Ценный материал для украшений.",100.0,"кг",1.0,30),
        Item(121,"Кобальт D","Твёрдый, но ломкий металл.",100.0,"кг",1.0,35),
        Item(122,"Чёрное железо C","Высокая прочность и повышенная совместимость с рунами.",100.0,"кг",1.0,55),
        Item(123,"Адамант B","Говорят, что это самый прочный металл после застывания.",100.0,"кг",1.0,90),
        Item(124,"Орихалк B","Хорошее взаимодействие с рунами.",100.0,"кг",1.0,100),
        Item(125,"Титановый сплав B","Малый вес и высокая прочность.",100.0,"кг",1.0,110),
        Item(126,"Звёздное железо A","Необычные свойства внеземного металла.",100.0,"кг",1.0,160),
        Item(127,"Проводящий металл A","Исключительная проводимость энергии.",100.0,"кг",1.0,180),
        Item(128,"Драконья сталь S","Выдерживает колоссальные температуры и нагрузки.",100.0,"кг",1.0,250),
        Item(129,"Мифрил S","Малый вес, прочность и магическая проводимость. Он хорош во всём.",100.0,"кг",1.0,280),
        Item(130,"Металл бездны SS","Этот металл настолько чёрный, что поглощает 99,9% света.",100.0,"кг",1.0,400))),
    Merchant("Милош", "Фермер", "Человек", listOf(
        Item(104,"Грубая кожа F","Необработанная кожа.",100.0,"кг",1.0,6),
        Item(105,"Мягкая кожа F","Подготовленная мягкая кожа.",100.0,"кг",1.0,11),
        Item(106,"Кости F","Кости монстров.",100.0,"кг",1.0,2),
        Item(107,"Рога","Материал для изготовления.",100.0,"шт.",0.2,3))),
    Merchant("Финн", "Лесоруб", "Зверолюд", listOf(
        Item(108,"Обычное дерево F","Самая распространённая древесина. Легко обрабатывается, но обладает невысокой прочностью и плохо выдерживает сильные нагрузки.",100.0,"кг",1.0,4),
        Item(116,"Дуб E","Плотная и прочная древесина. Хорошо выдерживает механические нагрузки, отличается долговечностью и подходит для изготовления надёжных рукоятей.",100.0,"кг",1.0,9),
        Item(117,"Железное дерево D","Чрезвычайно плотная древесина, по твёрдости сопоставимая с некоторыми металлами. Отличается высокой прочностью и устойчивостью к повреждениям.",100.0,"кг",1.0,16),
        Item(131,"Магическое дерево B","Древесина, пропитанная природной магической энергией. Обладает повышенной прочностью и способностью проводить магическую энергию.",100.0,"кг",1.0,60),
        Item(132,"Дерево жизни A","Редкая древесина, наполненная жизненной энергией. Отличается высокой прочностью, восстанавливает свою структуру и обладает целебными свойствами.",100.0,"кг",1.0,120),
        Item(133,"Дерево маны A","Древесина, накапливающая и проводящая ману. Особенно хорошо подходит для магических инструментов и предметов с руническими схемами.",100.0,"кг",1.0,120),
        Item(134,"Древо стихий S","Легендарное дерево, вобравшее энергию всех стихий. Его древесина обладает высокой прочностью и способна взаимодействовать с различными элементальными энергиями.",100.0,"кг",1.0,250),
        Item(135,"Древо пустоты S","Таинственное дерево, связанное с энергией пустоты. Его древесина обладает необычной структурой, высокой устойчивостью к магическому воздействию и способностью взаимодействовать с энергией пустоты.",100.0,"кг",1.0,300),
        Item(136,"Мировое древо SS","Древнейшее и величайшее дерево мироздания. Его древесина содержит первозданную энергию, обладает невероятной прочностью и сохраняет свойства под воздействием сил высшего порядка.",100.0,"кг",1.0,500),
        Item(109,"Ветки F","Подходят для простых заготовок.",100.0,"шт.",0.1,2))),
    Merchant("Ларс", "Авантюрист", "Человек", listOf(
        Item(110,"Ядро монстра F","Сгусток энергии монстра.",100.0,"шт.",0.1,10),
        Item(111,"Шкура волка F","Шкура обычного волка.",100.0,"кг",1.0,12),
        Item(112,"Клыки волка F","Острые волчьи клыки.",100.0,"шт.",0.05,5))),
    Merchant("Йохан", "Торговец зельями и книгами навыков", "Человек", listOf(
        Item(140,"Малое зелье здоровья","Восстанавливает игроку 50 HP.",99.0,"шт.",0.25,20,equipmentSlot="Зелье 1"),
        Item(141,"Малое зелье выносливости","Восстанавливает игроку 25 ОВ.",99.0,"шт.",0.25,25,equipmentSlot="Зелье 2"),
        Item(142,"Книга навыков: Огненный шар","Изучение активного боевого заклинания «Огненный шар».",1.0,"шт.",0.2,50)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setContent { BlacksmithApp() }
    }
}

@Composable
private fun BlacksmithApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val focusManager = LocalFocusManager.current
    var showResetConfirm by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var room by remember { mutableIntStateOf(0) }
    var showStorage by remember { mutableStateOf(false) }
    var craftRoomUnlocked by remember { mutableStateOf(false) }
    var runeRoomUnlocked by remember { mutableStateOf(false) }
    var location by remember { mutableStateOf("Дом") }
    var level by remember { mutableIntStateOf(1) }
    var xp by remember { mutableIntStateOf(0) }
    var freePoints by remember { mutableIntStateOf(0) }
    var goldBalance by remember { mutableIntStateOf(0) }
    var reputation by remember { mutableIntStateOf(0) }
    var multiplier by remember { mutableStateOf("1") }
    val stats = remember { mutableStateMapOf("Сила" to 5, "Ловкость" to 5, "Выносливость" to 5, "Интеллект" to 5, "Удача" to 5) }
    val skills = listOf("Кузнечное дело","Ремесленное дело","Руническая гравировка","Двуручное оружие","Одноручное оружие","Дальний бой","Блокирование")
    val skillXp = remember { mutableStateMapOf<String, Int>().apply { skills.forEach { put(it,0) } } }
    val skillLevels = remember { mutableStateMapOf<String, Int>().apply { skills.forEach { put(it,1) } } }
    val toolRanks = remember { mutableStateMapOf<String, Int>().apply { (listOf(forgeTool)+blacksmithTools+craftTools+runeTools).forEach { put(it.name,0) } } }
    val inventory = remember { mutableStateListOf<Item>().apply { add(Item(1,"Начальный молот кузнеца","При экипировке повышает силу на 1.",1.0,"шт.",2.0,equipmentSlot="Оружие 1")) } }
    val storage = remember { mutableStateListOf<Item>() }
    val equipment = remember { mutableStateMapOf<String, Item>() }
    var drawerItem by remember { mutableStateOf<Item?>(null) }
    var drawerStorage by remember { mutableStateOf(false) }
    var quantityText by remember { mutableStateOf("") }
    var drawerSliderValue by remember { mutableFloatStateOf(0f) }
    var confirmDelete by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    var merchant by remember { mutableStateOf<Merchant?>(null) }
    var buyItem by remember { mutableStateOf<Item?>(null) }
    var buyQty by remember { mutableStateOf("") }
    var buySliderValue by remember { mutableFloatStateOf(1f) }
    var expandedStat by remember { mutableStateOf("") }
    var subTab by remember { mutableIntStateOf(0) }
    var productionMessage by remember { mutableStateOf("Выбери доступную мастерскую и инструмент.") }
    var pendingUpgrade by remember { mutableStateOf<Pair<Tool, Int>?>(null) }
    var fieldResearch by remember { mutableIntStateOf(0) }
    var autoExplore by remember { mutableStateOf(false) }
    var gameDay by remember { mutableIntStateOf(1) }
    var gameMinutes by remember { mutableIntStateOf(7 * 60) }
    var bedRank by remember { mutableIntStateOf(0) }
    var bedDialog by remember { mutableStateOf(false) }
    var currentHp by remember { mutableIntStateOf(0) }
    var currentMp by remember { mutableIntStateOf(0) }
    var currentOv by remember { mutableIntStateOf(0) }
    var inBattle by remember { mutableStateOf(false) }
    var battleMonster by remember { mutableStateOf<FieldMonster?>(null) }
    var monsterHp by remember { mutableIntStateOf(0) }
    var monsterOv by remember { mutableIntStateOf(20) }
    var deathDialog by remember { mutableStateOf(false) }
    var deathPenalty by remember { mutableIntStateOf(0) }
    var battleNotice by remember { mutableStateOf("") }
    var battleTick by remember { mutableIntStateOf(0) }
    var fireballLearned by remember { mutableStateOf(false) }
    var fireballCooldown by remember { mutableStateOf(false) }
    var fireballDrawer by remember { mutableStateOf(false) }
    var rewardDialog by remember { mutableStateOf(false) }
    val claimedFieldRewards = remember { mutableStateListOf<Int>() }
    val bedNames = listOf("Неудобная старая кровать", "Улучшенная кожаная кровать", "Хорошая кровать", "Мягкая кровать", "Комфортная кровать", "Очень удобная кровать", "Царское ложе")
    val bedOv = listOf(100, 150, 200, 300, 400, 500, 1000)
    fun advanceGameTime(minutes: Int) {
        val total = gameMinutes + minutes
        gameDay += total / (24 * 60)
        gameMinutes = total % (24 * 60)
    }

    LaunchedEffect(fireballCooldown) {
        if (fireballCooldown) { delay(3000L); fireballCooldown = false }
    }

    val strength = (stats["Сила"] ?: 5) + if (equipment.containsKey("Оружие 1") || equipment.containsKey("Оружие 2")) 1 else 0
    val endurance = stats["Выносливость"] ?: 5
    val intelligence = stats["Интеллект"] ?: 5
    val hpMax = 100 + 20 * endurance + 5 * level
    val mpMax = 50 + 15 * intelligence + 3 * level
    val ovMax = 50 + 10 * endurance + 2 * level
    LaunchedEffect(hpMax, mpMax, ovMax) {
        if (currentHp == 0) currentHp = hpMax
        if (currentMp == 0) currentMp = mpMax
        if (currentOv == 0) currentOv = ovMax
    }
    val carryMax = 30.0 + strength * 4.0
    val carryNow = inventory.sumOf { it.amount * it.weightEach } + equipment.values.sumOf { it.amount * it.weightEach }
    val reputationRank = listOf(250,500,1000,2000,4000,8000).indexOfFirst { reputation < it }.let { if (it < 0) 6 else it }
    val reputationName = listOf("F","E","D","C","B","A","S")[reputationRank]
    val reputationBase = listOf(0,250,500,1000,2000,4000,8000)[reputationRank]
    val reputationNext = listOf(250,500,1000,2000,4000,8000,16000)[reputationRank]
    val reputationInRank = reputation - reputationBase

    fun addXp(amount: Int) {
        xp += amount
        while (xp >= level * 100) { xp -= level * 100; level += 1; freePoints += 2 }
    }
    fun moveItem(item: Item, fromStorage: Boolean, count: Double, destinationStorage: Boolean) {
        val source = if (fromStorage) storage else inventory
        val destination = if (destinationStorage) storage else inventory
        val found = source.firstOrNull { it.id == item.id } ?: return
        if (fromStorage && !destinationStorage && carryNow + count * item.weightEach > carryMax) { toast = "Вы столько не унесёте."; return }
        if (!fromStorage && destinationStorage && location != "Дом") { toast = "Выложить можно только дома."; return }
        val safeCount = count.coerceIn(0.0, found.amount)
        source.remove(found)
        if (found.amount > safeCount + 0.0001) source.add(found.copy(amount = found.amount - safeCount))
        addToStack(destination, found, safeCount)
        drawerItem = null
    }

    fun encounter(exploring: Boolean) {
        val chance = if (exploring) 1.0 else 0.5
        if (Math.random() < chance) {
            val levelRange = (1..5).toList()
            val monsterLevel = levelRange.random()
            val monster = FieldMonster("Слизень","F",monsterLevel,90+10*monsterLevel,5,7+monsterLevel,0.0,3,2,5,20+2*monsterLevel,listOf("Ядро монстра F ×1","Слизь F"))
            battleMonster = monster; monsterHp = monster.hp; monsterOv = monster.ov; inBattle = true
            if (currentHp <= 0) currentHp = hpMax
            if (currentMp <= 0) currentMp = mpMax
            if (currentOv <= 0) currentOv = ovMax
        } else toast = "Встреч с монстрами не обнаружено."
    }

    fun finishVictory() {
        val m = battleMonster ?: return
        val earnedGold = (m.goldMin..m.goldMax).random()
        goldBalance += earnedGold
        addXp(m.xp)
        fieldResearch = (fieldResearch + 2).coerceAtMost(100)
        // Выпавшие материалы действительно попадают в инвентарь.
        if (m.name == "Слизень") {
            addToStack(inventory, Item(200, "Ядро монстра F", "Сгусток энергии монстра.", 1.0, "шт.", 0.1))
            addToStack(inventory, Item(201, "Слизь F", "Материал, полученный после победы над слизнем.", 1.0, "шт.", 0.1))
        }
        battleNotice = "Вы победили ${m.name}. Получено: ${m.loot.joinToString()}, $earnedGold G, ${m.xp} опыта."
        inBattle = false
        battleMonster = null
        if (autoExplore && location == "Поля") {
            encounter(true)
        } else {
            toast = battleNotice
        }
    }

    LaunchedEffect(inBattle, battleMonster, currentHp, currentOv, monsterHp, monsterOv) {
        while (inBattle && battleMonster != null) {
            delay(1000L)
            advanceGameTime(1)
            val m = battleMonster ?: break
            // Один боевой такт; скорость определяет частоту ударов по заданной формуле.
            val playerInterval = (1000.0 * Math.pow(10.0, -(stats["Ловкость"] ?: 5) / 50.0)).toLong().coerceAtLeast(1L)
            val monsterInterval = (1000.0 * Math.pow(10.0, -m.speed / 50.0)).toLong().coerceAtLeast(1L)
            if (currentOv > 0 && battleTick % (playerInterval / 1000L).coerceAtLeast(1L).toInt() == 0) {
                monsterHp = (monsterHp - (strength * 2 + 5)).coerceAtLeast(0); currentOv = (currentOv - 1).coerceAtLeast(0)
            }
            if (monsterHp <= 0) { finishVictory(); break }
            if (monsterOv > 0 && battleTick % (monsterInterval / 1000L).coerceAtLeast(1L).toInt() == 0) {
                currentHp = (currentHp - (m.minAttack..m.maxAttack).random()).coerceAtLeast(0); monsterOv = (monsterOv - 1).coerceAtLeast(0)
            }
            battleTick++
            if (currentHp <= 0) {
                deathPenalty = floor(goldBalance * 0.01).toInt(); goldBalance -= deathPenalty
                gameDay += 1; gameMinutes = 7 * 60
                currentHp = hpMax; currentMp = mpMax
                autoExplore = false
                deathDialog = true; inBattle = false; battleMonster = null; location = "Дом"; break
            }
        }
    }

    // Автосохранение одного слота на устройстве: файл настроек перезаписывается каждые 10 секунд.
    LaunchedEffect(Unit) {
        val prefs=context.getSharedPreferences("blacksmiths_path_save", Context.MODE_PRIVATE)
        fun itemJson(item:Item)=JSONObject().apply {
            put("id",item.id);put("name",item.name);put("description",item.description);put("amount",item.amount);put("unit",item.unit);put("weightEach",item.weightEach);put("price",item.price);put("equipmentSlot",item.equipmentSlot ?: JSONObject.NULL);put("equipped",item.equipped);put("stackTag",item.stackTag)
        }
        fun readItems(array:JSONArray): List<Item> = (0 until array.length()).mapNotNull { i -> runCatching { val o=array.getJSONObject(i); Item(o.getInt("id"),o.getString("name"),o.optString("description"),o.optDouble("amount"),o.optString("unit"),o.optDouble("weightEach"),o.optInt("price"),if(o.isNull("equipmentSlot"))null else o.optString("equipmentSlot"),o.optBoolean("equipped"),o.optString("stackTag")) }.getOrNull() }
        if(prefs.contains("snapshot")) runCatching {
            val root=JSONObject(prefs.getString("snapshot","{}") ?: "{}")
            level=root.optInt("level",level);xp=root.optInt("xp",xp);freePoints=root.optInt("freePoints",freePoints);goldBalance=root.optInt("gold",goldBalance);reputation=root.optInt("reputation",reputation)
            location=root.optString("location",location);room=root.optInt("room",room).coerceIn(0,2);gameDay=root.optInt("day",gameDay);gameMinutes=root.optInt("minutes",gameMinutes)
            fieldResearch=root.optInt("research",fieldResearch);autoExplore=root.optBoolean("autoExplore",autoExplore);bedRank=root.optInt("bedRank",bedRank).coerceIn(0,6);fireballLearned=root.optBoolean("fireball",fireballLearned)
            craftRoomUnlocked=root.optBoolean("craftUnlocked",false);runeRoomUnlocked=root.optBoolean("runeUnlocked",false);multiplier=root.optString("multiplier",multiplier)
            currentHp=root.optInt("hp",currentHp);currentMp=root.optInt("mp",currentMp);currentOv=root.optInt("ov",currentOv)
            val st=root.optJSONObject("stats");if(st!=null) stats.keys.toList().forEach{stats[it]=st.optInt(it,stats[it]?:5)}
            val lv=root.optJSONObject("skillLevels");if(lv!=null) skills.forEach{skillLevels[it]=lv.optInt(it,1)}
            val sx=root.optJSONObject("skillXp");if(sx!=null) skills.forEach{skillXp[it]=sx.optInt(it,0)}
            val tr=root.optJSONObject("toolRanks");if(tr!=null) toolRanks.keys.toList().forEach{toolRanks[it]=tr.optInt(it,0).coerceIn(0,6)}
            inventory.clear();inventory.addAll(readItems(root.optJSONArray("inventory")?:JSONArray()))
            storage.clear();storage.addAll(readItems(root.optJSONArray("storage")?:JSONArray()))
            equipment.clear();val eq=root.optJSONArray("equipment")?:JSONArray();readItems(eq).forEach{it.equipmentSlot?.let{slot->equipment[slot]=it}}
            claimedFieldRewards.clear();val rewards=root.optJSONArray("claimedRewards")?:JSONArray();for(i in 0 until rewards.length()) claimedFieldRewards.add(rewards.optInt(i))
        }
        while(true) {
            delay(10_000L)
            val root=JSONObject().apply {
                put("level",level);put("xp",xp);put("freePoints",freePoints);put("gold",goldBalance);put("reputation",reputation);put("location",location);put("room",room)
                put("day",gameDay);put("minutes",gameMinutes);put("research",fieldResearch);put("autoExplore",autoExplore);put("bedRank",bedRank);put("fireball",fireballLearned)
                put("craftUnlocked",craftRoomUnlocked);put("runeUnlocked",runeRoomUnlocked);put("multiplier",multiplier);put("hp",currentHp);put("mp",currentMp);put("ov",currentOv)
                put("stats",JSONObject().apply{stats.forEach{(k,v)->put(k,v)}});put("skillLevels",JSONObject().apply{skills.forEach{put(it,skillLevels[it]?:1)}});put("skillXp",JSONObject().apply{skills.forEach{put(it,skillXp[it]?:0)}});put("toolRanks",JSONObject().apply{toolRanks.forEach{(k,v)->put(k,v)}})
                put("inventory",JSONArray().apply{inventory.forEach{put(itemJson(it))}});put("storage",JSONArray().apply{storage.forEach{put(itemJson(it))}});put("equipment",JSONArray().apply{equipment.values.forEach{put(itemJson(it))}});put("claimedRewards",JSONArray().apply{claimedFieldRewards.forEach{put(it)}})
            }
            prefs.edit().putString("snapshot",root.toString()).apply()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background=bg, surface=panel, primary=goldColor, onPrimary=Color.Black, onBackground=cream, onSurface=cream)) {
        Box(Modifier.fillMaxSize().background(bg)) {
            Column(Modifier.fillMaxSize()) {
                if (tab == 0) {
                    StatusHeader(level,currentHp.coerceAtLeast(0),hpMax,currentMp.coerceAtLeast(0),mpMax,currentOv.coerceAtLeast(0),ovMax,reputationName,reputationInRank,reputationNext-reputationBase,goldBalance,5+strength,0,stats["Ловкость"]?:5)
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        0 -> {
                            if (location == "Дом") {
                                Column(Modifier.fillMaxSize()) {
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=8.dp, vertical=7.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                                        listOf("Кузница","Ремесло","Руническая гравировка").forEachIndexed { i, title ->
                                            FilterChip(selected=!showStorage && room==i,onClick={room=i;showStorage=false;pendingUpgrade=null},label={Text(title,fontSize=11.sp)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=goldColor,selectedLabelColor=Color.Black,labelColor=cream))
                                        }
                                    }
                                    Box(Modifier.weight(1f).fillMaxWidth().pointerInput(room,showStorage) {
                                        var drag = 0f
                                        detectHorizontalDragGestures(onHorizontalDrag={ _, amount -> drag += amount }, onDragEnd={
                                            if (!showStorage && drag < -70f) { room=(room+1).coerceAtMost(2); pendingUpgrade=null }
                                            else if (!showStorage && drag > 70f) { room=(room-1).coerceAtLeast(0); pendingUpgrade=null }
                                            drag=0f
                                        })
                                    }) {
                                        if (showStorage) StorageScreen(storage) { item -> drawerItem=item; drawerStorage=true; quantityText="";drawerSliderValue=0f }
                                        else when(room) {
                                            0 -> Column(Modifier.fillMaxSize()) {
                                                Row(Modifier.fillMaxWidth().padding(horizontal=14.dp, vertical=6.dp).clip(RoundedCornerShape(12.dp)).background(panel).clickable { bedDialog=true }.padding(10.dp), verticalAlignment=Alignment.CenterVertically) {
                                                    Text("🛏️", fontSize=25.sp)
                                                    Spacer(Modifier.width(10.dp))
                                                    Column(Modifier.weight(1f)) { Text("${bedNames[bedRank]}", color=cream, fontWeight=FontWeight.Bold); Text("Кровать · ранг ${rankNames[bedRank]}", color=muted, fontSize=10.sp) }
                                                    Text("Открыть ›", color=goldColor, fontSize=11.sp)
                                                }
                                                Box(Modifier.weight(1f)) {
                                                    WorkshopRoom("Кузница",blacksmithTools,toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(6)}}, onMessage={productionMessage=it}, message=productionMessage, onRequestUpgrade={tool,current->pendingUpgrade=tool to current}, extraTool=forgeTool)
                                                }
                                            }
                                            1 -> WorkshopRoom("Ремесло",craftTools,toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(6)}}, onMessage={productionMessage=it}, message=productionMessage, onRequestUpgrade={tool,current->pendingUpgrade=tool to current}, locked=!craftRoomUnlocked, unlockCost=150, gold=goldBalance, onUnlock={goldBalance-=150;craftRoomUnlocked=true})
                                            else -> WorkshopRoom("Руническая гравировка",runeTools,toolRanks, onRank={name->toolRanks[name]=(toolRanks[name]?:0).let{(it+1).coerceAtMost(6)}}, onMessage={productionMessage=it}, message=productionMessage, onRequestUpgrade={tool,current->pendingUpgrade=tool to current}, locked=!runeRoomUnlocked, unlockCost=500, gold=goldBalance, onUnlock={goldBalance-=500;runeRoomUnlocked=true})
                                        }
                                    }
                                    Button(onClick={showStorage=!showStorage}, modifier=Modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=5.dp), colors=ButtonDefaults.buttonColors(containerColor=if(showStorage)goldColor else panel,contentColor=if(showStorage)Color.Black else cream)) { Text(if(showStorage)"Вернуться в мастерскую" else "Склад") }
                                }
                            } else if (location == "Рынок") {
                                if (merchant == null) MarketScreen(merchants) { merchant=it }
                                else Box(Modifier.fillMaxSize().pointerInput(merchant) {
                                    var drag = 0f
                                    detectHorizontalDragGestures(onHorizontalDrag={ _, amount -> drag += amount }, onDragEnd={
                                        if (drag > 70f) { merchant=null; buyItem=null }
                                        drag=0f
                                    })
                                }) { MerchantScreen(merchant!!,goldBalance,{item->buyItem=item;buyQty="";buySliderValue=1f},{merchant=null}) }
                            } else if (location == "Поля" && inBattle && battleMonster != null) {
                                BattleScreen(battleMonster!!,monsterHp,monsterOv,currentHp,currentMp,currentOv,hpMax,mpMax,ovMax,
                                    hpPotion=equipment["Зелье 1"], ovPotion=equipment["Зелье 2"], fireballLearned=fireballLearned, fireballCooldown=fireballCooldown,
                                    onHpPotion={
                                        val potion=equipment["Зелье 1"]
                                        if(potion!=null) { if(potion.amount>1) equipment["Зелье 1"]=potion.copy(amount=potion.amount-1) else equipment.remove("Зелье 1"); currentHp=(currentHp+50).coerceAtMost(hpMax); toast="Малое зелье здоровья использовано: +50 HP." }
                                        else toast="Зелье здоровья не экипировано."
                                    },
                                    onOvPotion={
                                        val potion=equipment["Зелье 2"]
                                        if(potion!=null) { if(potion.amount>1) equipment["Зелье 2"]=potion.copy(amount=potion.amount-1) else equipment.remove("Зелье 2"); currentOv=(currentOv+25).coerceAtMost(ovMax); toast="Малое зелье выносливости использовано: +25 ОВ." }
                                        else toast="Зелье выносливости не экипировано."
                                    },
                                    onFireball={
                                        when {
                                            fireballCooldown -> toast="Навык на перезарядке."
                                            currentMp<25 -> toast="Недостаточно маны."
                                            else -> { currentMp-=25; monsterHp=(monsterHp-50).coerceAtLeast(0); fireballCooldown=true; if(monsterHp<=0) finishVictory() }
                                        }
                                    },
                                    onEscape={ inBattle=false; battleMonster=null; autoExplore=false; toast="Вы сдались и прекратили цикл исследования." })
                            } else if (location == "Поля") {
                                FieldLocationScreen(fieldResearch, autoExplore, onAutoExplore={autoExplore=it}, onRest={ advanceGameTime(30); currentOv=(currentOv+5).coerceAtMost(ovMax); encounter(false) }, onExplore={
                                    fieldResearch=(fieldResearch+1).coerceAtMost(100); encounter(true)
                                    if(fieldResearch in listOf(25,50,75,100) && fieldResearch !in claimedFieldRewards) { claimedFieldRewards.add(fieldResearch); goldBalance+=50; rewardDialog=true }
                                })
                            } else LocationScreen(location)
                        }
                        1 -> CreateScreen(inventory, storage, (carryMax-carryNow).coerceAtLeast(0.0))
                        2 -> CharacterScreen(level, xp, freePoints, stats, skillLevels, skillXp, inventory, equipment, currentHp, currentMp, currentOv, hpMax, mpMax, ovMax, subTab, {subTab=it}, {item->drawerItem=item;drawerStorage=false;quantityText="";drawerSliderValue=0f}, fireballLearned, {fireballDrawer=true}, {slot,item->
                            if (equipment[slot] == null) {
                                val source = inventory.firstOrNull { it.id == item.id }
                                if (source != null) { inventory.remove(source); equipment[slot] = source.copy(equipped=true, equipmentSlot=slot) }
                            } else toast="Слот уже занят."
                        }, {slot->
                            val worn = equipment.remove(slot)
                            if (worn != null) addToStack(inventory, worn.copy(equipped=false))
                        },expandedStat,{expandedStat=it}, {name-> if(freePoints>0){stats[name]=(stats[name]?:5)+1;freePoints--}else toast="Нет свободных очков характеристик."})
                        3 -> MapScreen(location) { location=it; merchant=null; autoExplore=false; inBattle=false; battleMonster=null; tab=0 }
                        else -> SettingsScreen(multiplier,{multiplier=it},{addXp((80*multiplier.toDouble()).toInt())},{goldBalance+=55},{showResetConfirm=true})
                    }
                }
                if(tab==0 && !inBattle) CarryBar(carryNow,carryMax)
                NavigationBar(containerColor=Color(0xFF211C17),contentColor=cream) {
                    val labels=listOf("Ты здесь","Чертежи","Персонаж","Карта","Настройки")
                    val icons=listOf(Icons.Default.Place,Icons.Default.Build,Icons.Default.Person,Icons.Default.Map,Icons.Default.Settings)
                    labels.forEachIndexed { i,label ->
                        NavigationBarItem(selected=tab==i,onClick={tab=i;drawerItem=null;merchant=null;pendingUpgrade=null},icon={
                            if(i==2) Box(Modifier.size(45.dp).background(if(tab==i)goldColor else Color(0xFF493522),CircleShape),contentAlignment=Alignment.Center){Icon(icons[i],null,tint=if(tab==i)Color.Black else goldColor)}
                            else Icon(icons[i],null)
                        },label={if(label.isNotEmpty())Text(label,fontSize=9.sp,maxLines=1)},colors=NavigationBarItemDefaults.colors(selectedIconColor=goldColor,selectedTextColor=goldColor,indicatorColor=Color(0xFF493522),unselectedIconColor=Color.LightGray,unselectedTextColor=Color.LightGray))
                    }
                }
            }
            if(tab==0) {
                Box(Modifier.align(Alignment.BottomStart).padding(start=12.dp, bottom=78.dp).size(66.dp).clip(CircleShape).background(Color(0xFF211C17)).border(1.dp,goldColor,CircleShape), contentAlignment=Alignment.Center) {
                    Column(horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
                        Text(String.format("%02d:%02d",gameMinutes/60,gameMinutes%60), color=cream, fontSize=14.sp, fontWeight=FontWeight.Bold)
                        Text("День $gameDay", color=goldColor, fontSize=9.sp)
                    }
                }
            }
            if(bedDialog) {
                val nextBed = (bedRank + 1).coerceAtMost(6)
                AlertDialog(
                    onDismissRequest={bedDialog=false},
                    title={Text("Кровать", color=goldColor)},
                    text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("Текущая: ${bedNames[bedRank]}", color=cream, fontWeight=FontWeight.Bold)
                        Text("Ранг ${rankNames[bedRank]} · восстановление +${bedOv[bedRank]} ОВ", color=muted)
                        Divider(color=muted)
                        if(bedRank<6) {
                            Text("Следующая: ${bedNames[nextBed]}", color=cream, fontWeight=FontWeight.Bold)
                            Text("Ранг ${rankNames[nextBed]} · восстановление +${bedOv[nextBed]} ОВ", color=muted)
                        } else Text("Достигнут максимальный ранг S.", color=goldColor)
                    }},
                    confirmButton={Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick={advanceGameTime(8*60);currentHp=hpMax;currentMp=mpMax;currentOv=(currentOv+bedOv[bedRank]).coerceAtMost(ovMax);toast="Вы поспали 8 часов. HP и MP восстановлены полностью, ОВ +${bedOv[bedRank]} ."}) { Text("Спать", color=goldColor) }
                        TextButton(onClick={if(bedRank<6)bedRank++}) { Text("Улучшить", color=if(bedRank<6)goldColor else muted) }
                    }},
                    dismissButton={TextButton(onClick={bedDialog=false}){Text("Закрыть",color=cream)}},
                    containerColor=panel
                )
            }
            if(rewardDialog) AlertDialog(onDismissRequest={rewardDialog=false},title={Text("Награда 50G")},text={Text("Вы достигли контрольной точки исследования поля.")},confirmButton={TextButton(onClick={rewardDialog=false}){Text("Закрыть")}})
            if(deathDialog) AlertDialog(onDismissRequest={deathDialog=false},title={Text("Вы умерли")},text={Text("Вы потеряли ${deathPenalty}G")},confirmButton={TextButton(onClick={deathDialog=false}){Text("Закрыть")}})
            if(fireballDrawer) {
                Row(Modifier.fillMaxSize().background(Color(0x99000000)),horizontalArrangement=Arrangement.End) {
                    Spacer(Modifier.weight(1f).fillMaxHeight().clickable{focusManager.clearFocus()})
                    Column(Modifier.fillMaxHeight().fillMaxWidth(.75f).background(panel).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("Огненный шар",color=goldColor,fontSize=21.sp,fontWeight=FontWeight.Bold)
                        Text("Потребляет 25 MP, наносит противнику 50 урона огнём. Время отката 3с.",color=cream,fontSize=14.sp)
                        Spacer(Modifier.weight(1f))
                        Button(onClick={fireballLearned=false;fireballDrawer=false;toast="Навык «Огненный шар» забыт."},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=red)){Text("Забыть")}
                        TextButton(onClick={fireballDrawer=false},modifier=Modifier.fillMaxWidth()){Text("Закрыть",color=goldColor)}
                    }
                }
            }
            if(drawerItem!=null) {
                val item=drawerItem!!
                Row(Modifier.fillMaxSize().background(Color(0x99000000)),horizontalArrangement=Arrangement.End) {
                    Spacer(Modifier.weight(1f).fillMaxHeight().clickable{quantityText="";drawerSliderValue=0f;focusManager.clearFocus()} )
                    Column(Modifier.fillMaxHeight().fillMaxWidth(.75f).background(panel).padding(15.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(54.dp).background(Color(0xFF44382B),RoundedCornerShape(9.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.Inventory2,null,tint=goldColor,modifier=Modifier.size(29.dp))}
                            Spacer(Modifier.width(9.dp)); Text(item.name,color=cream,fontWeight=FontWeight.Bold,fontSize=17.sp)
                        }
                        Text(item.description,color=muted,fontSize=12.sp)
                        val available=item.amount
                        val selected=quantityText.replace(',','.').toDoubleOrNull()?.coerceIn(0.0,available)?:drawerSliderValue.toDouble().coerceIn(0.0,available)
                        if(item.unit!="кг") Text("Вес: 1 шт. — ${item.weightEach} кг\nВсего: ${"%.2f".format(selected*item.weightEach)} кг",color=muted,fontSize=12.sp)
                        Spacer(Modifier.weight(1f))
                        Text("Количество",color=goldColor,fontWeight=FontWeight.Bold)
                        OutlinedTextField(value=quantityText,onValueChange={quantityText=it.filter{c->c.isDigit()||c=='.'||c==','};drawerSliderValue=quantityText.replace(',','.').toFloatOrNull()?:0f},modifier=Modifier.fillMaxWidth(.48f),singleLine=true,placeholder={Text("",color=muted)},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=cream,unfocusedTextColor=cream))
                        Slider(value=selected.toFloat(),onValueChange={drawerSliderValue=it;quantityText="";focusManager.clearFocus()},valueRange=0f..available.toFloat().coerceAtLeast(.01f),modifier=Modifier.fillMaxWidth().padding(end=12.dp))
                        if(item.equipmentSlot!=null) {
                            if(item.equipped) Button(onClick={val worn=equipment[item.equipmentSlot]; if(worn!=null && worn.id==item.id){equipment.remove(item.equipmentSlot);addToStack(inventory,worn.copy(equipped=false))};drawerItem=null},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Снять")}
                            else Button(onClick={
                                if(equipment[item.equipmentSlot]==null) {
                                    val source=inventory.firstOrNull { it.id==item.id }
                                    if(source!=null && source.amount>=1.0) {
                                        val stackableSlot = item.equipmentSlot!!.startsWith("Зелье") || item.equipmentSlot=="Стрелы"
                                        val equipCount = if(stackableSlot) ceil(selected).coerceIn(1.0,source.amount) else 1.0
                                        if(source.amount>equipCount) inventory[inventory.indexOf(source)]=source.copy(amount=source.amount-equipCount) else inventory.remove(source)
                                        equipment[item.equipmentSlot!!]=source.copy(amount=equipCount,equipped=true)
                                        drawerItem=null
                                    } else toast="Предмет отсутствует в инвентаре."
                                } else toast="Слот уже занят."
                            },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Надеть")}
                        }
                        if(drawerStorage) Button(onClick={
                            val count=if(item.unit=="кг") floor(selected*100)/100 else ceil(selected).coerceAtLeast(1.0)
                            moveItem(item,true,count,false)
                        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Забрать")}
                        else Button(onClick={
                            val count=if(item.unit=="кг") floor(selected*100)/100 else ceil(selected).coerceAtLeast(1.0)
                            moveItem(item,false,count,true)
                        },enabled=location=="Дом"&&!item.equipped,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Выложить")}
                        OutlinedButton(onClick={confirmDelete=true},enabled=!item.equipped,modifier=Modifier.fillMaxWidth()){Text("Выбросить",color=cream)}
                        TextButton(onClick={drawerItem=null},modifier=Modifier.fillMaxWidth()){Text("Закрыть меню",color=goldColor)}
                    }
                }
                if(confirmDelete) AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Удаление предмета")},text={Text("Вы точно хотите удалить предмет?\n${item.name} — $quantityText")},confirmButton={TextButton(onClick={
                    val source = if(drawerStorage) storage else inventory
                    val found = source.firstOrNull { it.id == item.id }
                    if(found!=null) {
                        val amount = if(found.unit=="кг") floor((quantityText.replace(',','.').toDoubleOrNull()?:0.0)*100)/100 else ceil(quantityText.replace(',','.').toDoubleOrNull()?:0.0)
                        val safe = amount.coerceIn(0.0,found.amount)
                        source.remove(found)
                        if(found.amount-safe>0.0001) source.add(found.copy(amount=found.amount-safe))
                    }
                    drawerItem=null;confirmDelete=false
                }){Text("Удалить")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("Отмена")}},containerColor=panel,titleContentColor=cream,textContentColor=cream)
            }
            if(buyItem!=null && merchant!=null) {
                val product=buyItem!!
                AlertDialog(onDismissRequest={buyItem=null},title={Text(product.name)},text={
                    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("Цена: ${product.price} G / ${product.unit}")
                        val precision = if(product.unit=="кг") 100.0 else 1.0
                        val maxByGold = if(product.price>0) floor(goldBalance.toDouble()/product.price*precision)/precision else 0.0
                        val maxByWeight = if(product.weightEach>0) floor(((carryMax-carryNow).coerceAtLeast(0.0)/product.weightEach)*precision)/precision else 0.0
                        val maxBuy = if(product.name=="Книга навыков: Огненный шар") 1.0 else minOf(product.amount,maxByGold,maxByWeight,9999.0).coerceAtLeast(0.0)
                        val qty=buyQty.replace(',','.').toDoubleOrNull()?.coerceIn(0.0,maxBuy)?:buySliderValue.toDouble().coerceIn(0.0,maxBuy)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value=buyQty,onValueChange={if(product.name!="Книга навыков: Огненный шар") { buyQty=it.filter{c->c.isDigit()||c=='.'||c==','};buySliderValue=buyQty.replace(',','.').toFloatOrNull()?:0f }},placeholder={Text("")},enabled=product.name!="Книга навыков: Огненный шар",singleLine=true,modifier=Modifier.fillMaxWidth(.48f),keyboardOptions=KeyboardOptions(keyboardType=if(product.unit=="кг")KeyboardType.Decimal else KeyboardType.Number))
                        if(product.name!="Книга навыков: Огненный шар" && maxBuy>1.0) Slider(value=(qty.coerceIn(1.0,maxBuy)).toFloat(),onValueChange={buySliderValue=it;buyQty="";focusManager.clearFocus()},valueRange=1f..maxBuy.toFloat(),steps=0,modifier=Modifier.fillMaxWidth().padding(end=12.dp))
                        Text("Можно купить: ${if(product.unit=="кг")"%.2f".format(maxBuy) else maxBuy.toInt()} ${product.unit}")
                        Text("Золото: ${"%.2f".format(qty*product.price)} G")
                        Text("Добавляемый вес: ${"%.2f".format(qty*product.weightEach)} кг")
                    }
                },confirmButton={TextButton(onClick={
                    val rawQty=if(product.name=="Книга навыков: Огненный шар")1.0 else buyQty.replace(',','.').toDoubleOrNull()?:buySliderValue.toDouble()
                    val qty=if(product.unit=="кг") floor(rawQty*100)/100 else ceil(rawQty)
                    val price=ceil(qty*product.price).toInt()
                    if(qty<=0) toast="Укажи количество."
                    else if(price>goldBalance)toast="Недостаточно золота."
                    else if(carryNow+qty*product.weightEach>carryMax)toast="Вы столько не унесёте."
                    else if(product.name=="Книга навыков: Огненный шар") {
                        if(fireballLearned) toast="Навык «Огненный шар» уже изучен."
                        else { goldBalance-=price; fireballLearned=true; toast="Вы изучили навык «Огненный шар»." }
                        buyItem=null
                    }
                    else {goldBalance-=price;addToStack(inventory,product.copy(id=(inventory.maxOfOrNull{it.id}?:200)+1,amount=qty));buyItem=null}
                }){Text("Купить")}},dismissButton={TextButton(onClick={buyItem=null}){Text("Отмена")}},containerColor=panel,titleContentColor=cream,textContentColor=cream)
            }
            if(pendingUpgrade!=null) {
                val (upgradeTool, currentRank)=pendingUpgrade!!
                val nextRank=currentRank+1
                Dialog(onDismissRequest={pendingUpgrade=null}) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(panel).padding(20.dp),
                        verticalArrangement=Arrangement.spacedBy(11.dp)
                    ) {
                        Text("Улучшение инструмента",color=cream,fontSize=19.sp,fontWeight=FontWeight.Bold)
                        Text(upgradeTool.rankNames.getOrElse(currentRank){upgradeTool.name},color=muted,fontSize=13.sp)
                        Text("↓",color=goldColor,fontSize=20.sp)
                        Text(upgradeTool.rankNames.getOrElse(nextRank){rankNames[nextRank]},color=goldColor,fontWeight=FontWeight.Bold,fontSize=17.sp)
                        Text(upgradeTool.rankDescriptions.getOrElse(nextRank){upgradeTool.description},color=cream,fontSize=12.sp)
                        Text("Ранг: ${rankNames[currentRank]} → ${rankNames[nextRank]}",color=muted,fontSize=11.sp)
                        Button(onClick={
                            toolRanks[upgradeTool.name]=nextRank
                            productionMessage="${upgradeTool.rankNames.getOrElse(currentRank){upgradeTool.name}} улучшен до ${upgradeTool.rankNames.getOrElse(nextRank){rankNames[nextRank]}}."
                            pendingUpgrade=null
                        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF388E3C),contentColor=Color.White)) { Text("Улучшить") }
                        Button(onClick={pendingUpgrade=null},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=red,contentColor=Color.White)) { Text("Отменить") }
                    }
                }
            }
            if(showResetConfirm) AlertDialog(
                onDismissRequest={showResetConfirm=false},
                title={Text("Начать заново",color=goldColor)},
                text={Text("Вы уверены что хотите сбросить текущий прогресс и начать заново? Все уровни, ресурсы и навыки обнуляется",color=cream)},
                confirmButton={Button(onClick={
                    context.getSharedPreferences("blacksmiths_path_save", Context.MODE_PRIVATE).edit().clear().apply()
                    level=1;xp=0;freePoints=0;goldBalance=0;reputation=0;multiplier="1"
                    stats.clear();stats.putAll(mapOf("Сила" to 5,"Ловкость" to 5,"Выносливость" to 5,"Интеллект" to 5,"Удача" to 5))
                    skills.forEach{skillLevels[it]=1;skillXp[it]=0};toolRanks.keys.toList().forEach{toolRanks[it]=0}
                    inventory.clear();inventory.add(Item(1,"Начальный молот кузнеца","При экипировке повышает силу на 1.",1.0,"шт.",2.0,equipmentSlot="Оружие 1"))
                    storage.clear();equipment.clear();craftRoomUnlocked=false;runeRoomUnlocked=false;location="Дом";room=0;showStorage=false
                    fieldResearch=0;autoExplore=false;gameDay=1;gameMinutes=7*60;bedRank=0;fireballLearned=false
                    currentHp=100+20*5+5;currentMp=50+15*5+3;currentOv=50+10*5+2
                    inBattle=false;battleMonster=null;deathDialog=false;fireballCooldown=false;claimedFieldRewards.clear()
                    tab=0;drawerItem=null;merchant=null;buyItem=null;toast="Игра начата заново.";showResetConfirm=false
                },colors=ButtonDefaults.buttonColors(containerColor=red,contentColor=Color.White)){Text("Подтвердить",fontWeight=FontWeight.Bold)}},
                dismissButton={Button(onClick={showResetConfirm=false},colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF388E3C),contentColor=Color.White)){Text("Отмена")}},containerColor=panel)
            if(toast.isNotEmpty()) AlertDialog(onDismissRequest={toast=""},text={Text(toast)},confirmButton={TextButton(onClick={toast=""}){Text("ОК")}},containerColor=panel,textContentColor=cream)
        }
    }
}

@Composable
private fun StatusHeader(level:Int,hp:Int,hpMax:Int,mp:Int,mpMax:Int,ov:Int,ovMax:Int,rank:String,rep:Int,repMax:Int,goldBalance:Int,attack:Int,defense:Int,speed:Int) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF211C17)).padding(horizontal=13.dp,vertical=7.dp), verticalArrangement=Arrangement.spacedBy(4.dp)) {
        Text("Уровень $level", color=goldColor, fontSize=11.sp, fontWeight=FontWeight.Bold)
        listOf(Triple("Здоровье",hp to hpMax,Color(0xFFC84D45)), Triple("Мана",mp to mpMax,Color(0xFF438BD4)), Triple("ОВ",ov to ovMax,Color(0xFFE2AD35))).forEach { (label,values,color) ->
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Text(label, color=cream, fontSize=10.sp, modifier=Modifier.width(66.dp))
                Text("${values.first}/${values.second}", color=cream, fontSize=10.sp, modifier=Modifier.width(55.dp))
                LinearProgressIndicator(progress={(values.first.toFloat()/values.second.coerceAtLeast(1)).coerceIn(0f,1f)}, modifier=Modifier.weight(1f).height(5.dp), color=color, trackColor=panel)
            }
        }
        Text("Атака: $attack   Защита: $defense   Скорость: $speed", color=cream, fontSize=10.sp)
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Text("Репутация: $rank — $rep/$repMax",color=goldColor,fontSize=11.sp,modifier=Modifier.weight(1f))
            Text("Золото: $goldBalance G",color=goldColor,fontSize=12.sp,fontWeight=FontWeight.Bold)
        }
    }
}
@Composable
private fun CarryBar(weight:Double,max:Double) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF211C17)).padding(horizontal=12.dp,vertical=4.dp)) {
        LinearProgressIndicator(progress={(weight/max).toFloat().coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(3.dp),color=goldColor,trackColor=panel)
        Text("${"%.1f".format(weight)} / ${"%.0f".format(max)} кг",color=muted,fontSize=9.sp,modifier=Modifier.align(Alignment.End))
    }
}
@Composable
private fun WorkshopRoom(title:String,tools:List<Tool>,ranks:Map<String,Int>,onRank:(String)->Unit,onMessage:(String)->Unit,message:String,onRequestUpgrade:(Tool,Int)->Unit,locked:Boolean=false,unlockCost:Int=0,gold:Int=0,onUnlock:()->Unit={},extraTool:Tool?=null) {
    Column(Modifier.fillMaxSize().padding(horizontal=14.dp)) {
        Text(title,color=cream,fontSize=24.sp,fontWeight=FontWeight.Bold)
        if(locked) {
            Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)){Icon(Icons.Default.Lock,null,tint=goldColor,modifier=Modifier.size(42.dp));Text("Комната закрыта",color=cream,fontSize=20.sp);Text("Разблокировка: $unlockCost G",color=goldColor);Button(onClick=onUnlock,enabled=gold>=unlockCost,colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Разблокировать")};if(gold<unlockCost)Text("Недостаточно золота. Есть: $gold G",color=red,fontSize=12.sp)}}
        } else {
            Text("Пять инструментов • свайп не влияет на нижнюю навигацию",color=muted,fontSize=10.sp)
            LazyVerticalGrid(columns=GridCells.Fixed(2),modifier=Modifier.weight(1f),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                items(listOfNotNull(extraTool)+tools) { tool ->
                    val current = (ranks[tool.name] ?: 0).coerceIn(0, 6)
                    val currentName = tool.rankNames.getOrElse(current) { tool.name }
                    val currentDescription = tool.rankDescriptions.getOrElse(current) { tool.description }
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(panel).clickable{onMessage("$currentName. $currentDescription")}.padding(8.dp)) {
                        AsyncImage(model=tool.image,contentDescription=currentName,modifier=Modifier.fillMaxWidth().aspectRatio(3f/4f).clip(RoundedCornerShape(8.dp)))
                        Text(currentName,color=cream,fontSize=12.sp,fontWeight=FontWeight.SemiBold,minLines=2)
                        Text("Ранг ${rankNames[current]}",color=goldColor,fontSize=10.sp)
                        Button(onClick={ if (current < 6) onRequestUpgrade(tool,current) },enabled=current < 6,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(2.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Улучшить",fontSize=11.sp)}
                        tool.requirements.forEach{Text(it,color=muted,fontSize=9.sp)}
                    }
                }
            }
            if(message.isNotBlank()) Text(message,color=goldColor,fontSize=10.sp)
        }
    }
}
@Composable
private fun StorageScreen(items:List<Item>,onItem:(Item)->Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Склад",color=cream,fontSize=24.sp,fontWeight=FontWeight.Bold)
        Text("Предметы на складе не учитываются в переносимом весе.",color=muted,fontSize=11.sp)
        LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.fillMaxSize(),contentPadding=PaddingValues(top=10.dp),verticalArrangement=Arrangement.spacedBy(6.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            items(40) { i -> val item=items.getOrNull(i)
                Box(Modifier.aspectRatio(1f).background(panel,RoundedCornerShape(7.dp)).clickable{item?.let(onItem)},contentAlignment=Alignment.Center) {
                    if(item!=null) Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Inventory2,null,tint=goldColor);Text("${if(item.unit=="кг")String.format("%.2f",item.amount).trimEnd('0').trimEnd('.') else item.amount.toInt()} ${item.unit}",color=muted,fontSize=8.sp,textAlign=TextAlign.Center)}
                    else Text("·",color=muted)
                }
            }
        }
    }
}
@Composable
private fun MarketScreen(merchants:List<Merchant>,onSelect:(Merchant)->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text("Рынок",color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
        merchants.forEach { m ->
            Row(Modifier.fillMaxWidth().padding(vertical=5.dp).background(panel,RoundedCornerShape(12.dp)).clickable{onSelect(m)}.padding(13.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Store,null,tint=goldColor,modifier=Modifier.size(34.dp));Spacer(Modifier.width(10.dp))
                Column { Text(m.name,color=cream,fontWeight=FontWeight.Bold);Text("${m.job} • ${m.race}",color=muted,fontSize=11.sp) }
                Spacer(Modifier.weight(1f));Text("Торговать ›",color=goldColor,fontSize=11.sp)
            }
        }
    }
}
@Composable
private fun MerchantScreen(merchant:Merchant,goldBalance:Int,onBuy:(Item)->Unit,onLeave:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        TextButton(onClick=onLeave){Text("← К торговцам",color=goldColor)}
        Text(merchant.name,color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
        Text("${merchant.job} • ${merchant.race}",color=muted)
        Text("«Что брать будешь?»",color=goldColor,modifier=Modifier.padding(vertical=10.dp))
        merchant.stock.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(vertical=4.dp).background(panel,RoundedCornerShape(10.dp)).padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)){Text(item.name,color=cream,fontWeight=FontWeight.SemiBold);Text("${item.price} G / ${item.unit}",color=muted,fontSize=11.sp)}
                Button(onClick={onBuy(item)},colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Купить")}
            }
        }
        Text("Твоё золото: $goldBalance G",color=goldColor,fontWeight=FontWeight.Bold)
    }
}
@Composable
private fun MapScreen(location:String,onMove:(String)->Unit) {
    val places=listOf("Рынок" to "Здесь можно купить всё, что тебе нужно.","Ворота" to "Выход из города.","Замок" to "Здесь живёт король.","Дом" to "Дряхлый, но свой.","Поля" to "Колосистая пшеница и мелкие вредители.","Лес" to "Подходит для рубки древесины.")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text("Карта",color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        places.forEach { (name,desc) ->
            Row(Modifier.fillMaxWidth().padding(vertical=5.dp).background(panel,RoundedCornerShape(12.dp)).padding(11.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Place,null,tint=goldColor);Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text(name,color=cream,fontWeight=FontWeight.Bold);Text(desc,color=muted,fontSize=10.sp)}
                if(location==name)Text("Вы здесь",color=goldColor,fontSize=10.sp) else Button(onClick={onMove(name)},contentPadding=PaddingValues(horizontal=7.dp),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Переместиться",fontSize=9.sp)}
            }
        }
    }
}
@Composable
private fun FieldLocationScreen(progress:Int,autoExplore:Boolean,onAutoExplore:(Boolean)->Unit,onRest:()->Unit,onExplore:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Поля",color=cream,fontSize=25.sp,fontWeight=FontWeight.Bold)
        Text("Колосистая пшеница и мелкие вредители.",color=muted)
        Text("Исследование: $progress / 100",color=goldColor,fontWeight=FontWeight.Bold)
        Box(Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(9.dp)).background(panel)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(progress/100f).background(Color(0xFF4DAD70)))
            Row(Modifier.fillMaxSize(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) { listOf(25,50,75,100).forEach { Box(Modifier.width(2.dp).fillMaxHeight().background(cream)) } }
        }
        Text("Контрольные точки: 25% · 50% · 75% · 100%",color=muted,fontSize=11.sp)
        Spacer(Modifier.weight(1f))
        Button(onClick=onRest,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=panel,contentColor=cream)){Text("Отдохнуть · +30 минут · +5 ОВ")}
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Button(onClick=onExplore,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Исследовать")}
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Text("Авто", color=cream, fontSize=9.sp)
                Switch(checked=autoExplore,onCheckedChange=onAutoExplore)
            }
        }
    }
}

@Composable
private fun BattleScreen(monster:FieldMonster,monsterHp:Int,monsterOv:Int,hp:Int,mp:Int,ov:Int,hpMax:Int,mpMax:Int,ovMax:Int,hpPotion:Item?,ovPotion:Item?,fireballLearned:Boolean,fireballCooldown:Boolean,onHpPotion:()->Unit,onOvPotion:()->Unit,onFireball:()->Unit,onEscape:()->Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.SpaceBetween) {
        Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(12.dp)).padding(10.dp)) {
            Text("${monster.name} • ${monster.rank} • Ур. ${monster.level}",color=cream,fontWeight=FontWeight.Bold)
            listOf(Triple("HP",monsterHp,monster.hp),Triple("MP",0,0),Triple("ОВ",monsterOv,monster.ov)).forEach { (n,v,mx) ->
                Text(if(mx>0)"$n $v/$mx" else "$n —",color=muted,fontSize=10.sp)
                LinearProgressIndicator(progress={if(mx>0)(v.toFloat()/mx).coerceIn(0f,1f) else 0f},modifier=Modifier.fillMaxWidth().height(5.dp),color=if(n=="HP")red else goldColor,trackColor=bg)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) { Text(monster.name,color=cream,fontSize=30.sp,fontWeight=FontWeight.Bold) }
        Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(12.dp)).padding(10.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick=onHpPotion,modifier=Modifier.weight(1f),enabled=hpPotion!=null,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF375B45))){Text(if(hpPotion!=null) "${hpPotion.name} ×${hpPotion.amount.toInt()}" else "Пусто",fontSize=9.sp,color=Color(0xFFFF7770))}
                Button(onClick=onOvPotion,modifier=Modifier.weight(1f),enabled=ovPotion!=null,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF375B45))){Text(if(ovPotion!=null) "${ovPotion.name} ×${ovPotion.amount.toInt()}" else "Пусто",fontSize=9.sp,color=Color(0xFFFFB347))}
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                repeat(5) { i ->
                    Button(onClick=onFireball,modifier=Modifier.weight(1f).height(48.dp),enabled=fireballLearned && i==0,contentPadding=PaddingValues(2.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF55432D),disabledContainerColor=Color(0xFF302920))){Text(if(i==0 && fireballLearned) if(fireballCooldown)"3с" else "🔥" else "—",fontSize=10.sp)}
                }
            }
            Button(onClick=onEscape,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=red)){Text("Сдаться")}
        }
    }
}

@Composable
private fun LocationScreen(location:String) {
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(Icons.Default.Place,null,tint=goldColor,modifier=Modifier.size(45.dp))
        Text(location,color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        Text(when(location){"Ворота"->"Выход из города.";"Замок"->"Здесь живёт король.";else->"Текущая локация."},color=muted)
    }
}
@Composable
private fun CharacterScreen(level:Int,xp:Int,free:Int,stats:MutableMap<String,Int>,skillLevels:Map<String,Int>,skillXp:Map<String,Int>,inventory:List<Item>,equipment:Map<String,Item>,hp:Int,mp:Int,ov:Int,hpMax:Int,mpMax:Int,ovMax:Int,sub:Int,onSub:(Int)->Unit,onItem:(Item)->Unit,fireballLearned:Boolean,onFireball:()->Unit,onEquip:(String,Item)->Unit,onUnequip:(String)->Unit,expanded:String,onExpand:(String)->Unit,onImprove:(String)->Unit) {
    val descriptions=mapOf(
        "Сила" to "Влияет на общий переносимый вес и на количество обрабатываемого материала за раз. Отвечает за навык кузнечного дела и за урон ближним оружием.",
        "Ловкость" to "Влияет на скорость выполнения действий и точность движений. Отвечает за эффективность ремесленного дела и владение одноручным оружием и оружием дальнего боя.",
        "Выносливость" to "Увеличивает запас здоровья и количество ОВ. ОВ тратится во время работы или боя. Влияет на эффективность блокирования.",
        "Интеллект" to "Влияет на запас маны и эффективность работы с рунами. Отвечает за навык рунической гравировки и определяет количество доступных ячеек активных навыков.",
        "Удача" to "Я в такое не верю."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start=13.dp,end=13.dp,top=13.dp,bottom=90.dp)) {
        Text("Персонаж",color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        Text("Уровень $level • Опыт $xp/${level*100} • Свободные очки: $free",color=goldColor,fontSize=11.sp)
        listOf(Triple("Здоровье",hp to hpMax,Color(0xFFC84D45)),Triple("Мана",mp to mpMax,Color(0xFF438BD4)),Triple("ОВ",ov to ovMax,Color(0xFFE2AD35))).forEach { (label,values,color) ->
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Text(label,color=cream,fontSize=10.sp,modifier=Modifier.width(65.dp))
                Text("${values.first}/${values.second}",color=cream,fontSize=10.sp,modifier=Modifier.width(52.dp))
                LinearProgressIndicator(progress={(values.first.toFloat()/values.second.coerceAtLeast(1)).coerceIn(0f,1f)},modifier=Modifier.weight(1f).height(5.dp),color=color,trackColor=panel)
            }
        }
        Spacer(Modifier.height(8.dp));Text("ЭКИПИРОВКА",color=goldColor,fontWeight=FontWeight.Bold,fontSize=11.sp)
        val slotRows=listOf(listOf("Кольцо 1","Голова","Кольцо 2"),listOf("Лук","Ожерелье","Стрелы"),listOf("Правая рука","Тело","Левая рука"),listOf("Оружие 1","Ноги","Оружие 2"),listOf("Зелье 1","Ступни","Зелье 2"))
        slotRows.forEach { row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){row.forEach{slot->val item=equipment[slot] ?: equipment[if(slot=="Правая рука")"Правая рука" else slot];val itemColor=when { item?.name?.contains("здоровья",true)==true -> Color(0xFFE05252); item?.name?.contains("маны",true)==true || item?.name?.contains("мана",true)==true -> Color(0xFF438BD4); item?.name?.contains("выносливости",true)==true -> Color(0xFFE2AD35); else -> if(item!=null)goldColor else muted };Box(Modifier.weight(1f).height(48.dp).padding(vertical=2.dp).background(panel,RoundedCornerShape(7.dp)).clickable{if(item!=null)onItem(item)},contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(item?.name?.take(12)?:slot,color=itemColor,fontSize=9.sp,textAlign=TextAlign.Center);if(item!=null && (slot.startsWith("Зелье") || slot=="Стрелы"))Text("×${item.amount.toInt()}",color=itemColor,fontSize=9.sp,fontWeight=FontWeight.Bold)}}}}}
        Text("Атака: ${5+(stats["Сила"]?:5)} • Защита: 0 • Скорость: ${stats["Ловкость"]?:5}",color=cream,fontSize=11.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
            listOf("Инвентарь","Навыки","Характеристики").forEachIndexed{i,s->Button(onClick={onSub(i)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(3.dp),colors=ButtonDefaults.buttonColors(containerColor=if(sub==i)goldColor else panel,contentColor=if(sub==i)Color.Black else cream)){Text(s,fontSize=9.sp)}}
        }
        Spacer(Modifier.height(8.dp))
        when(sub) {
            0 -> {
                Text("ИНВЕНТАРЬ",color=goldColor,fontWeight=FontWeight.Bold)
                LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.height(260.dp),userScrollEnabled=false,verticalArrangement=Arrangement.spacedBy(5.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    items(30){i->val item=inventory.getOrNull(i);Box(Modifier.aspectRatio(1f).background(panel,RoundedCornerShape(7.dp)).clickable{item?.let(onItem)},contentAlignment=Alignment.Center){if(item!=null)Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Inventory2,null,tint=goldColor);Text("${if(item.unit=="кг")String.format("%.2f",item.amount).trimEnd('0').trimEnd('.') else item.amount.toInt()} ${item.unit}",color=muted,fontSize=7.sp,textAlign=TextAlign.Center)}else Text("·",color=muted)}}
                }
            }
            1 -> {
                Text("ПАССИВНЫЕ НАВЫКИ",color=goldColor,fontWeight=FontWeight.Bold)
                listOf("Кузнечное дело","Ремесленное дело","Руническая гравировка","Двуручное оружие","Одноручное оружие","Дальний бой","Блокирование").forEach{s->
                    Column(Modifier.fillMaxWidth().padding(vertical=5.dp)){Row{Text(s,color=cream,modifier=Modifier.weight(1f));Text("${skillLevels[s]?:1}",color=goldColor)};LinearProgressIndicator(progress={((skillXp[s]?:0)/100f).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth(),color=goldColor);Text("${skillXp[s]?:0}/100",color=muted,fontSize=9.sp)}
                }
                Text("АКТИВНЫЕ НАВЫКИ",color=goldColor,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
                val unlocked=5+((stats["Интеллект"]?:5)-5).coerceAtLeast(0)/5
                LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.height(150.dp),userScrollEnabled=false,horizontalArrangement=Arrangement.spacedBy(5.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    items(unlocked+1){i->
                        val hasFireball=fireballLearned && i==0
                        Box(Modifier.aspectRatio(1f).background(panel,RoundedCornerShape(7.dp)).clickable(enabled=hasFireball){onFireball()},contentAlignment=Alignment.Center){
                            Text(if(i>=unlocked)"🔒" else if(hasFireball)"🔥" else "+",color=if(i>=unlocked)muted else goldColor)
                        }
                    }
                }
            }
            else -> {
                Text("ХАРАКТЕРИСТИКИ",color=goldColor,fontWeight=FontWeight.Bold)
                listOf("Сила","Ловкость","Выносливость","Интеллект","Удача").forEach{s->
                    Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(9.dp)).clickable{onExpand(if(expanded==s)"" else s)}.padding(10.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically){Text(s,color=cream,modifier=Modifier.weight(1f));Text("${stats[s]?:5}",color=goldColor,fontWeight=FontWeight.Bold);TextButton(onClick={onImprove(s)},contentPadding=PaddingValues(horizontal=8.dp)){Text("+",color=if(free>0)goldColor else red,fontSize=19.sp)}}
                        if(expanded==s)Text(descriptions[s]?: "",color=muted,fontSize=11.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }
        }
    }
}
@Composable
private fun CreateScreen(inventory: MutableList<Item>, storage: MutableList<Item>, remainingCarry: Double) {
    val coalNames = listOf("Бурый уголь", "Каменный уголь", "Крепкий уголь", "Чистый уголь", "Сердце вулкана")
    val coalColors = listOf(Color(0xFF72543B), Color(0xFF373737), Color(0xFF252525), Color(0xFFB8B8B8), Color(0xFFB64A27))
    var expandedProfession by remember { mutableStateOf("") }
    var expandedCategory by remember { mutableStateOf("") }
    var selectedRecipe by remember { mutableStateOf<CraftRecipe?>(null) }
    var selectedMaterialId by remember { mutableIntStateOf(-1) }
    var craftNotice by remember { mutableStateOf("") }
    val allItems = inventory + storage
    val categories = mapOf(
        "Кузнечное дело" to linkedMapOf(
            "Двуручное оружие" to listOf("Кувалда","Секира","Копьё","Меч"),
            "Одноручное оружие" to listOf("Булава","Длинный меч","Короткий меч","Кинжал","Топор"),
            "Экипировка" to listOf("Шлем","Нагрудник","Перчатки","Поножи","Сапоги"),
            "Разное" to listOf("Наконечники","Ожерелье","Кольца","Производственные инструменты","Декор")
        ),
        "Ремесло" to linkedMapOf(
            "Обработка кожи" to listOf("Выделанная кожа","Кожаный ремень","Ножны"),
            "Обработка древесины" to listOf("Деревянная заготовка","Рукоять оружия"),
            "Кожаные изделия" to listOf("Кожаный ремень","Ножны"),
            "Деревянные изделия" to listOf("Деревянный щит","Рукоять оружия")
        ),
        "Руническая гравировка" to linkedMapOf(
            "Рунические схемы" to listOf("Руническая пластина","Гравировка предмета"),
            "Рунические материалы" to listOf("Рунический камень"),
            "Гравировка предметов" to listOf("Гравировка предмета")
        )
    )
    fun matching(need: MaterialNeed): List<Pair<Item,String>> {
        val result = mutableListOf<Pair<Item,String>>()
        inventory.filter { item -> item.unit == need.unit && need.aliases.any { alias -> item.name.contains(alias, true) } }.forEach { result.add(it to "Инвентарь") }
        storage.filter { item -> item.unit == need.unit && need.aliases.any { alias -> item.name.contains(alias, true) } }.forEach { result.add(it to "Склад") }
        return result
    }
    fun available(need: MaterialNeed) = matching(need).sumOf { it.first.amount }
    fun consume(need: MaterialNeed) {
        var remaining = need.amount
        listOf(inventory,storage).forEach { source ->
            val matches = source.filter { item -> item.unit == need.unit && need.aliases.any { alias -> item.name.contains(alias,true) } }.toList()
            matches.forEach { item ->
                if (remaining > 0.0001) {
                    val used = minOf(item.amount,remaining)
                    if (item.amount <= used + 0.0001) source.remove(item)
                    else { val index=source.indexOf(item); source[index]=item.copy(amount=item.amount-used) }
                    remaining -= used
                }
            }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Чертежи", color=cream, fontSize=25.sp, fontWeight=FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            coalNames.forEachIndexed { index, coal ->
                val total = allItems.filter { it.name == coal }.sumOf { it.amount }
                if (total > 0.0) Column(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(panel).clickable { craftNotice = if(craftNotice==coal) "" else coal }.padding(5.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                    Box(Modifier.size(24.dp,16.dp).background(coalColors[index],RoundedCornerShape(5.dp)))
                    Text(if(craftNotice==coal) coal else "${"%.1f".format(total)} кг", color=if(craftNotice==coal)goldColor else cream, fontSize=7.sp, textAlign=TextAlign.Center, maxLines=2)
                }
            }
        }
        if(craftNotice.isNotBlank() && coalNames.contains(craftNotice)) Text(craftNotice,color=goldColor,fontSize=11.sp)
        categories.forEach { (profession, groups) ->
            Column(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(10.dp)).padding(12.dp)) {
                Row(Modifier.fillMaxWidth().clickable { expandedProfession=if(expandedProfession==profession) "" else profession;expandedCategory="" },verticalAlignment=Alignment.CenterVertically) { Text(profession,color=cream,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f)); Icon(if(expandedProfession==profession)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null,tint=goldColor) }
                if(expandedProfession==profession) groups.forEach { (category, products) ->
                    Column(Modifier.fillMaxWidth().padding(start=10.dp,top=8.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { expandedCategory=if(expandedCategory==category) "" else category },verticalAlignment=Alignment.CenterVertically) { Text("› $category",color=goldColor,fontSize=13.sp,modifier=Modifier.weight(1f));Icon(if(expandedCategory==category)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null,tint=muted) }
                        if(expandedCategory==category) products.forEach { product ->
                            Text("• $product",color=cream,fontSize=12.sp,modifier=Modifier.fillMaxWidth().clickable { selectedRecipe=craftRecipe(product);selectedMaterialId=-1 }.padding(start=14.dp,top=7.dp,bottom=4.dp))
                        }
                    }
                }
            }
        }
    }
    selectedRecipe?.let { recipe ->
        val enough = recipe.needs.all { available(it) + 0.0001 >= it.amount }
        val canCarry = recipe.resultWeight <= remainingCarry + 0.0001
        val outputSlot = when(recipe.name) {
            "Шлем" -> "Голова"; "Нагрудник" -> "Тело"; "Перчатки" -> "Правая рука"; "Поножи" -> "Ноги"; "Сапоги" -> "Ступни"
            "Ожерелье" -> "Ожерелье"; "Кольца" -> "Кольцо 1"; "Кувалда","Секира","Копьё","Меч","Булава","Длинный меч","Короткий меч","Кинжал","Топор" -> "Оружие 1"
            else -> null
        }
        AlertDialog(onDismissRequest={selectedRecipe=null;selectedMaterialId=-1},containerColor=panel,title={Text(recipe.name,color=goldColor,fontWeight=FontWeight.Bold)},text={
            Column(Modifier.fillMaxWidth().heightIn(max=520.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text(recipe.description,color=cream,fontSize=13.sp)
                Text("Минимальные материалы",color=goldColor,fontWeight=FontWeight.SemiBold)
                recipe.needs.forEach { need ->
                    val have=available(need)
                    Text("${need.label}: ${"%.2f".format(need.amount)} ${need.unit}  •  доступно ${"%.2f".format(have)} ${need.unit}",color=if(have>=need.amount)cream else red,fontSize=11.sp)
                    val cells=matching(need)
                    if(cells.isNotEmpty()) {
                        LazyVerticalGrid(columns=GridCells.Fixed(5),modifier=Modifier.fillMaxWidth().heightIn(max=105.dp),userScrollEnabled=false,horizontalArrangement=Arrangement.spacedBy(4.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                            items(cells.size) { index ->
                                val (item,place)=cells[index]
                                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(if(selectedMaterialId==item.id)goldColor else Color(0xFF393027)).clickable{selectedMaterialId=item.id}.padding(4.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Inventory2,null,tint=if(selectedMaterialId==item.id)Color.Black else goldColor,modifier=Modifier.size(18.dp))
                                    Text(item.name,color=if(selectedMaterialId==item.id)Color.Black else cream,fontSize=7.sp,maxLines=2,textAlign=TextAlign.Center)
                                    Text("${"%.1f".format(item.amount)} ${item.unit}",color=if(selectedMaterialId==item.id)Color.Black else muted,fontSize=7.sp)
                                    Text(place,color=if(selectedMaterialId==item.id)Color.Black else muted,fontSize=6.sp)
                                }
                            }
                        }
                    }
                }
                if(!enough) Text("Недостаточно материалов для создания.",color=red,fontSize=11.sp)
                if(!canCarry) Text("Не хватает места в инвентаре. Свободно ${"%.2f".format(remainingCarry)} кг.",color=red,fontSize=11.sp)
            }
        },confirmButton={Button(onClick={
            recipe.needs.forEach { consume(it) }
            val nextId=(inventory+storage).maxOfOrNull{it.id}?.plus(1) ?: 1000
            inventory.add(Item(nextId,recipe.name,recipe.description,1.0,"шт.",recipe.resultWeight,equipmentSlot=outputSlot,stackTag="crafted-${recipe.name}"))
            craftNotice="Создано: ${recipe.name}"
            selectedRecipe=null;selectedMaterialId=-1
        },enabled=enough && canCarry,colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Создать")}},dismissButton={TextButton(onClick={selectedRecipe=null;selectedMaterialId=-1}){Text("Закрыть",color=cream)}})
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(multiplier:String,onMultiplier:(String)->Unit,onXp:()->Unit,onGold:()->Unit,onReset:()->Unit) {
    var expanded by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Настройки",color=cream,fontSize=26.sp,fontWeight=FontWeight.Bold)
        Text("Множитель опыта",color=goldColor)
        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}) {
            OutlinedTextField(value="×$multiplier",onValueChange={},readOnly=true,modifier=Modifier.menuAnchor().fillMaxWidth(),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=cream,unfocusedTextColor=cream))
            ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){listOf("0.5","1","2","5","10").forEach{v->DropdownMenuItem(text={Text("×$v")},onClick={onMultiplier(v);expanded=false})}}
        }
        Button(onClick=onXp,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Получить опыт (+${(80*multiplier.toDouble()).toInt()} XP)")}
        Button(onClick=onGold,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=goldColor,contentColor=Color.Black)){Text("Получить золото (+55 G)")}
        Spacer(Modifier.height(18.dp))
        Button(onClick=onReset,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=red,contentColor=Color.White)){Text("Начать заново")}
    }
}
@Composable
private fun Placeholder(text:String) { Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(text,color=muted)} }
